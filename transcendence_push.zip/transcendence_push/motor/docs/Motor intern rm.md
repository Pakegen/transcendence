Motor functioning

Summary :

I) Rules of The Gwent
II) Review of logic between Front, Back, Motor
III) Review of the database the Motor uses
IV) Review of how a Motor game state is made
V) Review of how the Motor determines the possible plays
VI) Review of how a player game state is made
VII) Review of how the Motor plays a turn until the next game state
VIII) Review of how AI picks its plays
IX) Review of choices made, initial plan and current version
X) Brief review of the Python files
XI) AI usage and sources
XII) Python Module

## I) Rules of The Gwent

Gwent is a versus card game between 2 players.
The goal is to win rounds with the strength on your board, while keeping enough cards for the following rounds.

This project takes ideas from The Witcher 3 and standalone Gwent. It doesn't implement all the rules of either game.
The current version has the full match loop, AI, a simple Heroic Power and Stratagem. Most individual card effects are still outside this version, even when a card description mentions them.

Deck

A deck consists of 25 normal cards. Each player also has one Heroic Power, which is not a card in the deck.
Deck 1 is Witcher, deck 2 is Wild Hunt.
The player starting the match also receives a Stratagem, separately from the 25 cards.

Here, normal card means a Unit, Spell or Location. The Stratagem is handled separately.
Both humans can choose either deck. AI always uses Witcher, and a match can have at most one AI.

Game Setup

Back assigns the players to seat 1 and seat 2. If the first player is chosen randomly, this happens in Back.
Motor itself doesn't flip a coin. Player 1 always starts round 1.
P1 and P2 remain the same identities for the whole match, even when P2 starts another round.

Each player draws 10 cards, leaving 15 in the deck.
Both players choose their initial mulligan at the same time.
P1 may return up to 3 cards, P2 up to 2 cards.

To Mulligan X cards :

- Choose the X cards to return.
- Draw X replacement cards from the existing deck.
- Remove the chosen cards from the hand and append the replacements.
- Put the returned cards into the remaining deck and shuffle it.

So a returned card cannot be its own immediate replacement.
Keeping all cards does not shuffle the deck or reorder the hand.
These exchanges don't count as playing, destroying or discarding cards, and don't trigger effects.
There is only one mulligan phase, before round 1.

After the mulligan, the Stratagem is added to P1's hand. P1 now has 10 normal cards plus the Stratagem.
It was kept aside during the mulligan, so it could not be exchanged.

Turn Structure

The active player may play one normal card OR use Heroic Power, not both during the same turn.
P1 may also use the Stratagem if it is still available, before or after that normal card or Power.

The player keeps priority after playing a card or using a power and must press End Turn to finish.
Motor does not automatically end a human turn just because the normal card was played.
This leaves the opportunity to use a remaining Stratagem or to concede.

End Turn is only offered after a normal card or Power has been used.
Concede is always offered to the player with priority. The inactive player has no command, including no concession command.

Playing a Card

A normal card is played from the hand.
A Unit is appended to the selected front or back row, with its current strength contributing to that row.
A Spell or Location goes directly to the graveyard. Its described effect does not currently execute.

The original plan had targeted effects, automatic summons and destruction when a Unit reaches zero strength.
There is no general effect or death handler yet. Updating strength and the Boosted/Hurt flags does not by itself destroy a card.

Cards are appended on the right/end of the destination list. Choosing a precise insertion position is not implemented.
The deck is different: its last stored card is the top, and draws remove from that end.

Heroic Power

Each player may use it once per game.
It draws one card from the top of the deck, consumes the Power and replaces the normal play for this turn.
An empty deck still consumes the Power and enables End Turn, but draws nothing.
Power use is kept across rounds, it does not reset.

A player with an empty normal hand automatically passes at their own turn start, before they can use Power.
So Power cannot rescue an empty hand after that automatic pass.

Stratagem

Only P1 has one: card 126 for Witcher or 152 for Wild Hunt.
If P1 has a Unit on either row when using it, it gives +5 to the board score for the current round.
This is a board bonus, not a boost to one card or row.

If there is no Unit on the board, the Stratagem is still consumed but gives no bonus. Playing a Unit later doesn't give the missed bonus.
It is removed from the game, not sent to the graveyard.
An unused Stratagem remains in the hand between rounds.

Using it blocks Pass Round for that turn. By itself it does not enable End Turn and does not protect against the AFK card penalty.
A hand containing only the Stratagem counts as empty for automatic passing.
It still counts as one card in the displayed Hand_Count while it is in the hand.

Passing the Round

Passing means the player will not receive input priority again until the next round.
It is allowed before playing a normal card, using Power or using Stratagem during the current turn.
It immediately completes that player's turn.

An empty normal hand automatically passes at its own turn start, not immediately when the last card leaves the hand.
At a new round, the draws happen before checking for an empty hand.

A passed player still has automatic start/end phases while the other player continues. These are called pseudo-turns.
They don't ask Front for input. They advance the turn counter and that player's frost history and duration.
Actual frost damage and other turn effects are not implemented yet.
Once both players have passed, the round resolves without an extra pseudo-turn.

End of a Round

Points are the sum of both row strengths plus the current round board bonus.
The player with more points receives one Crown.
In a tie, both receive one Crown.

Motor checks both crown totals immediately after awarding them.
If the match is over, the final board is preserved: there is no cleanup and no new draw.

If the match continues, cards on both rows go to the owner's graveyard and their strength resets to base strength.
Frost durations, round bonus, pass flags and completed-turn counters reset for the next round.
Hands, remaining decks, unused Stratagem, used Power, global turn count and frost damage history are preserved.

Start of a New Round

Both players draw as many cards as possible, up to 3 cards each.
There is no additional mulligan.
The previous round winner starts. On a tie, the player who did not start the previous round starts next.

After drawing, a player with no normal cards is already passed.
If both players are empty, Motor can resolve another round immediately without asking for input.

End of the Game

A sole player reaching 2 Crowns wins, giving a result of 2–0 or 2–1.
If both reach 2 together, the result is a 2–2 draw.
Concede also ends the match and makes the opponent the winner.

An internal error or crashed Motor is a cancelled match handled by Back, not a draw created by the game rules.

## II) Review of logic between Front, Back, Motor

Front displays the game and lets the human select an offered command.
Back handles accounts, matching, fixed seat assignment, timers and the room's running process.
Motor owns game rules, legal commands, state changes and AI actions.

The usual cycle is :

Front sends one command to Back.
Back checks the sender and invokes Motor for that room.
Motor loads the saved state, validates the request, applies it and writes the new files.
Back waits for the process to finish, checks its exit code, then sends each human their own player view.
Front waits for that updated view before submitting another command.

Back must run only one operation at a time per room, including timeout operations.
Different rooms have separate files. Reusing a room number still requires Back to reject requests and timers left over from its previous match.
There is no match ID or request revision in the Motor command itself.

Running Motor

Python 3 and its standard library are enough. There are no extra Python packages for the engine.
These examples are run from game-engine :

```text
python3 motor.py XX I A1B C2D
python3 motor.py XX M <human-mulligan-code> [<second-human-code>]
python3 motor.py XX P <offered-command>
python3 motor.py XX T
```

`./motor.py` also works on Unix when the file has executable permission.
An absolute path to motor.py works from another working directory. Templates, catalogue and normal CLI output files are found beside the script.

XX is exactly two digits, from 00 to 99.
I, M, P and T are literal letters identifying the operation.
The square brackets in the example mean an optional second argument, they are not sent as text.

Initialization

In `A1B C2D`, A and C are P for a human or I for AI.
The middle digit identifies the fixed seat, 1 or 2.
B and D select deck 1 Witcher or deck 2 Wild Hunt.
AI is forced to Witcher even if its token requests deck 2.

```text
python3 motor.py 07 I P11 P22
python3 motor.py 07 I P11 I21
python3 motor.py 07 I I11 P22
```

The first example is human P1 Witcher against human P2 Wild Hunt.
The others place AI in seat 2 or seat 1.
Two AI seats are rejected.

I creates fresh `07M.json`, `071.json` and `072.json` and returns 0.
It replaces existing room file contents. It must not be used to resume a match.

Mulligan input

Back waits for one choice from each human and sends them together in one M call.
In PvP, either argument order works because the code contains the player number.
In AI games, send only the human choice. No AI placeholder, AI code or extra zero argument.

Examples keeping all human cards :

```text
python3 motor.py 07 M 15000000000 25000000
python3 motor.py 07 M 15000000000
python3 motor.py 07 M 25000000
```

These correspond to PvP, human P1 against AI P2, and AI P1 against human P2.
AI's mulligan is selected internally.
If AI is P1, the same M call also plays its opening turn before returning human P2 priority.

Normal input

Front sends the exact string selected from its latest Available_Commands.
Back invokes P with that string. Motor checks legality again.
For example, `python3 motor.py 07 P 16000000000000` ends P1's turn, only if that command was offered.

Using a card or Power can return the same human seat again because the turn is not over yet.
Whenever AI gets priority, Motor keeps going internally until human input is needed or the match ends.
Back does not send another request to make AI play.

Exit codes

The result is the process exit code, not a JSON message printed to stdout.
Nonzero does not necessarily mean failure.

| Code | Meaning |
| --- | --- |
| 0 | Initialization succeeded, collect the human mulligan choices |
| 1 | Success, human P1 has input priority |
| 2 | Success, human P2 has input priority |
| 3 | Invalid request, rejected without changing room files or declaring a loser |
| 4 | Internal, stored-state or file error, Back cancels the match |
| 61 | Match ended, P1 won |
| 62 | Match ended, P2 won |
| 63 | Match ended in a draw |

Back also needs to handle a killed process, an unexpected exit or a process that stops responding.
Error details go to stderr. If Motor hangs, Back terminates it and cancels the match.

Files and publication

`XXM.json` is the complete private Motor state.
`XX1.json` is only for P1 and `XX2.json` only for P2.
`ai_prediction/XX/` contains private AI simulations, never player views.
Back must never send XXM or predictions to Front.

Motor prepares and serializes the three room documents before writing, but the actual writes are sequential.
If one write fails, some files may already contain a new version while another still contains the old one.
There is no automatic rollback or three-file transaction. Back must not publish that partial result or retry it as a recovered match.

AI can produce several successive room saves inside one invocation.
Back reads only after successful completion, not after each file change. These writes are not an animation stream.

AFK and disconnect

Back owns the timer duration, timer resets and the check that a timer still belongs to the current match and turn.
The original one-minute duration was a proposal; no duration is enforced by Python.

During Turn, Back sends `python3 motor.py XX T` with no player argument.
If no normal card or Power was used, Motor randomly removes one normal hand card, if any, and ends the turn.
A Stratagem is never selected for this penalty.
The removed card stays recorded with Exist=false and Location="0000", outside every zone. It does not enter the graveyard.

After a normal card or Power, timeout only ends the turn.
If the penalty removed the last normal card, automatic passing happens at that player's next turn start.
A stale T could affect the wrong player, since T has no identity of its own. Back must discard it before invoking Motor.

During Mulligan, T is rejected. Back instead supplies the timed-out player's offered keep-all M code.
It keeps the other human's submitted choice if that player already answered.

Disconnect policy belongs to Back. Motor has no separate disconnect or reconnect command.
The original ideas were to keep advancing through timeouts, or to make the disconnected player lose. Neither is a separate implemented Motor rule.
An inactive disconnected player cannot simply be made to concede through P, since only the active player's commands are accepted.

## III) Review of the database the Motor uses

The catalogue is currently `library.json`, not `library.db`.
It is static card data, separate from the shuffled deck in a particular match.

The current file contains 102 card records :

- 74 Units
- 22 Spells
- 4 Locations
- 2 Stratagems

P1 and P2 versions of normal cards have different full IDs.
There are only two Stratagem records, 126 and 152, because only P1 receives a Stratagem. There are no catalogue entries 226 or 252.

A card record includes Full ID, Short ID, Name, Type, Tag and Strength.
It also has Play_target, event flags such as Played, Battlecry, Graveyard, End Turn and End Round, and `Card Desciption`.
That last field name is misspelled in the JSON, but it is the actual key.

Some descriptions are filled in and some are empty. All current Play_target values are "none".
A description or a true event flag does not mean Python executes the effect.
For example, Dandelion's description says to draw and play another card, but current play only puts Dandelion on a row and consumes the normal play.

Currently the engine reads Type to decide card destinations and Strength for AI mulligan ranking.
Initialization gets the card's starting and current strength from `motor_game_state_template.json`, not directly from library.json.
So changing catalogue Strength alone does not change the initialized card strength. The two files currently agree on these strengths and must stay consistent.

The initial idea was to consult the catalogue at each event and call the relevant card effect.
To extend the current version, the event metadata could identify known Python handlers for play, board entry, death, graveyard entry and turn/round end.
The handler would receive the current state and the relevant command/card/player context.
This event dispatcher is not present yet. It would use a registry of known functions rather than executing arbitrary text from JSON.

## IV) Review of how a Motor game state is made

1) Card IDs, zones and positions

A full card ID is the player number followed by a two-digit short ID.
For example 108 is P1's Roach, 208 is P2's Roach.
Different copies have their own IDs even if their names match.

Witcher uses short IDs 01–25, Wild Hunt 27–51.
Short IDs 26 and 52 are the two P1 Stratagem choices.
Only the two selected decks and the selected P1 Stratagem are retained in a fresh private state. Unselected card records are removed from it.

Each player has ordered lists for Deck, Hand, Front_Row, Back_Row and Graveyard.
The lists contain integer card IDs.
The matching `Card_108`, for example, contains that card's changing information.

Location is a four-character string `PZNN` :

| Part | Meaning |
| --- | --- |
| P | Fixed player 1 or 2 |
| Z | 1 deck, 2 hand, 3 front row, 4 back row, 5 graveyard |
| NN | Position starting at 01 |

`1201` is the first card in P1's hand.
`2302` is the second card in P2's front row.
`0000` means outside the zone lists.
Position 01 is the leftmost item for hand/rows and the bottom of the deck. The last deck item is drawn first.
Graveyard cards also retain list order, but no graveyard ordering effect currently runs.

Exist and Location must be considered together :

- Initial reserved Stratagem: Exist=true, Location="0000", not in a zone yet.
- A card in a normal zone: Exist=true, with its refreshed location.
- AFK-removed card or consumed Stratagem: Exist=false, Location="0000", no zone membership.

A graveyard card still exists. Exist=false does not mean "in the graveyard".

2) Fields in the private state

Match fields include Game_Type (PvP or AI), Room_number, Mulligan, Game_Phase and Round_number.
Player fields include Player_N_Type (Human or AI), Decklist, Crown and has_passed, with N replaced by 1 or 2.

Active_Player and Active_Opponent give the current turn identities.
They are both 0 during initial mulligans and after Game_End.
Round_Starting_Player and Previous_Round_Starting_Player separately track round starters, so a turn swap doesn't lose that information.

Turn_number counts started turns across the entire game, including automatic pseudo-turns. It does not count cards or pairs of turns.
The first P1 turn is 1. Playing a card during that turn doesn't increment it.

Card_has_been_played is 0 or 1. It becomes 1 after a normal card OR Heroic Power.
Stratagem_has_been_played is a separate private 0/1 flag.
Both reset at the start of a turn.
Player_N_Power_Used is a boolean that persists for the whole game.
Player_N_Round_Bonus holds the current board bonus and resets between rounds.

Player_N_Completed_Turns_This_Round counts completed playable turns for AI timing.
End Turn, voluntary Pass and timeout each complete such a turn.
Normal play, Power and Stratagem alone do not. Automatic passed-player turns also do not increment it.
These counters reset for a new round.

Each card has Name, Exist, Location, Base Strength, Current_Strength, Boosted, Hurt, Elixir_left and Revived.
Boosted is true when current strength is greater than base strength. Hurt is true when it is lower.
Elixir_left and Revived are reserved for future effects; the current templates start them at 0 and the engine does not run their planned mechanics.

For each player, the state also contains :

- Front_Row_Strength and Back_Row_Strength, summed from current card strengths.
- Board_Strength, equal to both rows plus Round_Bonus.
- Hand_Count, Deck_Count and Graveyard_Count, based on zone list lengths.
- Front_Frost and Back_Frost durations, plus the flag for frost on both rows.
- Five Frost_Damage_Turn_1 through Frost_Damage_Turn_5 values and their rolling total.

The frost history is five own turns, not five global turns.
At the owner's turn start, the oldest value is dropped, the others move one place older and the newest starts at zero.
The other player's history is untouched. Current code maintains this history but never applies frost damage.

Roach-in-deck and Winter-Queen-in-deck flags are refreshed for the relevant faction only.
Fields such as Dominance and Auberon-on-board are present in templates but not calculated by a working effect system. Their presence alone should not be treated as an active mechanic.

Last_Command contains the latest accepted I/M/P/T request and stays private.
Last_Phases contains a short trace of the latest action's phases, not the whole game history.
When AI makes more actions within the same invocation, later actions replace earlier command/phase traces. It is not a complete log of everything that invocation did.

Available_Commands in XXM is a dictionary with string keys "1" and "2", each containing that seat's current offers.
Winner is 1 or 2 for a winner, or 0. Winner=0 only means a draw when Game_Phase is Game_End.
End_Reason is Crowns or Concede for the implemented game endings.
Fields named _comment and similar are descriptive metadata, not instructions used to resolve rules.

3) Initialization and refresh

initialize() reads the Motor template, sets the selected seats/decks and creates their card lists.
Each deck is shuffled; the first ten stored cards become the hand and the remaining fifteen the deck.
The selected Stratagem stays aside until the mulligan finishes.

Before every room publication, refresh_state() checks and updates derived information :

- Check that every zone is a list and each listed card has one record and only one zone membership.
- Recalculate each listed card's Location and set its Exist flag.
- Sum row strengths, add the board bonus once, and refresh public counts.
- Refresh faction-specific deck-presence flags.
- Recalculate Boosted and Hurt for retained card records.
- Validate frost history values and sum the five buckets for each player.

The zone lists are the source for card locations. A refresh is not an effect resolver and doesn't repair every possible corrupt state.
Older saved rooms can be rejected if their fields or offers don't match the current engine. There is no general save migration; use a fresh room for the current version.

## V) Review of how the Motor determines the possible plays

During mulligans, Motor generates all allowed subsets of the player's hand.
With ten cards, this gives 176 choices for P1 and 56 for P2, including keeping everything.

Mulligan codes :

```text
P1: 15XXXYYYZZZ
P2: 25XXXYYY
```

Each slot is a three-digit card ID. Unused slots contain 000 and come first.
Selected card IDs are distinct and in ascending order.
P1's code is 11 digits, P2's code is 8 digits.

Examples :

```text
15000000000   P1 keeps everything
25000000      P2 keeps everything
15000000101   P1 returns 101
15000101105   P1 returns 101 and 105
25000227      P2 returns 227
```

These are examples, not permission to send a card that isn't in the current hand and offers.

Normal action codes

The current layout has 14 digits :

```text
P A CCC ZNN Z00 TTT
```

Spaces are only here to separate the fields.
P is the fixed player, A the action, CCC the card ID, ZNN the source zone and position, Z00 the destination zone and placement field, TTT the target.
Placement is currently always 00 and target always 000.

| Action | Meaning |
| --- | --- |
| 0 | Pass Round |
| 1 | Concede |
| 2 | Heroic Power |
| 3 | Play a normal card or Stratagem |
| 4 | Reserved for targeting, not implemented |
| 5 | Mulligan, using the separate shorter format |
| 6 | End Turn |

Control actions 0, 1, 2 and 6 use zeros for every field after player/action.

| Action | P1 code | P2 code |
| --- | --- | --- |
| Pass Round | 10000000000000 | 20000000000000 |
| Concede | 11000000000000 | 21000000000000 |
| Heroic Power | 12000000000000 | 22000000000000 |
| End Turn | 16000000000000 | 26000000000000 |

`13101201300000` means P1 plays card 101 from hand position 01 to the front row.
`13101201400000` does the same to the back row.
`13126211500000` uses P1's Stratagem 126 from hand position 11. Its destination field is 5 like a spell, but its special handling removes it outside the game instead of adding it to the graveyard.

Always transport these codes as strings.
Front uses offered commands rather than constructing codes from this document. Hand positions can change after each action.
The current source position supports 01–99. A larger playable hand would require an encoding extension; this is not a rule imposing a 99-card hand cap.

How offers are generated

legal_commands() first checks Turn phase, the active seat and its pass flag.
If the player has no priority, the result is an empty list.
Otherwise it offers Concede, then the other actions allowed by the turn flags.

Before normal play or Power, Pass Round is offered unless Stratagem was used this turn.
Unused Power is offered if there is a normal card in hand.
Each Unit gives two play commands, one per row. Each Spell/Location gives one, to the graveyard.
P1's Stratagem is separately allowed before or after the normal play/Power while priority is retained.
After normal play or Power, other normal cards and Pass Round disappear; End Turn becomes available.
At Game_End both lists are empty.

Future targeting

The original plan encoded target zone and position in the last three digits.
The later design keeps those three digits but makes them a target token :

- 000 means no target.
- A full existing card ID means that particular card, independent of its current position.
- 011–016 mean P1 deck, hand, front row, back row, graveyard, player/terrain.
- 021–026 mean the same for P2.

P1/P2 are absolute seats, not self/opponent. Zone 6 is a player/terrain target, not an additional card list.
010, 020 and other unlisted values have no defined use.

This design is not implemented in current offers. Sending a nonzero target is rejected because it is not an offered command.
To implement it, legal_commands() would combine playable cards with eligible targets from their effect rules, and apply_command() would pass the selected target to the handler.
The planned no-target fallback is allowed when an effect has no legal target, not as a way to ignore an available required target.
Multiple targets or a new choice after drawing/revealing information would need their own choice and phase rules.
Selecting a target locally in Front changes no game state until the complete command is submitted.

## VI) Review of how a player game state is made

The original idea was to copy the full state and remove secret data.
The current code starts with a player template and copies only the fields listed there.
This makes the permitted fields explicit rather than relying on remembering every secret to remove.

The files are `player1_game_state_template copy.json` and `player2_game_state_template.json`.
The word "copy" in the first filename is currently part of the actual path used by motor.py.

Each view receives its own hand IDs, both boards and graveyards, crowns, pass flags, row/board scores, counts, Power-use flags, phase, turn number and result fields.
The templates also expose the existing frost fields and Last_Phases.
Client_Player_Number identifies the recipient.
Available_Commands is just that player's list, not the private dictionary of both lists.

Views exclude :

- The opponent's hand identities.
- Both deck lists and their order.
- Full numeric Card_ID records and their private locations.
- Last_Command, including which cards were returned during mulligans.
- Round_Bonus, Stratagem_has_been_played and the completed-turn counters.

They also don't automatically include Room_number, Game_Type, player types/deck selections, round-starter fields or Player_1_Stratagem, since those are absent from the view templates.
Back supplies the account/room/mode context needed by Front.

Front should display Board_Strength from Motor. Summing the row scores alone misses the +5 Stratagem bonus.
The own hand includes a Stratagem while it exists there; opponent hand count is public even though the IDs are hidden.

Individual Current_Strength, Boosted and Hurt values are currently not projected to the views.
Before implementing visible card damage or boosts, the view builder would need to include the relevant public and own-card information while still hiding opponent hand/deck data.

player_view() uses deep copies for nested values, so modifying the returned view does not modify the real state.
During mulligans both humans have offers. During turns only the active seat does. A waiting player may still receive updated scores and board information.

## VII) Review of how the Motor plays a turn until the next game state

1) Validate before applying

For M, Motor checks the opening phase, deck contents, card locations, player views and expected mulligan offers.
Every human choice must be accepted before either exchange is applied. The AI selection is then added internally.

For P/T, Motor checks room identity, Turn phase, priority, counters, pass flags, zone data and the saved views.
It regenerates legal commands and compares them with the saved view offers.
For P, the submitted string must occur in the active player's offered list.

Both normal actions and timeouts work on an independent state copy.
A rejected request does not save that copy or overwrite Last_Command.
Motor verifies game legality, but it has no account identity: authenticating the person sending P1's code is still Back's job.

2) Apply the action

Normal card : remove it from hand, append to the chosen row or graveyard, set Card_has_been_played to 1, retain priority.
Power : mark used, draw if possible, set the same flag, retain priority.
Stratagem : remove it outside the game, apply the conditional board bonus, set its separate turn flag, retain priority.
Pass : mark the player passed, then finish the turn.
End Turn : finish the turn.
Concede : set the opponent as winner and clear priority.
T : perform the penalty if needed, then finish the turn.

General on-play, battlecry, death and end-turn effects are not silently executed between these steps.
Roach, for example, does not automatically jump out of the deck merely because its deck-presence flag is true.

3) Move to the next input

finish_turn() counts a completed playable turn and enters Turn_End.
advance_to_input() then loops through automatic progression.
If both players passed, it resolves the round first.
Otherwise start_turn() swaps the active player and opponent, increments Turn_number, resets action flags and shifts the new active player's frost history.
It also reduces that player's frost durations, without going below zero.

The empty-hand check can mark this new player passed.
A non-passed player stops the loop and receives offers.
A passed player gets an automatic Turn_End and the loop continues, with no input or timer window for that player.

This is why one request can advance through several internal phases or even rounds.
Round_Start, Turn_Start, Turn_End and Round_End are internal steps. The usual published phases are Mulligan, Turn and Game_End.
The final result clears both active IDs and all offers.

Example with two humans :

- After M, P1 starts turn 1.
- P1 plays a Unit. The returned state is still P1, still turn 1.
- P1 ends. P2 starts turn 2.
- If P2 passes, P1 starts turn 3.
- When P1 later ends, P2 gets an automatic passed turn, then P1 can receive another playable turn.
- When P1 also passes, the round ends immediately.

4) Refresh and save

write_room() calls refresh_state(), generates fresh offers, builds the two filtered views, serializes and writes all three files.
publish_and_run_ai() checks the resulting priority and resolves automatic AI actions if required, saving again after each real AI action.
The final process status tells Back which human can act or how the game ended.

Last_Phases can help inspect this flow, but it is only a trace, not the driver of game rules.
A normal card action usually has ["Turn"]. End Turn can add Turn_End, Turn_Start and Turn.
Round resolution can add Round_End, Round_Start or Game_End before the result is published.

## VIII) Review of how AI picks its plays

AI uses the same legal commands and action application as a human.
There is no separate score-only implementation of playing a card.
It can occupy either seat, but always uses Witcher.

AI Mulligan

Return Spells and Locations first, then the weakest Units by catalogue Strength, up to the seat's limit.
Ascending card ID breaks ties within the same priority.
This replaces the earlier special-card-first mulligan idea.

AI Turn

Motor remembers the score margin at the start of each AI turn :

```text
start_margin = AI board strength - opponent board strength
```

A Stratagem can change the current score, but it does not rewrite this saved starting margin.

The actual decision order is :

1. Use an offered Stratagem when exactly one normal card remains in hand.
2. Use an offered Power if its round condition is met.
3. If End Turn is offered, take it.
4. If Pass Round is offered and a passing condition is met, take it.
5. Otherwise compare normal card plays using simulations.

The normal legality rules still apply. AI doesn't get a second normal play or an extra Power.
After a card or Power, the next decision can still use a qualifying Stratagem before End Turn.

Power conditions :

- Round 1: opponent has not passed, has completed at least one playable turn this round, and AI was ahead at its turn start.
- Round 2: AI's first playable turn, opponent has 1 Crown and AI has 0. A tied round 1 doesn't qualify.
- Round 3: AI's first playable turn, if Power is still unused.

The private completed-turn counters identify these first/completed turns, not the global Turn_number.
The opponent may have played first in a new round while AI still has zero completed turns.

Passing conditions :

- Opponent has zero Crowns and the starting margin is at least +5 or at most -5.
- Or the opponent has passed and AI was ahead at turn start.

Empty-hand passing is already handled by normal Motor progression.
These are fixed conditions, not a general search for whether passing will eventually win the game.

Normal card predictions

For every offered normal card command, AI copies the same current state through apply_command(), applies that one command and refreshes the result.
It then ranks the immediate resulting board margin, AI minus opponent.
It does not simulate the opponent's reply or the rest of a full turn.

The preference is exactly :

```text
+1, 0, -1, +2, -2, +3, -3, ...
```

So a narrow lead is best, but being behind by 1 is preferred to leading by 2.
This intentionally avoids always choosing the biggest immediate lead.
Equal-ranked results use ascending command text for a reproducible choice. For an otherwise identical Unit play, that can favour the front-row code.

Predictions are stored in `ai_prediction/XX/<14-digit-command>.json`.
They contain complete private projected states, not files for Front.
Normal-card simulation includes Spells and Locations, even though they currently have no effect and go to the graveyard.
The choice reads own offers/cards and public scores, crowns and pass status, plus turn bookkeeping. Although the copy is a full private state, this policy does not inspect hidden opponent hand identities or deck order to rank moves.

After a valid AI mulligan, Motor resets that room's prediction folder.
Before each new normal-card evaluation it clears the previous generated predictions for that room.
Special actions don't produce a fresh set of card predictions, so the previous evaluation can remain until the next evaluation or reset.

Cleanup accepts only regular files with generated command filenames. Unknown entries, nested directories and symbolic links cause an error before deletion.
Other rooms are not cleared. PvP does not create prediction folders.

The selected command is applied again through the real engine, then normal state and view publication runs.
Current projected card actions are deterministic. If random effects are added, simulation and replay need a defined random-result policy; otherwise the real play could differ from the chosen prediction.
A 1000-action guard stops unexpected automatic nontermination as an internal error, not as a match turn limit.

## IX) Review of choices made, initial plan and current version

The original objective was to keep something recognizable as Gwent, usable on desktop and phone, without copying either the simpler Witcher 3 game or the full complexity of modern Gwent.
The project joined Lucas and Nima with Quentin and Cyril. The first recorded planning meeting was 31 August 2026.
Lucas and Nima focused on Back, Quentin on Front, and Cyril on the game rules and Motor.
September work focused on the rules, decks and the Front/Back/Motor division, then a working basic engine. AI and upgrades followed in October.

To make the project finishable, the current version keeps the complete match loop and simple abilities before attempting every individual card effect.
On the motor, I underevaluated the time to get Front+Back update after Motor update. In the end it was insisted that we push as early as possible, some consessions were made, motor ambitions were downscale, python learning was rushed.
The current cards therefore don't yet have the interactions or balance expected from their full descriptions.

Main differences from the initial notes

Card effects and deaths

Initially, each card could trigger effects when played, entering the board, dying, entering the graveyard, or at turn/round end.
Currently only the special Power and Stratagem behavior is implemented; normal cards mostly contribute strength or go to the graveyard.

To follow the original plan, add event dispatch at those movement/phase boundaries and separate handlers for each effect.
After damage, check affected Units for death and move them with the corresponding events. Mulligans and AFK removal remain separate from these normal events.
The design notes describe left-to-right handling for simultaneous deaths, but order across players/rows and chained effects still needs precise rules before implementation.

Frost

The planned frost effect deals 2 damage to a highest-strength Unit on the affected row at the owner's turn start, choosing randomly among ties.
It also reduces its duration even on an empty row, including passed-player pseudo-turns.
Current code only reduces duration and maintains the five-own-turn history fields.

A future handler would deal the damage before the duration reduction, record it in the newest history bucket and resolve any resulting deaths.
Stacking, cross-row order and how to count damage beyond a Unit's remaining strength still need definitions.

Locations, Elixir and revival

Locations were intended to remain attached to a row, with effects and potentially a changed field appearance.
Currently they are discarded to the graveyard like Spells, without effects.
A full implementation needs a persistent location representation, row attachment, effect handling and a defined destination at round end.
A Location with zero strength must not be confused with a dead Unit.
Elixir_left and Revived similarly need their timed effects and exceptions to ordinary cleanup; just having these fields does not implement them.

Commander and Stratagem

The original turn outline allowed a Commander plus a normal card, with more individual ability behavior.
The current Power is instead a once-per-game draw that replaces the normal play.
Both Stratagem choices use the same simple conditional +5 board bonus.

Richer powers would need their own availability checks, handlers and command offers. Restoring a Commander alongside normal play would also require separate tracking instead of consuming Card_has_been_played.
An individual-card Stratagem boost would change a card's strength rather than Round_Bonus, and Front would need those per-card changes in its view.
These are possible extensions, not the current rules.

Passing and ending turns

The initial notes said no remaining actions could automatically end a turn and an empty hand could pass as soon as the turn ended.
Current human turns require explicit End Turn after normal play/Power, and empty-hand passing is checked at the player's own turn start.
Pseudo-turns preserve the place for future effects after a player passes.
Changing those timings would mean changing offer generation and advance_to_input(), including their interactions with Stratagem and timeouts.

Targeting and placement

The original target zone/position proposal was replaced by the fixed-seat target token described in section V.
Current commands still have no target and append cards to their row.
Selectable insertion positions could use the placement field, insert into the row list, then let refresh_state() renumber locations.
That would need legal position offers and defined limits. Multiple-target or follow-up choices are separate work.

Player views and catalogue

Starting from a permitted-field template replaced copying everything and removing secrets.
That is the current view design, not a temporary missing feature. It can be extended by adding the specific safe fields Front needs.
JSON replaced the proposed library.db. A database-backed catalogue would need a loader returning the same card data, but storing effects in a database would still not execute them without Python handlers.

AI strategy

Initially the AI would look for the largest score gap, perhaps adding extra value for card effects and avoiding a losing pass.
The current policy uses separate special-action conditions and the exact small-margin ordering in section VIII.
To try the initial strategy, replace margin_rank() with the chosen score/value evaluation and revise the pass policy. Searching a full turn or replies would also require deeper simulations rather than evaluating one card action.

Errors, saving and disconnections

An invalid command originally meant the sender should lose. Current code rejects it without a loss or room writes.
Account misconduct can't be established from a numeric command alone, so it is separate from game-command validation.
The old crash code 5 is not a guaranteed process result.

Cancellation on internal failure remains the current saving policy. Resuming after a partial save would need a complete recoverable publication design, not just retrying three independent file writes.
Disconnect defeat/reconnection also needs a defined Back policy and an appropriate game event if Motor is expected to record that result.
A timer alone is not a disconnect decision.

## X) Brief review of the Python files

The code is split by responsibility. The current form uses explicit loops and branches with learning notes in comments, while keeping the same game behavior and variable names.
Read motor.py first for the overall flow, then the files it calls.

motor.py

This is the entry point. main() reads I/M/P/T and converts the outcome or an exception into an exit code.
parse_players() validates initialization tokens.
initialize() creates the match from templates and deals the opening hands.
mulligan_commands() builds card-selection codes using combinations.
player_view() builds a filtered copy using the matching player template.
write_room() refreshes state, updates offers and saves XXM/XX1/XX2.
mulligan() and play() load the current files and call the relevant rules.
publish_and_run_ai() saves and continues automatic play until a human or final result is reached.
read_json() loads a JSON object; refresh_cards() keeps a compatibility name for refresh_state().

mulligan.py

Defines InvalidCommand and StateError, shared by the other files.
validate_state() checks the opening state and saved views.
ai_selection() ranks the AI's opening returns.
resolve_mulligans() validates the submitted choices, copies state and applies both exchanges before turn setup.

game_state.py

ensure_turn_fields() supplies defaults for missing tracking fields without overwriting existing values. This is not a full save migration.
refresh_state() validates zone records and recalculates locations, strengths, counts, faction flags, statuses and frost totals.
It edits the supplied dictionary directly. The action routines choose when to pass it an independent copy.

turns.py

action_code() builds the ordinary command string; card_type() reads a catalogue type.
legal_commands() generates the currently allowed actions.
normal_hand() excludes the Stratagem from normal-card checks.
first_turn(), start_turn(), finish_turn() and advance_to_input() control turn progression.
resolve_round() awards crowns, checks the result, cleans up and prepares another round if needed.
end_game() sets the result and clears priority; result_code() translates it for Back.
validate_turn_state() checks state and views before action processing.
apply_command() and apply_timeout() return an independently modified state for the caller to save.

ai.py

prediction_folder() checks and clears this room's generated prediction files.
special_command() handles the Stratagem, Power, End Turn and Pass priorities.
margin_rank() gives each score difference its preference rank.
choose_command() simulates normal plays when needed and returns the selected offered command.

The JSON files

motor_game_state_template.json supplies initial private fields and mutable card records.
The two player templates define what each view can contain.
library.json supplies the static catalogue. None of these files replaces the actual game-rule functions.


## XI) AI usage and sources

I used official rules of Gwent to get inspiration and make the Games rules adapted to the project scale. After that I constructed many read.me and a large scale pseudo code.  I used LLM to try to learn and convert the pseudo code into actual Python code. It also suggested more security and tools specific to python to improve structure of the code.  So AI was used as a co-pilot to be able to transcribe in python the logic of the function of the pseudo code of the different functions. It challenged me, and I asked it questions to understand at best. Because of poor time left available, many thing had to but cut off initial scale, so was the learning. I worked without a front because of delays and compatibility problem with my current hardware, so I relied on AI for testing, I needed to implement extra code to run local tests built by AI, I didn't remove them because of dependencies. I also used AI to compile my readmes and my notes into something this more digest readme because the notes were scattered in many files and not well made for a foreign mind. I also used to get quizzed and for training purpose.

## XII) Python Module

The intention behind is to module was to learn a new code language that seemed challenging and usefull.
Python has really powerfull tools as long as you are aware of them and their syntax.
It is way easier to manage the data and files than in C, to access them, to organize them etc..
It was difficult because I started from scratch. I decided to do reverse learning, pseudo coding the whole infrastructure
first, and get llm to help figure out and learn the answer on how to do it with Python, and learn all the specific tools we cas
use in python and try to make use of them to solve the challenges than what I was used to with C.