import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import cookieParser from 'cookie-parser';
import { AppModule } from './app.module.js';

async function bootstrap() {
	const app = await NestFactory.create(AppModule);

	// Lit le cookie contenant le JWT (voir auth/auth.controller.ts
	app.use(cookieParser());

	// credentials: true = necessaire pour que le navigateur envoie/accepte
	// le cookie httpOnly depuis le frontend
	// ATTENTION psq * est interdit par les navigateurs dès qu'on utilise credentials
	app.enableCors({
		origin: process.env.FRONTEND_ORIGIN ?? 'http://localhost:5173',
		credentials: true,
	});

	app.useGlobalPipes(
	new ValidationPipe({
		whitelist: true, // supprime les champs non déclarés dans le DTO
		forbidNonWhitelisted: true, // rejette la requête si un champ en trop est présent
	}),
	);

	// swagger https://localhost:8443/api/docs
	const config = new DocumentBuilder()
		.setTitle('API publique Gwentscendance')
		.setDescription(
			"API pour script externe (pas pour le front). Authentification par clée API = " +
			'header "X-API-Key: <your key here>", obtenue via POST /account/api-keys (connecté au site)',
		)
		.setVersion('1.1')
		.addApiKey({ type: 'apiKey', name: 'X-API-Key', in: 'header' }, 'X-API-Key')

		// nginx route que ce qui commence par /api/ le reste au front
		// dcp applelerait /auth/signup et pas /api/auth/signup (ret 405)
		.addServer('/api')
		.build();
	const document = SwaggerModule.createDocument(app, config);
	SwaggerModule.setup('docs', app, document);

	await app.listen(process.env.PORT ?? 3000);
}
await bootstrap();
