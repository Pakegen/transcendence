import { Injectable, Logger } from '@nestjs/common';
import nodemailer from 'nodemailer';

// SMTP_HOST pointe vers mailhog
// interface sur :8025
// changer env pour changer de serveur SMTP genre gmail
@Injectable()
export class MailService
{
	private readonly logger = new Logger(MailService.name);

	private readonly transporter = nodemailer.createTransport(
	{
		host: process.env.SMTP_HOST ?? 'mailhog',
		port: Number(process.env.SMTP_PORT ?? 1025),
		secure: false, //ps de tls pour mailhog, true pr gmail ?
	});

	// Best-effort : un email qui echoue (SMTP down, domaine invalide...) ne
	// doit jamais faire echouer l'operation qui l'a declenchee (suppr/export)
	// si mail echoue, ne fait ps échouer l'operation qui l'a declenchee juste log
	async envoyer(destinataire: string, sujet: string, texte: string)
	{
		try
		{
			await this.transporter.sendMail({
				from: process.env.MAIL_FROM ?? 'no-reply@gwent.local',
				to: destinataire,
				subject: sujet,
				text: texte,
			});
		}
		catch (error)
		{
			this.logger.warn(`Echec envoi email a ${destinataire} : ${error}`);
		}
	}
}
