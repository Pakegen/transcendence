// Echoue au demarrage plutot que de tourner silencieusement avec une
// variable manquante (ex: JWT_SECRET undefined -> tokens signes avec "undefined")
export function requireEnv(name: string): string {
	const value = process.env[name];
	if (!value) throw new Error(`Variable d'environnement manquante: ${name}`);
	return value;
}
