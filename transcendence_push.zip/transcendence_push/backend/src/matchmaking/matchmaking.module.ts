import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { requireEnv } from '../env.js';
import { GameModule } from '../game/game.module.js';
import { MatchmakingGateway } from './matchmaking.gateway.js';

@Module({
	// JwtService pr le token du cookie a la conn socket ; GameModule pr lancer/piloter
	// la partie une fois l'adversaire trouve
	imports: [JwtModule.register({ secret: requireEnv('JWT_SECRET') }), GameModule],
	providers: [MatchmakingGateway],
})
export class MatchmakingModule {}
