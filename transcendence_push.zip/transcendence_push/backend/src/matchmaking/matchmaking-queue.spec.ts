import { MatchmakingQueue } from './matchmaking-queue.js';

// Crée un joueur de test (id 1 -> socket "socket-1")
function makePlayer(userId: number) {
	return { userId, username: `joueur${userId}`, socketId: `socket-${userId}`, faction: 'Witcher' };
}

describe('MatchmakingQueue', () => {
	it('file vide: takeFirst renvoie undefined', () => {
		const queue = new MatchmakingQueue();
		expect(queue.takeFirst()).toBeUndefined();
	});

	it("le premier arrivé est le premier sorti (ordre d'arrivée)", () => {
		const queue = new MatchmakingQueue();
		const player1 = makePlayer(1);
		const player2 = makePlayer(2);
		queue.add(player1);
		queue.add(player2);

		// toBe = c'est exactement le même joueur qu'on a ajouté
		expect(queue.takeFirst()).toBe(player1);
		expect(queue.takeFirst()).toBe(player2);
		expect(queue.takeFirst()).toBeUndefined();
	});

	it('isQueued dit si un joueur est dans la file', () => {
		const queue = new MatchmakingQueue();
		queue.add(makePlayer(1));

		expect(queue.isQueued(1)).toBe(true);
		expect(queue.isQueued(2)).toBe(false);
	});

	it('takeFirst retire le joueur de la file', () => {
		const queue = new MatchmakingQueue();
		queue.add(makePlayer(1));
		queue.takeFirst();

		expect(queue.isQueued(1)).toBe(false);
		expect(queue.size()).toBe(0);
	});

	it('removeByUser retire seulement ce joueur', () => {
		const queue = new MatchmakingQueue();
		queue.add(makePlayer(1));
		queue.add(makePlayer(2));
		queue.removeByUser(1);

		expect(queue.isQueued(1)).toBe(false);
		expect(queue.isQueued(2)).toBe(true);
	});

	it('removeBySocket retire seulement ce joueur', () => {
		const queue = new MatchmakingQueue();
		queue.add(makePlayer(1));
		queue.add(makePlayer(2));
		queue.removeBySocket('socket-2');

		expect(queue.isQueued(1)).toBe(true);
		expect(queue.isQueued(2)).toBe(false);
	});
});
