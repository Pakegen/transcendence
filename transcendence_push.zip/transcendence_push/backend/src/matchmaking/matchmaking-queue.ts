// Un joueur qui attend un adversaire
export type WaitingPlayer = {
	userId: number;
	username: string;
	socketId: string; // identifiant de sa connexion socket (pour lui envoyer des messages)
	faction: string; // deck choisi: 'Witcher' ou 'Wild_Hunt'
};

// file d'att : ordre d'arrivée
// Cette classe ne connaît pas les sockets, on fait juste une liste pr check facilement
export class MatchmakingQueue {
	private waiting: WaitingPlayer[] = [];

	isQueued(userId: number) {
		for (const player of this.waiting)
		{
			if (player.userId === userId) {return true;}
		}
		return false;
	}


	add(player: WaitingPlayer) {
		this.waiting.push(player);
	}

	// (shift = enlève le 1er elem) == undefined si la file est vide.
	takeFirst() {return this.waiting.shift();}

	// filter = garde seulement les joueurs qui respectent la condition
	// "=>" = func anonyme (player) => player.userId !== userId
	removeByUser(userId: number) {this.waiting = this.waiting.filter((player) => player.userId !== userId);}

	// utilisé quand ferme la page
	removeBySocket(socketId: string)
		{this.waiting = this.waiting.filter((player) => player.socketId !== socketId);}

	size() {return this.waiting.length;}
}
