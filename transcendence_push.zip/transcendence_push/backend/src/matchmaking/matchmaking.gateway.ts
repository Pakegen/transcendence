import { JwtService } from '@nestjs/jwt';

import {
	ConnectedSocket,
	MessageBody,
	SubscribeMessage,
	WebSocketGateway,
	WebSocketServer,
} from '@nestjs/websockets';


import type { Server, Socket } from 'socket.io';
import { GameService } from '../game/game.service.js';
import type { GamePlayer } from '../game/game.service.js';
import { MatchmakingQueue } from './matchmaking-queue.js';
import type { WaitingPlayer } from './matchmaking-queue.js';

////// A VOIR AVEC LES GARS + Si client envoie rien = par défaut
const FACTIONS = ['Witcher', 'Wild_Hunt'];
const DEFAULT_FACTION = 'Witcher';

// cherche dans l'entete cookie le name passé et renvoie sa valeur ou null
function readCookie(header: string | undefined, name: string): string | null
{
	if (!header) {return null;}

	for (const part of header.split(';'))
	{
		const separator = part.indexOf('=');
		if (separator === -1) {continue;}

		if (part.slice(0, separator).trim() === name) {return part.slice(separator + 1).trim();}
	}
	return null;
}

// Lit la faction envoyée par le front dans queue:join (genre { faction: 'Witcher' })
// Le client peut envoyer n'importe quoi donc attention (on met par défaut du coup)
// body en type any vu qu'on sait pas ce qu'on manipule
// includes = true que si body.faction est dans FACTIONS
function readFaction(body: any): string {
	if (body && FACTIONS.includes(body.faction)) {return body.faction;}
	return DEFAULT_FACTION;
}

// /api/socket.io
// Le CORS ne sert que pour le serveur de dev Vite
// MAIS en prod tout est sur la même origine (a BIEN CHECKER)
@WebSocketGateway({
	cors: { origin: process.env.FRONTEND_ORIGIN ?? 'http://localhost:5173', credentials: true },
})
// afterInit et handleDisconnect sont appelées automatiquement par Nest
export class MatchmakingGateway {
	// le serveur Socket.IO (sert à envoyer un message à un autre joueur
	@WebSocketServer()
	private readonly server: Server;

	private readonly queue = new MatchmakingQueue();

	// Partie géree ds GameService ici uniquement file d'att + relais cmds
	constructor(
		private readonly jwt: JwtService,
		private readonly game: GameService,
	) {}

	// call une fois au démarrage == on ajoute une vérification pr tt nouvelle conn
	// Sans cookie err "connect_error"
	afterInit(server: Server)
	{
		server.use((socket, next) =>
		{
			const token = readCookie(socket.handshake.headers.cookie, 'access_token');
			if (!token)
			{
				next(new Error('unauthorized'));
				return;
			}

			try
			{
				// verify = signature et date d'exp token, err sinon
				const check = this.jwt.verify(token);

				// on garde l'id et le pseudo sur la connexion pour savoir qui parle ensuite
				socket.data.userId = check.sub;
				socket.data.username = check.username;
				next(); // next = on continue la connexion
			} catch { next(new Error('unauthorized'));}
		});
	}

	// recherche
	@SubscribeMessage('queue:join')
	async handleJoin(@ConnectedSocket() client: Socket, @MessageBody() body: any) {
		const userId = client.data.userId;
		const username = client.data.username;


		if (body && body.vsAI === true)
		{
			if (await this.game.hasActiveSessionBlocking(userId))
			{
				client.emit('queue:error', { message: 'Vous avez déjà une partie en cours ' });
				return;
			}

			const human: GamePlayer = {
				userId: userId,
				username: username,
				socketId: client.id,
				faction: readFaction(body),
			};


			const room = await this.game.createSessionVsAI(this.server, human);
			if (!room)
			{
				client.emit('queue:error', { message: 'Impossible de démarrer la partie !' });
				return;
			}

			client.emit('match:found', { gameId: room, opponent: 'IA' });
			return;
		}


		if (await this.game.hasActiveSessionBlocking(userId))
		{
			client.emit('queue:error', { message: 'Vous avez déjà une partie en cours ' });
			return;
		}


		if (this.queue.isQueued(userId))
		{
			client.emit('queue:error', { message: "Déjà dans la file d'attente !" });
			return;
		}

		const me: WaitingPlayer = {
			userId: userId,
			username: username,
			socketId: client.id,
			faction: readFaction(body),
		};

		// si qlq att déjà
		const opponent = this.queue.takeFirst();
		if (!opponent)
		{
			this.queue.add(me);
			client.emit('queue:joined');
			return;
		}

		// Oui = Le joueur 1 (celui qui commence tiré hasard)
		let player1 = opponent;
		let player2 = me;
		if (Math.random() < 0.5)
		{
			player1 = me;
			player2 = opponent;
		}

		// Alloc salle, launch moteur (I)
		// null = 100 salles prises ou echec (ajouter autre salle pour les échecs ?)
		const room = await this.game.createSession(this.server, player1, player2);
		if (!room)
		{
			const message = "Impossible de démarrer la partie";
			client.emit('queue:error', { message });
			this.server.to(opponent.socketId).emit('queue:error', { message });
			return ;
		}


		// échange des pseudos (1 vers 2 2 vers 1), GameService envoie la 1er vue après game:state
		client.emit('match:found', { gameId: room, opponent: opponent.username });
		this.server.to(opponent.socketId).emit('match:found', { gameId: room, opponent: me.username });
	}

	// annulation
	@SubscribeMessage('queue:leave')
	handleLeave(@ConnectedSocket() client: Socket) {this.queue.removeByUser(client.data.userId);}



	// apl auto qd une connexion réussit si partie en cours et reconnexion, on la reprend au lieu de laisser bloqué
	handleConnection(client: Socket) {this.game.reconnect(this.server, client.data.userId, client.id);}

	// commande envoyee par un joueur pendant une partie (mulligan ou action de tour
	@SubscribeMessage('game:action')
	handleAction(@ConnectedSocket() client: Socket, @MessageBody() body: any)
	{
		const room = body?.room;
		const code = body?.code;
		if (typeof room !== 'string' || typeof code !== 'string') return ;
		void this.game.submitAction(this.server, room, client.data.userId, code);
	}


	// co perdue ou autre, adversaire prévenu avec game:opponent-left son timer fera le reste
	handleDisconnect(client: Socket)
	{
		this.queue.removeBySocket(client.id);
		this.game.notifyDisconnect(this.server, client.data.userId, client.id);
	}
}
