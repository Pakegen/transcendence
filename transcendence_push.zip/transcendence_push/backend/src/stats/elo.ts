export type EloResult = 'PLAYER1' | 'PLAYER2' | 'DRAW';

const K = 32;


function expectedScore(eloA: number, eloB: number): number {
	return 1 / (1 + 10 ** ((eloB - eloA) / 400));
}

export function calculateElo(elo1: number, elo2: number, result: EloResult) {
	// score réel du joueur 1 : 1 = gagné, 0.5 = égalité, 0 perdu
	let score1 = 0;
	if (result === 'PLAYER1') {
		score1 = 1;
	} else if (result === 'DRAW') {
		score1 = 0.5;
	}

	const delta = Math.round(K * (score1 - expectedScore(elo1, elo2)));


	return { newElo1: elo1 + delta, newElo2: elo2 - delta };
}
