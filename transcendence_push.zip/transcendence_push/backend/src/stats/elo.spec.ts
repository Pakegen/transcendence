import { calculateElo } from './elo.js';

describe('calculateElo', () => {
	it('ELO égaux: le gagnant prend 16 points au perdant', () => {
		expect(calculateElo(1000, 1000, 'PLAYER1')).toEqual({ newElo1: 1016, newElo2: 984 });
		expect(calculateElo(1000, 1000, 'PLAYER2')).toEqual({ newElo1: 984, newElo2: 1016 });
	});

	it('égalité entre ELO égaux: rien ne bouge', () => {
		expect(calculateElo(1000, 1000, 'DRAW')).toEqual({ newElo1: 1000, newElo2: 1000 });
	});

	it('le favori gagne peu de points en battant le plus faible', () => {
		expect(calculateElo(1200, 1000, 'PLAYER1')).toEqual({ newElo1: 1208, newElo2: 992 });
	});

	it("l'outsider gagne beaucoup de points en battant le favori", () => {
		expect(calculateElo(1200, 1000, 'PLAYER2')).toEqual({ newElo1: 1176, newElo2: 1024 });
	});

	it("égalité: le favori perd des points, l'outsider en gagne", () => {
		expect(calculateElo(1200, 1000, 'DRAW')).toEqual({ newElo1: 1192, newElo2: 1008 });
	});

	it("le total d'ELO est conservé", () => {
		const { newElo1, newElo2 } = calculateElo(1337, 1042, 'PLAYER2');
		expect(newElo1 + newElo2).toBe(1337 + 1042);
	});
});
