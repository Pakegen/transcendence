import { Controller, DefaultValuePipe, Get, ParseIntPipe, Query, UseGuards } from '@nestjs/common';
import { CurrentUser } from '../auth/decorators/current-user.decorator.js';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard.js';
import { StatsService } from './stats.service.js';

// Si pas connecté == 401 pas autorisé grace a jwtAuthGuard
@UseGuards(JwtAuthGuard)
@Controller('stats')
export class StatsController {
	constructor(private readonly statsService: StatsService) {}

	@Get('me')
	me(@CurrentUser() user: { id: number }) {
		return this.statsService.getMyStats(user.id);
	}

	// query = permet de passer des paramètres dans l'url genre /stats/history?limit=10
	@Get('history')
	history(
		@CurrentUser() user: { id: number },
		@Query('limit', new DefaultValuePipe(20), ParseIntPipe) limit: number,
	) {
		return this.statsService.getHistory(user.id, limit);
	}

	@Get('leaderboard')
	leaderboard(@Query('limit', new DefaultValuePipe(20), ParseIntPipe) limit: number) {
		return this.statsService.getLeaderboard(limit);
	}
}
