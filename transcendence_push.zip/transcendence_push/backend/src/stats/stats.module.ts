import { Module } from '@nestjs/common';
import { PassportModule } from '@nestjs/passport';
import { StatsController } from './stats.controller.js';
import { StatsService } from './stats.service.js';

@Module({
	// nécessaire pour que JwtAuthGuard fonctionne dans ce module
	imports: [PassportModule.register({ defaultStrategy: 'jwt' })],


	controllers: [StatsController],
	providers: [StatsService],
})
export class StatsModule {}
