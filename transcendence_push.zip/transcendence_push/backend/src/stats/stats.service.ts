import { Injectable } from '@nestjs/common';
// Match == le type d'une ligne de la table Match (gen par Prisma depuis schema.prisma
import type { Match } from '@prisma/client';
import { PrismaService } from '../prisma.service.js';

// Un succès = win avc faction X contre la faction Y + la date de la 1e victoire
type Matchup = {
	myFaction: string;
	opponentFaction: string;
	firstWinAt: Date;
};

// pov joueur = qui suis je ? qui est l'opponent ? win/loose/draw ?
// Dans la db une partie est écrite du point de vue de player1 / player2
// Cette fonction la "retourne" du point de vue du joueur userId
function fromPlayerPoint(match: Match, userId: number) {
	// par défaut je suis player2
	let myFaction = match.faction2;
	let opponentFaction = match.faction1;
	let mySide = 'PLAYER2';

	// si je suis player1, j'inverse
	if (match.player1Id === userId) {
		myFaction = match.faction1;
		opponentFaction = match.faction2;
		mySide = 'PLAYER1';
	}

	// match.result == PLAYER1, PLAYER2 ou DRAW
	let outcome = 'LOSS';
	if (match.result === 'DRAW') {
		outcome = 'DRAW';
	} else if (match.result === mySide) {
		outcome = 'WIN';
	}

	return { myFaction, opponentFaction, outcome };
}

// (évite de demander toute la base d'un coup) limit toujours entre 1 et 100
function clampLimit(limit: number)
{
	if (limit < 1) {
		return 1;
	}
	if (limit > 100) {
		return 100;
	}
	return limit;
}


@Injectable()
export class StatsService {

	constructor(private readonly prisma: PrismaService) {}


	async getMyStats(userId: number)
	{
		// findUniqueOrThrow = cherche UN user (erreur si introuvabl)
		// select = on ne récupère que la colonne elo pas le reste
		const user = await this.prisma.user.findUniqueOrThrow(
		{
			where: { id: userId },
			select: { elo: true },
		});

		// findMany = récupère plusieurs lignes de la table Match
		// where = conditions == player2Id pas null (sinn ça veut dire ia)
		//		ET (j'étais player1 || j'étais player2)
		// ia == pas de succes/elo
		// orderBy 'asc' = acienne => récente
		const matches = await this.prisma.match.findMany(
		{
			where: { player2Id: { not: null }, OR: [{ player1Id: userId }, { player2Id: userId }] },
			orderBy: { playedAt: 'asc' },
		});

		let wins = 0;
		let losses = 0;
		let draws = 0;

		const matchupsWon: Matchup[] = [];// un par faction

		for (const match of matches)
		{
			const pov = fromPlayerPoint(match, userId);

			if (pov.outcome === 'WIN')
			{
				wins++;

				// déjà win le matchup ? find renvoie l'élément trouvé ou sinon undefined
				const alreadyWon = matchupsWon.find(
					(m) => m.myFaction === pov.myFaction && m.opponentFaction === pov.opponentFaction,
				);



				// Si non, c'est ma 1ère victoire de ce matchup: on l'ajoute avec la date de cette partie
				if (!alreadyWon) {
					matchupsWon.push({
						myFaction: pov.myFaction,
						opponentFaction: pov.opponentFaction,
						firstWinAt: match.playedAt,
					});
				}
			}
			else if (pov.outcome === 'LOSS')
				{losses++;}
			else
			{draws++;}
		}

		return { elo: user.elo, wins, losses, draws, matchupsWon };
	}

	// Attention ici garde les partie contre ia
	// ducp incluses dans l'histo, voir si ça convient
	async getHistory(userId: number, limit: number) {
		const matches = await this.prisma.match.findMany(
		{
			where: { OR: [{ player1Id: userId }, { player2Id: userId }] },
			orderBy: { playedAt: 'desc' },

			// take = nombre max de parties renvoyées
			take: clampLimit(limit),


			// include = récupère aussi le pseudo des deux joueurs (jointure avec la table User)
			include:
			{
				player1: { select: { username: true } },
				player2: { select: { username: true } },
			},
		});

		// map = transforme chaque partie de la liste en un objet plus simple pour le front
		return matches.map((match) => {
			const pov = fromPlayerPoint(match, userId);

			// pseudo de l'adversaire (string), ou null si c'est l'ia
			let opponent: string | null = null;
			if (match.player1Id === userId)
			{
				// je suis player1: mon adversaire est player2 (qui peut être null = ia)
				if (match.player2) {
					opponent = match.player2.username;
				}
			}
			else
			{
				// je suis player2: mon adversaire est player1
				opponent = match.player1.username;
			}

			return{
				id: match.id,
				playedAt: match.playedAt,
				myFaction: pov.myFaction,
				opponentFaction: pov.opponentFaction,
				outcome: pov.outcome,
				opponent,
			};
		});
	}

	// Classement de tous les joueurs par ELO
	async getLeaderboard(limit: number)
	{
		const users = await this.prisma.user.findMany({
			// comptes supprimés ps dans le classement
			where: { deleted: false },
			// elo 'desc' = du plus grand au plus petit
			// à ELO égal, le plus ancien compte passe devant ?
			orderBy: [{ elo: 'desc' }, { id: 'asc' }],
			take: clampLimit(limit),
			select: { id: true, username: true, elo: true },
		});

		// index = position dans la liste (0 pour le 1er), donc rang = index + 1
		return users.map((user, index) => {
			return { rank: index + 1, id: user.id, username: user.username, elo: user.elo };
		});
	}
}
