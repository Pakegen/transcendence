import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { PassportModule } from '@nestjs/passport';
import { ThrottlerModule } from '@nestjs/throttler';
import { requireEnv } from '../env.js';
import { AuthController } from './auth.controller.js';
import { AuthService } from './auth.service.js';
import { FortyTwoService } from './forty-two.service.js';
import { JwtStrategy } from './strategies/jwt.strategy.js';
import { TwoFactorService } from './two-factor.service.js';

@Module({
	imports: [
		PassportModule.register({ defaultStrategy: 'jwt' }),
		JwtModule.register({
			secret: requireEnv('JWT_SECRET'),
			// Doit match à  COOKIE_MAX_AGE_MS dans auth.controller aussi
			signOptions: { expiresIn: '7d' },
		}),
		// Limite le nombre de requetes par IP (5/min)
		// ttl = 60k ms == 1 min
		// limit = requetes max
		ThrottlerModule.forRoot([{ ttl: 60_000, limit: 5 }]),
	],
	controllers: [AuthController],
	providers: [AuthService, JwtStrategy, TwoFactorService, FortyTwoService],
})
export class AuthModule {}
