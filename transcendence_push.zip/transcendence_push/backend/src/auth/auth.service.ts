import { ConflictException, Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as argon2 from 'argon2';
import { PrismaService } from '../prisma.service.js';
import type { LoginDto } from './dto/login.dto.js';
import type { SignupDto } from './dto/signup.dto.js';
import { normalizeEmail } from './normalize-email.js';
import { TwoFactorService } from './two-factor.service.js';

type UserRecord = { id: number; email: string; username: string; twoFactorEnabled: boolean };

// Type du JWT intermediaire entre "mot de passe ok" et "code 2FA ok".
// JwtStrategy refuse ce type : il ne vaut jamais une session
export const TWO_FACTOR_PENDING = '2fa_pending';

// PAS DE RENVOI DU HASH NI DU SECRET 2FA AU FRONT
export function toPublicUser(user: UserRecord) {
	return {
		id: user.id,
		email: user.email,
		username: user.username,
		twoFactorEnabled: user.twoFactorEnabled,
	};
}

@Injectable()
export class AuthService {
	constructor(
		private readonly prisma: PrismaService,
		private readonly jwt: JwtService,
		private readonly twoFactor: TwoFactorService,
	) {}

	async signup(dto: SignupDto) {
		const email = normalizeEmail(dto.email);
		const [emailTaken, usernameTaken] = await Promise.all([
			this.prisma.user.findUnique({ where: { email } }),
			this.prisma.user.findUnique({ where: { username: dto.username } }),
		]);
		if (emailTaken) throw new ConflictException('Cet email est deja utilise.');
		if (usernameTaken) throw new ConflictException('Ce pseudo est deja pris.');

		const hash = await argon2.hash(dto.password);
		let user;
		try {
			user = await this.prisma.user.create({
				data: { email, username: dto.username, password: hash },
			});
		} catch (error: any) {
			// P2002 = contrainte unique : email/pseudo pris entre temps par une autre requete
			if (error?.code === 'P2002') throw new ConflictException('Email ou pseudo deja pris.');
			throw error;
		}

		return { user: toPublicUser(user), token: this.signToken(user.id, user.username) };
	}

	async login(dto: LoginDto) {
		const user = await this.prisma.user.findUnique({ where: { email: normalizeEmail(dto.email) } });

		// Même message que l'email soit inconnu ou le mot de passe faux pr eviter de réveler quels emails sont inscrits
		// password null == compte cree via OAuth 42, il n'a pas de mot de passe
		if (!user || !user.password || !(await argon2.verify(user.password, dto.password))) {
			throw new UnauthorizedException('Email ou mot de passe incorrect.');
		}

		return this.openSession(user);
	}

	// Identite deja prouvee (mot de passe ou OAuth 42) : ouvre la session,
	// ou si la 2FA est active, pas encore de session, juste un token court
	// qui permet d'appeler /auth/2fa/verify dans les 5 min
	openSession(user: UserRecord) {
		if (user.twoFactorEnabled) {
			const pendingToken = this.jwt.sign({ sub: user.id, type: TWO_FACTOR_PENDING }, { expiresIn: '5m' });
			return { twoFactorRequired: true as const, pendingToken };
		}

		return { twoFactorRequired: false as const, user: toPublicUser(user), token: this.signToken(user.id, user.username) };
	}

	// 2e etape du login quand la 2FA est active
	async verifyTwoFactorLogin(pendingToken: string | undefined, code: string) {
		const expired = new UnauthorizedException('Session expiree, reconnectez-vous.');
		if (!pendingToken) throw expired;

		let payload: { sub: number; type?: string };
		try {
			payload = this.jwt.verify(pendingToken);
		} catch {
			throw expired;
		}
		if (payload.type !== TWO_FACTOR_PENDING) throw expired;

		const user = await this.prisma.user.findUnique({ where: { id: payload.sub } });
		if (!user?.twoFactorEnabled || !user.twoFactorSecret) throw expired;
		if (!(await this.twoFactor.verifyCode(user.twoFactorSecret, code))) {
			throw new UnauthorizedException('Code invalide.');
		}

		return { user: toPublicUser(user), token: this.signToken(user.id, user.username) };
	}

	private signToken(userId: number, username: string) {
		return this.jwt.sign({ sub: userId, username });
	}
}
