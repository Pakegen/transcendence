import { generate } from 'otplib';
import type { PrismaService } from '../prisma.service.js';
import { TwoFactorService } from './two-factor.service.js';

type FakeUser = { id: number; username: string; twoFactorSecret: string | null; twoFactorEnabled: boolean };

// Faux Prisma en memoire : juste les 2 methodes utilisees par le service
function makeService(user: FakeUser) {
	const prisma = {
		user: {
			findUniqueOrThrow: async () => ({ ...user }),
			update: async ({ data }: { data: Partial<FakeUser> }) => Object.assign(user, data),
		},
	} as unknown as PrismaService;
	return new TwoFactorService(prisma);
}

describe('TwoFactorService', () => {
	it('setup: stocke un secret, renvoie un QR code, sans activer la 2FA', async () => {
		const user: FakeUser = { id: 1, username: 'bob', twoFactorSecret: null, twoFactorEnabled: false };
		const { qrCode, secret } = await makeService(user).generateSetup(1);

		expect(qrCode.startsWith('data:image/png;base64,')).toBe(true);
		expect(user.twoFactorSecret).toBe(secret);
		expect(user.twoFactorEnabled).toBe(false);
	});

	it('enable: refuse un mauvais code, accepte le bon', async () => {
		const user: FakeUser = { id: 1, username: 'bob', twoFactorSecret: null, twoFactorEnabled: false };
		const service = makeService(user);
		const { secret } = await service.generateSetup(1);

		await expect(service.enable(1, '000000')).rejects.toThrow('Code invalide.');
		expect(user.twoFactorEnabled).toBe(false);

		await service.enable(1, await generate({ secret }));
		expect(user.twoFactorEnabled).toBe(true);
	});

	it('disable: efface le secret avec un code valide', async () => {
		const user: FakeUser = { id: 1, username: 'bob', twoFactorSecret: null, twoFactorEnabled: false };
		const service = makeService(user);
		const { secret } = await service.generateSetup(1);
		await service.enable(1, await generate({ secret }));

		await service.disable(1, await generate({ secret }));
		expect(user.twoFactorEnabled).toBe(false);
		expect(user.twoFactorSecret).toBeNull();
	});

	it("enable: refuse si le setup n'a pas ete fait", async () => {
		const user: FakeUser = { id: 1, username: 'bob', twoFactorSecret: null, twoFactorEnabled: false };
		await expect(makeService(user).enable(1, '123456')).rejects.toThrow("Lancez d'abord");
	});
});
