import { Injectable } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

// Valable pour toutes les routes qui veulent une auth ?? (à voir)
@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {}
