import { BadRequestException, Injectable, UnauthorizedException } from '@nestjs/common';
import { generateSecret, generateURI, verify } from 'otplib';
import QRCode from 'qrcode';
import { PrismaService } from '../prisma.service.js';

// Nom affiche dans l'appli d'authentification (Google Authenticator, Authy...)
const ISSUER = 'Gwent';

// TOTP (RFC 6238) : le serveur et l'appli partagent un secret, et calculent
// chacun HMAC(secret, heure / 30s) -> meme code a 6 chiffres des deux cotes.
// Aucun service externe ni cle API : tout se passe ici et dans le telephone.
@Injectable()
export class TwoFactorService {
	constructor(private readonly prisma: PrismaService) {}

	// Tolere 30s de decalage d'horloge entre le serveur et le telephone,
	// + le cas ou l'utilisateur tape le code juste avant qu'il change
	async verifyCode(secret: string, code: string): Promise<boolean> {
		const result = await verify({ secret, token: code, epochTolerance: 30 });
		return result.valid;
	}

	// Etape 1 de l'activation : genere un secret et le QR code a scanner.
	// La 2FA n'est PAS encore active (voir enable), sinon un utilisateur qui
	// ferme la page sans scanner se retrouverait bloque dehors
	async generateSetup(userId: number) {
		const user = await this.prisma.user.findUniqueOrThrow({ where: { id: userId } });
		if (user.twoFactorEnabled) throw new BadRequestException('La 2FA est deja activee.');

		const secret = generateSecret();
		await this.prisma.user.update({ where: { id: userId }, data: { twoFactorSecret: secret } });

		// fabrique une adresse de la forme otpauth://totp/Gwent:pseudo?secret=...&issuer=Gwent,
		// que les applis savent lire.
		const uri = generateURI({ issuer: ISSUER, label: user.username, secret });
		// data:image/png;base64,... directement utilisable dans un <img src>
		const qrCode = await QRCode.toDataURL(uri);
		// secret renvoye aussi en clair pour la saisie manuelle dans l'appli
		return { qrCode, secret };
	}

	// Etape 2 : l'utilisateur prouve qu'il a bien enregistre le secret
	async enable(userId: number, code: string) {
		const user = await this.prisma.user.findUniqueOrThrow({ where: { id: userId } });
		if (user.twoFactorEnabled) throw new BadRequestException('La 2FA est deja activee.');
		if (!user.twoFactorSecret) throw new BadRequestException("Lancez d'abord la configuration de la 2FA.");
		if (!(await this.verifyCode(user.twoFactorSecret, code))) throw new UnauthorizedException('Code invalide.');

		await this.prisma.user.update({ where: { id: userId }, data: { twoFactorEnabled: true } });
		return { twoFactorEnabled: true };
	}

	// Code exige pour desactiver : un cookie de session vole ne suffit pas
	async disable(userId: number, code: string) {
		const user = await this.prisma.user.findUniqueOrThrow({ where: { id: userId } });
		if (!user.twoFactorEnabled || !user.twoFactorSecret) throw new BadRequestException("La 2FA n'est pas activee.");
		if (!(await this.verifyCode(user.twoFactorSecret, code))) throw new UnauthorizedException('Code invalide.');

		await this.prisma.user.update({
			where: { id: userId },
			data: { twoFactorEnabled: false, twoFactorSecret: null },
		});
		return { twoFactorEnabled: false };
	}
}
