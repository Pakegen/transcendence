import { IsString, Matches } from 'class-validator';

export class TwoFactorCodeDto {
	@IsString()
	@Matches(/^\d{6}$/, { message: 'Le code doit contenir exactement 6 chiffres.' })
	code: string;
}
