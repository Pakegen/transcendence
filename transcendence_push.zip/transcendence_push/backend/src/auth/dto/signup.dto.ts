import { IsEmail, IsString, Matches, MaxLength, MinLength } from 'class-validator';

// Checks demandés par le subject pr les validations des str
export class SignupDto {
	@IsEmail()
	@MaxLength(254)
	email: string;

	@IsString()
	@MinLength(3)
	@MaxLength(20)
	// regex pr autoriser que lettres, chiffres, "_" et "-" ds le pseudo
	@Matches(/^[a-zA-Z0-9_-]+$/, {
		message: 'Le pseudo ne peut contenir que des lettres, chiffres, "_" et "-".',
	})
	username: string;

	@IsString()
	@MinLength(8)
	@MaxLength(128)
	password: string;
}
