import { createParamDecorator, type ExecutionContext } from '@nestjs/common';

// Lit req.user, rempli par JwtStrategy.validate une fois le JwtAuthGuard passe
export const CurrentUser = createParamDecorator((_: unknown, ctx: ExecutionContext) => {
	return ctx.switchToHttp().getRequest().user;
});
