import { randomBytes } from 'node:crypto';
import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma.service.js';
import { normalizeEmail } from './normalize-email.js';

const INTRA = 'https://api.intra.42.fr';

// Codes renvoyes au front dans /connexion?erreur=<code> (voir docs/OAuth42-frontend.md)
export type FortyTwoErrorCode = 'oauth_indisponible' | 'oauth_refuse' | 'oauth_state' | 'oauth_echec' | 'email_pris';

export class FortyTwoError extends Error {
	constructor(readonly code: FortyTwoErrorCode) {
		super(code);
	}
}

export type FortyTwoProfile = { id: number; login: string; email: string };

// Pseudos a essayer pour un nouveau compte 42, dans l'ordre : le login 42,
// puis login-42, puis login-xxxx aleatoire. Toujours conforme au SignupDto
// (3 a 20 caracteres, lettres/chiffres/_/-)
export function usernameCandidates(login: string): string[] {
	let base = login.replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 20);
	if (base.length < 3) base = 'joueur';
	const candidates = [base, `${base.slice(0, 17)}-42`];
	for (let i = 0; i < 5; i++) candidates.push(`${base.slice(0, 15)}-${randomBytes(2).toString('hex')}`);
	return candidates;
}

// OAuth 2.0 "authorization code" avec l'intra 42 :
// 1. /auth/42 envoie l'utilisateur sur la page d'autorisation de l'intra
// 2. l'intra le renvoie sur /auth/42/callback avec un code temporaire
// 3. le back echange ce code contre un access token (avec le SECRET, jamais expose au navigateur)
// 4. le back lit le profil /v2/me avec ce token puis ouvre NOTRE session (cookie access_token)
// Le token 42 n'est jamais stocke : il ne sert qu'a lire le profil une fois
@Injectable()
export class FortyTwoService {
	constructor(private readonly prisma: PrismaService) {}

	// Lu a la demande et pas au demarrage : un backend sans cles 42 dans le
	// .env demarre quand meme, seul le login 42 est indisponible
	private config() {
		const clientId = process.env.FORTY_TWO_CLIENT_ID;
		const clientSecret = process.env.FORTY_TWO_CLIENT_SECRET;
		const callbackUrl = process.env.FORTY_TWO_CALLBACK_URL;
		if (!clientId || !clientSecret || !callbackUrl) throw new FortyTwoError('oauth_indisponible');
		return { clientId, clientSecret, callbackUrl };
	}

	// state = valeur aleatoire renvoyee telle quelle par l'intra, comparee au
	// cookie au retour : empeche un attaquant de faire finir SA connexion 42
	// dans le navigateur de la victime (CSRF)
	authorizeUrl(state: string) {
		const { clientId, callbackUrl } = this.config();
		const params = new URLSearchParams({
			client_id: clientId,
			redirect_uri: callbackUrl,
			response_type: 'code',
			// public = lecture du profil seulement, rien d'autre
			scope: 'public',
			state,
		});
		return `${INTRA}/oauth/authorize?${params.toString()}`;
	}

	async exchangeCode(code: string): Promise<string> {
		const { clientId, clientSecret, callbackUrl } = this.config();
		const response = await fetch(`${INTRA}/oauth/token`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({
				grant_type: 'authorization_code',
				client_id: clientId,
				client_secret: clientSecret,
				code,
				// doit etre identique a celui de l'etape 1, sinon l'intra refuse
				redirect_uri: callbackUrl,
			}),
			signal: AbortSignal.timeout(10_000),
		});
		if (!response.ok) throw new FortyTwoError('oauth_echec');
		const body = (await response.json()) as { access_token?: string };
		if (!body.access_token) throw new FortyTwoError('oauth_echec');
		return body.access_token;
	}

	async fetchProfile(accessToken: string): Promise<FortyTwoProfile> {
		const response = await fetch(`${INTRA}/v2/me`, {
			headers: { Authorization: `Bearer ${accessToken}` },
			signal: AbortSignal.timeout(10_000),
		});
		if (!response.ok) throw new FortyTwoError('oauth_echec');
		const { id, login, email } = (await response.json()) as Partial<FortyTwoProfile>;
		if (typeof id !== 'number' || !login || !email) throw new FortyTwoError('oauth_echec');
		return { id, login, email };
	}

	async findOrCreateUser(profile: FortyTwoProfile) {
		// Deja connecte via 42 avant (deleteAccount remet fortyTwoId a null,
		// donc un compte supprime ne peut pas ressortir ici)
		const linked = await this.prisma.user.findUnique({ where: { fortyTwoId: profile.id } });
		if (linked) {
			if (linked.deleted) throw new FortyTwoError('oauth_echec');
			return linked;
		}

		// Pas de liaison automatique avec un compte mot de passe du meme email :
		// l'inscription ne verifie pas les emails, n'importe qui pourrait donc
		// creer un compte avec l'email 42 de quelqu'un d'autre et recuperer
		// son acces le jour ou cette personne se connecte via 42
		const email = normalizeEmail(profile.email);
		const sameEmail = await this.prisma.user.findUnique({ where: { email } });
		if (sameEmail) throw new FortyTwoError('email_pris');

		for (const username of usernameCandidates(profile.login)) {
			const taken = await this.prisma.user.findUnique({ where: { username } });
			if (taken) continue;
			try {
				return await this.prisma.user.create({
					data: { fortyTwoId: profile.id, email, username, password: null },
				});
			} catch (error: any) {
				// P2002 = contrainte unique : pseudo pris entre temps par une autre requete
				if (error?.code !== 'P2002') throw error;
			}
		}
		throw new FortyTwoError('oauth_echec');
	}
}
