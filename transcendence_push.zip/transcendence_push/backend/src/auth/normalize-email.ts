// Les emails sont stockes et compares en minuscules : "Toto@Mail.com" == "toto@mail.com"
// sinon @unique (sensible a la casse) laisse passer 2 comptes pour la meme adresse
export function normalizeEmail(email: string) {
	return email.trim().toLowerCase();
}
