import type { PrismaService } from '../prisma.service.js';
import { FortyTwoService, usernameCandidates } from './forty-two.service.js';

type FakeUser = {
	id: number;
	email: string;
	username: string;
	password: string | null;
	fortyTwoId: number | null;
	deleted: boolean;
};

// Faux Prisma en memoire : findUnique sur un champ unique + create
function makeService(users: FakeUser[]) {
	const prisma = {
		user: {
			findUnique: async ({ where }: { where: Partial<FakeUser> }) => {
				const [field, value] = Object.entries(where)[0] as [keyof FakeUser, unknown];
				return users.find((u) => u[field] === value) ?? null;
			},
			create: async ({ data }: { data: Omit<FakeUser, 'id' | 'deleted'> }) => {
				const user = { ...data, id: users.length + 1, deleted: false };
				users.push(user);
				return user;
			},
		},
	} as unknown as PrismaService;
	return new FortyTwoService(prisma);
}

const profile = { id: 4242, login: 'jdupont', email: 'jdupont@student.42.fr' };

describe('usernameCandidates', () => {
	it('commence par le login 42 puis login-42', () => {
		const [first, second] = usernameCandidates('jdupont');
		expect(first).toBe('jdupont');
		expect(second).toBe('jdupont-42');
	});

	it('respecte le format du SignupDto (3-20 caracteres, lettres/chiffres/_/-)', () => {
		for (const login of ['un-login-vraiment-tres-long-42', 'a', 'é.t']) {
			for (const candidate of usernameCandidates(login)) {
				expect(candidate).toMatch(/^[a-zA-Z0-9_-]{3,20}$/);
			}
		}
	});
});

describe('FortyTwoService.findOrCreateUser', () => {
	it('cree un compte sans mot de passe au premier login', async () => {
		const users: FakeUser[] = [];
		const user = await makeService(users).findOrCreateUser(profile);

		expect(user).toMatchObject({ fortyTwoId: 4242, username: 'jdupont', email: profile.email, password: null });
		expect(users).toHaveLength(1);
	});

	it('retrouve le meme compte aux logins suivants', async () => {
		const users: FakeUser[] = [];
		const service = makeService(users);
		const first = await service.findOrCreateUser(profile);
		const second = await service.findOrCreateUser(profile);

		expect(second.id).toBe(first.id);
		expect(users).toHaveLength(1);
	});

	it('prend login-42 si le pseudo est deja pris', async () => {
		const users: FakeUser[] = [
			{ id: 1, email: 'autre@mail.fr', username: 'jdupont', password: 'hash', fortyTwoId: null, deleted: false },
		];
		const user = await makeService(users).findOrCreateUser(profile);
		expect(user.username).toBe('jdupont-42');
	});

	it("refuse si un compte mot de passe utilise deja l'email 42", async () => {
		const users: FakeUser[] = [
			{ id: 1, email: profile.email, username: 'squatteur', password: 'hash', fortyTwoId: null, deleted: false },
		];
		await expect(makeService(users).findOrCreateUser(profile)).rejects.toMatchObject({ code: 'email_pris' });
	});
});
