import { Injectable, UnauthorizedException } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import type { Request } from 'express';
import { Strategy } from 'passport-jwt';
import { requireEnv } from '../../env.js';
import { PrismaService } from '../../prisma.service.js';
import { TWO_FACTOR_PENDING, toPublicUser } from '../auth.service.js';

// Le token voyage dans un cookie httpOnly (voir auth.controller.ts)
// ps dans un header Authorization psq rien à lire coté JS dans le navigateur
function fromCookie(req: Request): string | null {
	return (req?.cookies?.access_token as string | undefined) ?? null;
}

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
	constructor(private readonly prisma: PrismaService) {
		super({
			jwtFromRequest: fromCookie,
			ignoreExpiration: false,
			secretOrKey: requireEnv('JWT_SECRET'),
		});
	}

	async validate(payload: { sub: number; type?: string }) {
		// Le token intermediaire du login 2FA (mot de passe ok, code pas encore
		// saisi) ne doit jamais etre accepte comme une session
		if (payload.type === TWO_FACTOR_PENDING) throw new UnauthorizedException();

		// Requete DB a chaque appel protege: un utilisateur supprime entre
		// temps perd immediatement l'acces, meme avec un token encore valide
		const user = await this.prisma.user.findUnique({ where: { id: payload.sub } });
		// deleted == la suppression RGPD anonymise la ligne
		// elle ne la supprime pas vraiment >>>>>>>>> sans ce check le token reste valide
		if (!user || user.deleted) throw new UnauthorizedException();
		return toPublicUser(user);
	}
}
