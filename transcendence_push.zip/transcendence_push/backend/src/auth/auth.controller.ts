import { randomBytes } from 'node:crypto';
import { Body, Controller, Get, HttpCode, Logger, Post, Query, Req, Res, UseGuards } from '@nestjs/common';
import { ThrottlerGuard } from '@nestjs/throttler';
import type { Request, Response } from 'express';
import { AuthService } from './auth.service.js';
import { CurrentUser } from './decorators/current-user.decorator.js';
import { LoginDto } from './dto/login.dto.js';
import { SignupDto } from './dto/signup.dto.js';
import { TwoFactorCodeDto } from './dto/two-factor-code.dto.js';
import { JwtAuthGuard } from './guards/jwt-auth.guard.js';
import { FortyTwoError, FortyTwoService } from './forty-two.service.js';
import { TwoFactorService } from './two-factor.service.js';

const COOKIE_NAME = 'access_token';
// Doit correspondre a signOptions.expiresIn dans auth.module.ts !!!!!
const COOKIE_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000;

// Cookie du login en attente du code 2FA
// Doit correspondre au expiresIn '5m' dans AuthService.login
const PENDING_COOKIE_NAME = 'twofa_pending';
const PENDING_COOKIE_MAX_AGE_MS = 5 * 60 * 1000;

// Cookie du "state" OAuth 42, le temps de faire l'aller-retour sur l'intra
const OAUTH_STATE_COOKIE_NAME = 'oauth42_state';
const OAUTH_STATE_COOKIE_MAX_AGE_MS = 5 * 60 * 1000;

type SessionResult = ReturnType<AuthService['openSession']>;

@Controller('auth')
export class AuthController
{
	private readonly logger = new Logger(AuthController.name);

	constructor(
		private readonly authService: AuthService,
		private readonly twoFactor: TwoFactorService,
		private readonly fortyTwo: FortyTwoService,
	) {}

	// 5 essais par min par ip pour le throttler
	@UseGuards(ThrottlerGuard)
	@Post('signup')
	async signup(@Body() dto: SignupDto, @Res({ passthrough: true }) res: Response) {
		const { user, token } = await this.authService.signup(dto);
		this.setAuthCookie(res, token);
		return user;
	}

	// 5 essais par min par ip aussi
	@UseGuards(ThrottlerGuard)
	@Post('login')
	@HttpCode(200)
	async login(@Body() dto: LoginDto, @Res({ passthrough: true }) res: Response) {
		const result = await this.authService.login(dto);
		this.applySession(res, result);
		return result.twoFactorRequired ? { twoFactorRequired: true } : result.user;
	}

	@Post('logout')
	@HttpCode(200)
	logout(@Res({ passthrough: true }) res: Response) {
		res.clearCookie(COOKIE_NAME, { path: '/' });
		res.clearCookie(PENDING_COOKIE_NAME, { path: '/' });
		res.clearCookie(OAUTH_STATE_COOKIE_NAME, { path: '/' });
		return { ok: true };
	}

	@UseGuards(JwtAuthGuard)
	@Get('me')
	me(@CurrentUser() user: unknown) {
		return user;
	}

	// 2e etape du login : pas de JwtAuthGuard, l'utilisateur n'a pas encore de
	// session, seulement le cookie twofa_pending pose par /auth/login
	// Throttle ici aussi pr limiter tentatives sur le 2FA
	@UseGuards(ThrottlerGuard)
	@Post('2fa/verify')
	@HttpCode(200)
	async verifyTwoFactor(
		@Body() dto: TwoFactorCodeDto,
		@Req() req: Request,
		@Res({ passthrough: true }) res: Response,
	) {
		const pendingToken = req.cookies?.[PENDING_COOKIE_NAME] as string | undefined;
		const { user, token } = await this.authService.verifyTwoFactorLogin(pendingToken, dto.code);
		res.clearCookie(PENDING_COOKIE_NAME, { path: '/' });
		this.setAuthCookie(res, token);
		return user;
	}

	@UseGuards(JwtAuthGuard)
	@Post('2fa/setup')
	@HttpCode(200)
	setupTwoFactor(@CurrentUser() user: { id: number }) {
		return this.twoFactor.generateSetup(user.id);
	}

	@UseGuards(JwtAuthGuard)
	@Post('2fa/enable')
	@HttpCode(200)
	enableTwoFactor(@CurrentUser() user: { id: number }, @Body() dto: TwoFactorCodeDto) {
		return this.twoFactor.enable(user.id, dto.code);
	}

	@UseGuards(JwtAuthGuard)
	@Post('2fa/disable')
	@HttpCode(200)
	disableTwoFactor(@CurrentUser() user: { id: number }, @Body() dto: TwoFactorCodeDto) {
		return this.twoFactor.disable(user.id, dto.code);
	}

	// OAuth 42, etape 1 : lien "Se connecter avec 42" du front (navigation
	// complete, pas un fetch) -> redirection vers la page d'autorisation de l'intra
	@Get('42')
	startFortyTwo(@Res() res: Response) {
		try {
			const state = randomBytes(16).toString('hex');
			const url = this.fortyTwo.authorizeUrl(state);
			this.setCookie(res, OAUTH_STATE_COOKIE_NAME, state, OAUTH_STATE_COOKIE_MAX_AGE_MS);
			res.redirect(url);
		} catch (error) {
			this.redirectOAuthError(res, error);
		}
	}

	// OAuth 42, etape 2 : l'intra renvoie ici avec ?code&state (ou ?error si
	// l'utilisateur a refuse). URL a declarer a l'identique dans l'appli intra
	// (FORTY_TWO_CALLBACK_URL). On repond toujours par une redirection vers le
	// front (chemins relatifs : le navigateur reste sur https://localhost)
	@Get('42/callback')
	async fortyTwoCallback(
		@Query('code') code: string | undefined,
		@Query('state') state: string | undefined,
		@Query('error') oauthError: string | undefined,
		@Req() req: Request,
		@Res() res: Response,
	) {
		const expectedState = req.cookies?.[OAUTH_STATE_COOKIE_NAME] as string | undefined;
		res.clearCookie(OAUTH_STATE_COOKIE_NAME, { path: '/' });

		try {
			// "Deny" sur la page de l'intra
			if (oauthError) throw new FortyTwoError('oauth_refuse');
			if (!state || !expectedState || state !== expectedState) throw new FortyTwoError('oauth_state');
			if (!code) throw new FortyTwoError('oauth_echec');

			const accessToken = await this.fortyTwo.exchangeCode(code);
			const profile = await this.fortyTwo.fetchProfile(accessToken);
			const user = await this.fortyTwo.findOrCreateUser(profile);

			// meme suite que le login par mot de passe : 2FA si activee
			const result = this.authService.openSession(user);
			this.applySession(res, result);
			res.redirect(result.twoFactorRequired ? '/2fa' : '/menu');
		} catch (error) {
			this.redirectOAuthError(res, error);
		}
	}

	private redirectOAuthError(res: Response, error: unknown) {
		const code = error instanceof FortyTwoError ? error.code : 'oauth_echec';
		if (!(error instanceof FortyTwoError)) this.logger.error('OAuth 42', error as Error);
		res.redirect(`/connexion?erreur=${code}`);
	}

	// Pose le bon cookie selon le resultat de AuthService.openSession :
	// session complete, ou cookie temporaire en attente du code 2FA
	private applySession(res: Response, result: SessionResult) {
		if (result.twoFactorRequired) {
			this.setCookie(res, PENDING_COOKIE_NAME, result.pendingToken, PENDING_COOKIE_MAX_AGE_MS);
		} else {
			this.setAuthCookie(res, result.token);
		}
	}

	private setAuthCookie(res: Response, token: string) {
		this.setCookie(res, COOKIE_NAME, token, COOKIE_MAX_AGE_MS);
	}

	private setCookie(res: Response, name: string, value: string, maxAge: number) {
		res.cookie(name, value, {
			httpOnly: true,
			// secure: true fait que le cookie n'est envoye que sur une connexion chiffree (HTTPS)
			secure: true,
			// sameSite: 'lax' empeche le cookie d'etre envoye quand un autre site
			// declenche une requete vers le notre. Cela protege contre l'attaque CSRF.
			sameSite: 'lax',
			maxAge,
			path: '/',
		});
	}
}
