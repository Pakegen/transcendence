import { Global, Module } from '@nestjs/common';
import { PrismaService } from './prisma.service.js';

// @Global() == un seul PrismaService pour grouverner tous les modules,
// pas besoin de réimporter
@Global()
@Module({
	providers: [PrismaService],
	exports: [PrismaService],
})
export class PrismaModule {}
