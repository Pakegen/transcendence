import type { Server } from 'socket.io';
import type { PrismaService } from '../prisma.service.js';
import { GameService } from './game.service.js';
import { MotorClientService } from './motor-client.service.js';
import { RoomAllocatorService } from './room-allocator.service.js';

function makePlayer(userId: number, socketId: string, faction = 'Witcher') {
	return { userId, username: `joueur${userId}`, socketId, faction };
}

// Server socket.io minimal: on capture juste ce qui est emis a chaque socketId
function makeServer() {
	const emitted: { socketId: string; event: string; payload: any }[] = [];
	const server = {
		to(socketId: string) {
			return {
				emit(event: string, payload: any) {
					emitted.push({ socketId, event, payload });
				},
			};
		},
	};
	return { server: server as unknown as Server, emitted };
}

function makeMotor() {
	return {
		init: vi.fn(),
		mulligan: vi.fn(),
		play: vi.fn(),
		timeout: vi.fn(),
		cleanup: vi.fn().mockResolvedValue(undefined),
	} as unknown as MotorClientService;
}

function makePrisma() {
	return {
		user: {
			findUniqueOrThrow: vi.fn().mockResolvedValue({ elo: 1000 }),
			update: vi.fn(),
		},
		// findFirst: null par defaut = pas de victoire precedente sur ce matchup (donc "nouveau succes")
		match: { create: vi.fn(), findFirst: vi.fn().mockResolvedValue(null) },
		// [{ id }] = ce que renverrait un vrai $transaction([match.create, ...]) : le Match cree en 1er
		$transaction: vi.fn().mockResolvedValue([{ id: 1 }]),
	} as unknown as PrismaService;
}

const mulliganState = {
	Game_Phase: 'Mulligan',
	Available_Commands: { '1': ['15000000000'], '2': ['25000000'] },
};

describe('GameService', () => {
	beforeEach(() => vi.useFakeTimers());
	afterEach(() => vi.useRealTimers());

	it('createSession initialise le moteur (tokens P<siege><deck>) et relaie la vue mulligan aux 2 joueurs', async () => {
		const motor = makeMotor();
		(motor.init as any).mockResolvedValue({
			resultCode: 0,
			state: mulliganState,
			view1: { hand: 'p1' },
			view2: { hand: 'p2' },
		});

		const game = new GameService(motor, new RoomAllocatorService(), makePrisma());
		const { server, emitted } = makeServer();
		const p1 = makePlayer(1, 'socket-1', 'Witcher');
		const p2 = makePlayer(2, 'socket-2', 'Wild_Hunt');

		const room = await game.createSession(server, p1, p2);

		expect(room).toBe('00');
		expect(motor.init).toHaveBeenCalledWith('00', 'P11', 'P22');
		expect(emitted).toContainEqual({ socketId: 'socket-1', event: 'game:state', payload: { hand: 'p1', turnDeadline: null } });
		expect(emitted).toContainEqual({ socketId: 'socket-2', event: 'game:state', payload: { hand: 'p2', turnDeadline: null } });
	});

	it('createSession renvoie null si le process moteur ne démarre pas', async () => {
		// resultCode: null = motor-client.service.ts n'a pas réussi à lancer python3
		const motor = makeMotor();
		(motor.init as any).mockResolvedValue({ resultCode: null, state: null, view1: null, view2: null });

		const game = new GameService(motor, new RoomAllocatorService(), makePrisma());
		const { server } = makeServer();

		const room = await game.createSession(server, makePlayer(1, 's1'), makePlayer(2, 's2'));
		expect(room).toBeNull();
		expect(motor.cleanup).toHaveBeenCalled();
	});

	it("refuse une commande absente d'Available_Commands sans appeler le moteur", async () => {
		const motor = makeMotor();
		(motor.init as any).mockResolvedValue({ resultCode: 0, state: mulliganState, view1: {}, view2: {} });

		const game = new GameService(motor, new RoomAllocatorService(), makePrisma());
		const { server, emitted } = makeServer();
		const p1 = makePlayer(1, 'socket-1');
		const p2 = makePlayer(2, 'socket-2');
		const room = (await game.createSession(server, p1, p2)) as string;

		await game.submitAction(server, room, p1.userId, 'code-invente');

		expect(motor.mulligan).not.toHaveBeenCalled();
		expect(emitted).toContainEqual(
			expect.objectContaining({ socketId: 'socket-1', event: 'game:error' }),
		);
	});

	it('attend les 2 mulligans avant de lancer le moteur, puis arme un timer de tour', async () => {
		const motor = makeMotor();
		(motor.init as any).mockResolvedValue({ resultCode: 0, state: mulliganState, view1: {}, view2: {} });
		(motor.mulligan as any).mockResolvedValue({
			resultCode: 1,
			state: { Game_Phase: 'Turn', Active_Player: 1, Available_Commands: { '1': ['11000000000000'], '2': [] } },
			view1: { phase: 'turn' },
			view2: { phase: 'turn' },
		});
		(motor.timeout as any).mockResolvedValue({ resultCode: 63, state: {}, view1: {}, view2: {} });

		const game = new GameService(motor, new RoomAllocatorService(), makePrisma());
		const { server } = makeServer();
		const p1 = makePlayer(1, 'socket-1');
		const p2 = makePlayer(2, 'socket-2');
		const room = (await game.createSession(server, p1, p2)) as string;

		await game.submitAction(server, room, p1.userId, '15000000000');
		expect(motor.mulligan).not.toHaveBeenCalled(); // un seul des deux codes reçu

		await game.submitAction(server, room, p2.userId, '25000000');
		expect(motor.mulligan).toHaveBeenCalledWith(room, ['15000000000', '25000000']);

		// resultCode 1 -> timer de tour arme, non declenche avant 60s
		await vi.advanceTimersByTimeAsync(59_000);
		expect(motor.timeout).not.toHaveBeenCalled();

		await vi.advanceTimersByTimeAsync(2_000);
		expect(motor.timeout).toHaveBeenCalledWith(room);
	});

	it('code 4: annule la partie (erreur aux 2 joueurs, salle libérée, pas de Match écrit)', async () => {
		const motor = makeMotor();
		(motor.init as any).mockResolvedValue({
			resultCode: 0,
			state: { Game_Phase: 'Turn', Active_Player: 1, Available_Commands: { '1': ['11000000000000'], '2': [] } },
			view1: {},
			view2: {},
		});
		(motor.play as any).mockResolvedValue({ resultCode: 4, state: null, view1: null, view2: null });

		const rooms = new RoomAllocatorService();
		const prisma = makePrisma();
		const game = new GameService(motor, rooms, prisma);
		const { server, emitted } = makeServer();
		const p1 = makePlayer(1, 'socket-1');
		const p2 = makePlayer(2, 'socket-2');
		const room = (await game.createSession(server, p1, p2)) as string;

		await game.submitAction(server, room, p1.userId, '11000000000000');

		expect(emitted).toContainEqual(expect.objectContaining({ socketId: 'socket-1', event: 'game:error' }));
		expect(emitted).toContainEqual(expect.objectContaining({ socketId: 'socket-2', event: 'game:error' }));
		expect(prisma.match.create).not.toHaveBeenCalled();
		expect(motor.cleanup).toHaveBeenCalledWith(room);
		// la salle a ete liberee: reallouable immediatement
		expect(rooms.allocate()).toBe(room);
	});

	it('61/62/63: enregistre le Match + met a jour les deux ELO puis nettoie la salle', async () => {
		const motor = makeMotor();
		(motor.init as any).mockResolvedValue({
			resultCode: 0,
			state: { Game_Phase: 'Turn', Active_Player: 1, Available_Commands: { '1': ['11000000000000'], '2': [] } },
			view1: {},
			view2: {},
		});
		(motor.play as any).mockResolvedValue({
			resultCode: 61,
			state: { Game_Phase: 'Game_End', Winner: 1 },
			view1: { winner: 1 },
			view2: { winner: 1 },
		});

		const prisma = makePrisma();
		const game = new GameService(motor, new RoomAllocatorService(), prisma);
		const { server, emitted } = makeServer();
		const p1 = makePlayer(1, 'socket-1', 'Witcher');
		const p2 = makePlayer(2, 'socket-2', 'Wild_Hunt');
		const room = (await game.createSession(server, p1, p2)) as string;

		await game.submitAction(server, room, p1.userId, '11000000000000');

		expect(prisma.match.create).toHaveBeenCalledWith({
			data: { player1Id: 1, player2Id: 2, faction1: 'Witcher', faction2: 'Wild_Hunt', result: 'PLAYER1' },
		});
		expect(prisma.user.update).toHaveBeenCalledTimes(2);
		expect(prisma.$transaction).toHaveBeenCalledTimes(1);
		expect(motor.cleanup).toHaveBeenCalledWith(room);

		// 1ere victoire Witcher vs Wild_Hunt pour p1 (findFirst mocke a null) -> succes envoye au gagnant seulement
		expect(emitted).toContainEqual({
			socketId: 'socket-1', event: 'game:succes', payload: { myFaction: 'Witcher', opponentFaction: 'Wild_Hunt' },
		});
		expect(emitted.filter((e) => e.event === 'game:succes')).toHaveLength(1);
	});

	it("61/62/63: pas de succès renvoyé si le gagnant avait déjà gagné ce matchup avant", async () => {
		const motor = makeMotor();
		(motor.init as any).mockResolvedValue({
			resultCode: 0,
			state: { Game_Phase: 'Turn', Active_Player: 1, Available_Commands: { '1': ['11000000000000'], '2': [] } },
			view1: {},
			view2: {},
		});
		(motor.play as any).mockResolvedValue({
			resultCode: 61,
			state: { Game_Phase: 'Game_End', Winner: 1 },
			view1: { winner: 1 },
			view2: { winner: 1 },
		});

		const prisma = makePrisma();
		(prisma.match.findFirst as any).mockResolvedValue({ id: 0 }); // une victoire precedente existe deja
		const game = new GameService(motor, new RoomAllocatorService(), prisma);
		const { server, emitted } = makeServer();
		const p1 = makePlayer(1, 'socket-1', 'Witcher');
		const p2 = makePlayer(2, 'socket-2', 'Wild_Hunt');
		const room = (await game.createSession(server, p1, p2)) as string;

		await game.submitAction(server, room, p1.userId, '11000000000000');

		expect(emitted.filter((e) => e.event === 'game:succes')).toHaveLength(0);
	});
});
