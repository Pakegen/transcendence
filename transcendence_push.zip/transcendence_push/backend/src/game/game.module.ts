import { Module } from '@nestjs/common';
import { GameService } from './game.service.js';
import { MotorClientService } from './motor-client.service.js';
import { RoomAllocatorService } from './room-allocator.service.js';

// PrismaModule est @Global
@Module({
	providers: [GameService, MotorClientService, RoomAllocatorService],
	exports: [GameService],
})
export class GameModule {}
