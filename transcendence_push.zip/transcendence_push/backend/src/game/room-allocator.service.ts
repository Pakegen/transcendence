import { Injectable } from '@nestjs/common';

const MAX_ROOMS = 100;

@Injectable()
export class RoomAllocatorService
{
	private readonly used = new Set<string>();

	// null si les 100 salles sont deja prises pas de file d'attente ?
	
	allocate(): string | null
	{
		for (let room = 0; room < MAX_ROOMS; room++)
		{
			const id = String(room).padStart(2, '0'); // padStart = ajoute des 0 devant pour que ca fasse 2 chiffres
			if (!this.used.has(id))
			{
				this.used.add(id);
				return id;
			}
		}
		return null;
	}

	free(room: string)
		{this.used.delete(room);}
}
