import { RoomAllocatorService } from './room-allocator.service.js';

describe('RoomAllocatorService', () => {
	it('alloue des numéros de salle sur 2 chiffres, en partant de 00', () => {
		const rooms = new RoomAllocatorService();
		expect(rooms.allocate()).toBe('00');
		expect(rooms.allocate()).toBe('01');
	});

	it('ne réalloue jamais une salle déjà prise', () => {
		const rooms = new RoomAllocatorService();
		const a = rooms.allocate();
		const b = rooms.allocate();
		expect(a).not.toBe(b);
	});

	it('free() permet de réutiliser un numéro de salle', () => {
		const rooms = new RoomAllocatorService();
		const first = rooms.allocate();
		rooms.free(first as string);
		expect(rooms.allocate()).toBe(first);
	});

	it('renvoie null quand les 100 salles sont prises', () => {
		const rooms = new RoomAllocatorService();
		for (let i = 0; i < 100; i++) expect(rooms.allocate()).not.toBeNull();
		expect(rooms.allocate()).toBeNull();
	});
});
