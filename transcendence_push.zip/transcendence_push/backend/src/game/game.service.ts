import { Injectable, Logger } from '@nestjs/common';
import type { Server } from 'socket.io';
import { PrismaService } from '../prisma.service.js';
import { calculateElo } from '../stats/elo.js';
import type { EloResult } from '../stats/elo.js';
import { MotorClientService } from './motor-client.service.js';
import type { MotorResult } from './motor-client.service.js';
import { RoomAllocatorService } from './room-allocator.service.js';


const TURN_TIMEOUT_MS = 60_000;

// Si un joueur ne repond pas a temps pendant le mulligan =  on soumet ce code a sa place (garde les cartes) voir md cyril
const MULLIGAN_KEEP_ALL_P1 = '15000000000';
const MULLIGAN_KEEP_ALL_P2 = '25000000';




const AI_USER_ID = -1;
const AI_USERNAME = 'IA';

// Seat = ne peut être que 1 ou 2 (player)
type Seat = 1 | 2;

function factionToDeck(faction: string): Seat {return faction === 'Wild_Hunt' ? 2 : 1;}

// export pr tests
export type GamePlayer = {
	userId: number;
	username: string;
	socketId: string;
	faction: string;
};

// Tt la data qu'on a ds une game
type Session = {
	room: string;
	player1: GamePlayer;
	player2: GamePlayer;

	// true == partie ia
	vsAI: boolean;

	// Dernier état complet reçu du moteur (Game_Phase, Available_Commands ou quoi)
	// On en a besoin pour vérifier qu'une commande reçue d'un joueur est valide
	// avant d'appeler le moteur
	lastState: Record<string, any> | null;


	// dernière vue privée send à chaque player
	// sert à se reco (rrenvoie au joueur ce qu'il a déjà recu)
	lastView1: Record<string, any> | null;
	lastView2: Record<string, any> | null;

	// Pendant la phase de mulligan stocke les codes de chaque joueur, qd on a les deux call moteur
	mulliganCode1: string | null;
	mulliganCode2: string | null;
	// Evite double call si ils rep en même temps plus ou moins
	mulliganInProgress: boolean;

	// Evite qu'un double-clic/retry client envoie 2 game:action avant que le
	// premier motor.play() ait fini et mis a jour lastState (meme principe que mulliganInProgress)
	actionInProgress: boolean;

	// Un timer par joueur pendant le mulligan + timer partagé pr le afk vu que chacun son tour
	mulliganTimer1: NodeJS.Timeout | null;
	mulliganTimer2: NodeJS.Timeout | null;
	turnTimer: NodeJS.Timeout | null;


	// Envoye aux 2 joueurs dans game:state pour afficher un chrono cote front
	// null = = pas de min pendant mulligan ou autre
	turnDeadline: number | null;
};

//Lien client et moteur via les sockets
//  Démarre une partie quand 2 joueurs sont co == createSession
// relaie les commandes des joueurs au moteur == submitAction
// timer par tour si le joueur actif ne joue ps, forcer timout == armTurnTimer
//enregistre le résultat ELO + HISTO
// +ia
@Injectable()
export class GameService
{
	private readonly logger = new Logger(GameService.name); // Logger = avoir les logs du service ds la console
	// trouvables par leur id
	private readonly sessions = new Map<string, Session>();

	// evite de reparcourir tt les sessions si un player se reconnecte (userId + room)
	private readonly roomByUserId = new Map<number, string>();

	constructor(
		private readonly motor: MotorClientService,
		private readonly rooms: RoomAllocatorService,
		private readonly prisma: PrismaService,
	) {}

	// Appelé par le matchmaking une fois 2 joueurs co ensemble
	// retourne l'id de la salle si la partie a pu démarrer OU null si toutes les salles sont occupées ou erreur
	async createSession(server: Server, player1: GamePlayer, player2: GamePlayer): Promise<string | null>
	{
		const room = this.rooms.allocate();
		if (room === null)
		{
			this.logger.warn('Impossible de créer une partie = 100 salles déjà occupées/erreur');
			return null;
		}

		const session: Session = {
			room,
			player1,
			player2,
			vsAI: false,
			lastState: null,

			lastView1: null, // updates post patch reconnexion
			lastView2: null,

			mulliganCode1: null,
			mulliganCode2: null,
			mulliganInProgress: false,
			actionInProgress: false,
			mulliganTimer1: null,
			mulliganTimer2: null,
			turnTimer: null,
			turnDeadline: null,
		};

		// set permet d'associer la salle à la session ds la map
		this.sessions.set(room, session);


		// track reconnexion
		this.roomByUserId.set(player1.userId, room);
		this.roomByUserId.set(player2.userId, room);


		// "P1/2 + faction" = pour le moteur
		const token1 = `P1${factionToDeck(player1.faction)}`;
		const token2 = `P2${factionToDeck(player2.faction)}`;

		// call moteur pr créer les fichiers
		const result = await this.motor.init(room, token1, token2);
		const success = await this.handleMotorResult(server, session, result);
		return success ? room : null;
	}




	async createSessionVsAI(server: Server, human: GamePlayer): Promise<string | null>
	{
		const room = this.rooms.allocate();
		if (room === null)
		{
			this.logger.warn('Impossible de créer une partie IA = 100 salles déjà occupées/erreur');
			return null;
		}


		const humanSeat: Seat = Math.random() < 0.5 ? 1 : 2;
		const aiSeat = this.otherSeat(humanSeat);


		const ai: GamePlayer = { userId: AI_USER_ID, username: AI_USERNAME, socketId: '', faction: 'Witcher' };


		const player1 = humanSeat === 1 ? human : ai;
		const player2 = humanSeat === 2 ? human : ai;

		const session: Session = {
			room,
			player1,
			player2,
			vsAI: true,
			lastState: null,

			lastView1: null,
			lastView2: null,


			mulliganCode1: null,
			mulliganCode2: null,
			mulliganInProgress: false,
			actionInProgress: false,
			mulliganTimer1: null,
			mulliganTimer2: null,
			turnTimer: null,
			turnDeadline: null,
		};

		this.sessions.set(room, session);

		this.roomByUserId.set(human.userId, room);

		const humanToken = `P${humanSeat}${factionToDeck(human.faction)}`;
		const aiToken = `I${aiSeat}1`;
		const token1 = humanSeat === 1 ? humanToken : aiToken;
		const token2 = humanSeat === 2 ? humanToken : aiToken;

		const result = await this.motor.init(room, token1, token2);

		// null si le moteur peut ps démarer sinn ret le code de sortie
		const success = await this.handleMotorResult(server, session, result);
		return success ? room : null;
	}


	// Que ce soit choix mulligan ou action, pas de diff c'est le mm évent game:action
	async submitAction(server: Server, room: string, userId: number, code: string)
	{
		const session = this.sessions.get(room);
		if (!session) return; // salle inconnue (partie déjà finie, mauvais id ou autre (NOTE AU DEBUGGER : CA PEUT ETRE ICI)

		const seat = this.seatOf(session, userId);
		if (seat === null) return ; // joueur inconnu wtf

		// Available_Commands ne contient des coups QUE pour le joueur dont c'est le
		// tour dcp si le code envoyé est dans la liste = c'est le bon player
		let allowedCodes: string[];
		if (session.lastState == null)
			{allowedCodes = [];}
		else if (session.lastState.Available_Commands == null) // mulligan/fin de partie ?
			{allowedCodes = [];}
		else if (session.lastState.Available_Commands[String(seat)] == null) // pas le tour du joueur
			{allowedCodes = [];}

		else {allowedCodes = session.lastState.Available_Commands[String(seat)];} // recup coups dispo


		if (!allowedCodes.includes(code))
			{this.emitTo(server, session, seat, 'game:error', { message: 'Commande invalide brother' }); return;}


		// diff mulligan / action normale si mulli, on stocke le code et on attend l'autre, sinn call moteur
		if (session.lastState?.Game_Phase === 'Mulligan')
		{
			this.receiveMulliganChoice(session, seat, code);
			await this.tryResolveMulligan(server, session);
			return ;
		}

		// un 2e game:action peut arriver avant que motor.play
		// ait fini et mis a jour lastState dcp on l'ignore plutot que de traiter 2x la meme action
		if (session.actionInProgress) return ;
		session.actionInProgress = true;

		try
		{
			// call vroum vroum
			const result = await this.motor.play(room, code);
			// null si le moteur peut ps démarer sinn ret le code de sortie
			await this.handleMotorResult(server, session, result);
		}
		finally
		{
			session.actionInProgress = false;
		}
	}

	/////////////////// MULLIGAN

	private receiveMulliganChoice(session: Session, seat: Seat, code: string)
	{
		if (seat === 1)
		{
			this.clearTimer(session.mulliganTimer1);
			session.mulliganTimer1 = null;
			session.mulliganCode1 = code;
		}
		else
		{
			this.clearTimer(session.mulliganTimer2);
			session.mulliganTimer2 = null;
			session.mulliganCode2 = code;
		}
	}

	// N'appelle le moteur que quand on a bien recup un code des 2 joueurs psq le moteur veut absolument les deux en mm tmp
	private async tryResolveMulligan(server: Server, session: Session)
	{
		if (session.mulliganInProgress) return; // déjà en train d'être traité évite double call

		if (session.vsAI)
		{
			const humanCode = session.mulliganCode1 ?? session.mulliganCode2;
			if (!humanCode) return;

			session.mulliganInProgress = true;
			session.mulliganCode1 = null;
			session.mulliganCode2 = null;

			const result = await this.motor.mulligan(session.room, [humanCode]);
			session.mulliganInProgress = false;
			await this.handleMotorResult(server, session, result);
			return;
		}

		if (!session.mulliganCode1 || !session.mulliganCode2) return;

		session.mulliganInProgress = true;
		const codes = [session.mulliganCode1, session.mulliganCode2];
		session.mulliganCode1 = null;
		session.mulliganCode2 = null;

		const result = await this.motor.mulligan(session.room, codes);
		session.mulliganInProgress = false;
		await this.handleMotorResult(server, session, result);
	}


	//Timers, on met "garde tt" si pas de rép (attention voir si les deux joueurs sont afk ?)
	private armMulliganTimers(server: Server, session: Session)
	{
		const aiIsSeat1 = session.vsAI && session.player1.userId === AI_USER_ID;
		const aiIsSeat2 = session.vsAI && session.player2.userId === AI_USER_ID;

		if (!aiIsSeat1)
		{
			session.mulliganTimer1 = setTimeout(async () =>
			{ // fonction anonyme pr le timer et TURN_TIMEOUT_MS fait office de 2e arg à setTimeout (fonction, délai)
				session.mulliganTimer1 = null;
				if (!session.mulliganCode1)
					session.mulliganCode1 = MULLIGAN_KEEP_ALL_P1;
				await this.tryResolveMulligan(server, session);
			}, TURN_TIMEOUT_MS);
		}

		if (!aiIsSeat2)
		{
			session.mulliganTimer2 = setTimeout(async () =>
			{
				session.mulliganTimer2 = null;
				if (!session.mulliganCode2) session.mulliganCode2 = MULLIGAN_KEEP_ALL_P2;
				await this.tryResolveMulligan(server, session);
			}, TURN_TIMEOUT_MS);
		}
	}





	////////////////// TIMER TOUR + AFK

	// Redémarre le chrono pour le tour en cours = call à chaque fois qu'on sait que c à un joueur de jouer == code moteur 1 ou 2
	private armTurnTimer(server: Server, session: Session)
	{
		this.clearTimer(session.turnTimer);
		session.turnDeadline = Date.now() + TURN_TIMEOUT_MS;
		session.turnTimer = setTimeout(async () =>
		{
			session.turnTimer = null;
			session.turnDeadline = null;
			await this.runTurnTimeout(server, session);
		}, TURN_TIMEOUT_MS);
	}

	// player a pas joué ds les temps on demande au moteur de forcer un timeout puis on traite le résultat comme nimp quel apl moteur
	private async runTurnTimeout(server: Server, session: Session)
	{
		const result = await this.motor.timeout(session.room);
		await this.handleMotorResult(server, session, result);
	}

	// NodeJS.Timeout = type de retour de setTimeout, null si pas de timer en cours
	private clearTimer(timer: NodeJS.Timeout | null) {if (timer) clearTimeout(timer);}






	/////////////// RESULT HANDLING MOTEUR

	// CALL APRES TOUS LES APLS AU MOTEUR !!!!
	// Vérifie d'abord que le process a bien tourné, puis passe la main à interpretResult()
	// Ret false si la partie a dû être annulée
	private async handleMotorResult(server: Server, session: Session, result: MotorResult): Promise<boolean>
	{
		if (result.resultCode === null)
		{
			await this.cancelSession(server, session, 'Le moteur de jeu n\'a pas pu démarrer :/');
			return false ;
		}
		// false si interpretResult a du annuler la session avc code 4 dcp la salle
		// n'existe plus, il ne faut pas la renvoyer comme si la partie avait demarré
		return await this.interpretResult(server, session, result);
	}

	///// CORE
	// 0 == on attend le choix de mulligan des 2 joueurs
	// 1 ou 2 == partie en cours, on attend un coup du joueur 1 ou du joueur 2
	// 3 == invalid cmd, pas de nouvel etat (no room writes), mais on rearme le
	// timer de tour si on etait en train d'attendre un coup, sinon la partie
	// reste figee pour toujours (voir plus bas)
	// 4 == match annulé erreur moteur : ne pas republier sa production (?)
	// 61 / 62 == victoire du p1/p2
	// 63 ==  nul
	// Retourne false si la session a ete annulee (code 4), true sinon
	private async interpretResult(server: Server, session: Session, result: MotorResult): Promise<boolean> {
		const code = result.resultCode;


		if (code === 3)
		{
			const sessionEncoreActive = this.sessions.get(session.room) === session;
			if (sessionEncoreActive && session.lastState?.Game_Phase === 'Turn')
			{
				this.armTurnTimer(server, session);
				this.sendViews(server, session, result);
			}
			return true ;
		}

		if (code === 4)
		{
			await this.cancelSession(server, session, 'Erreur moteur :(');
			return false ;
		}


		// d'abord armer le timer / calculer et envoyer le changement d'ELO et ps direct les views
		// perimees : deadline du tour precedent, ou pas d'ELO encore connu)
		if (result.state) session.lastState = result.state;

		if (code === 0)
			{this.armMulliganTimers(server, session);}
		else if (code === 1 || code === 2)
			{this.armTurnTimer(server, session);}
		else if (code === 61 || code === 62 || code === 63)
			{await this.finishSession(server, session, code);
		}

		this.sendViews(server, session, result);

		return true ;
	}



	// call par gateway avant d'accepter un queue:join ia ou pvp
	// Si ancienne partie IA, on abandonne pour laisser la nvelle partie, si c'est une vraie partie pvp on touche pas
	async hasActiveSessionBlocking(userId: number): Promise<boolean>
	{
		const room = this.roomByUserId.get(userId);
		if (!room) return false;

		const session = this.sessions.get(room);
		if (!session) return false;

		if (!session.vsAI) return true;

		await this.cleanupSession(session);
		return false;
	}

	private sendViews(server: Server, session: Session, result: MotorResult)
	{
		if (result.view1)
		{
			// maj de la dernière vue privée envoyée pour reco
			session.lastView1 = result.view1;

			this.emitTo(server, session, 1, 'game:state', this.avecDeadline(session, result.view1));
		}
		if (result.view2)
		{
			session.lastView2 = result.view2;
			this.emitTo(server, session, 2, 'game:state', this.avecDeadline(session, result.view2));
		}
	}

	// Le moteur ne connait pas la notion de minuteur (c'est gere par le back
	// via armTurnTimer) : on l'ajoute a la vue juste avant de l'envoyer
	private avecDeadline(session: Session, view: Record<string, any>)
	{
		return { ...view, turnDeadline: session.turnDeadline };
	}


	// Fonction ajout reconnexion. Qd un socket se connecte, si partie en cours on met à jour socketId car ancien foutu
	// renvoie de la dernière vue connue sans demander au moteur
	reconnect(server: Server, userId: number, newSocketId: string)
	{
		const room = this.roomByUserId.get(userId);
		if (!room) return; // pas de partie en cours

		const session = this.sessions.get(room);
		if (!session) return; // partie finie ou erreur

		const seat = this.seatOf(session, userId);
		if (seat === null) return;

		if (seat === 1)
		{
			session.player1.socketId = newSocketId;
			if (session.lastView1) this.emitTo(server, session, 1, 'game:state', this.avecDeadline(session, session.lastView1));
		}
		else
		{
			session.player2.socketId = newSocketId;
			if (session.lastView2) this.emitTo(server, session, 2, 'game:state', this.avecDeadline(session, session.lastView2));
		}


		// Prévenir que l'adversaire est revenu
		this.emitTo(server, session, this.otherSeat(seat), 'game:opponent-reconnected', {});
	}


	// Si joueur est déjà reco avec un nouveau socket car retard de cet event, le socketId rep plus
	notifyDisconnect(server: Server, userId: number, socketId: string)
	{
		const room = this.roomByUserId.get(userId);
		if (!room) return ; // pas de partie


		const session = this.sessions.get(room);
		if (!session) return; // partie finie ou erreur

		const seat = this.seatOf(session, userId);
		if (seat === null) return;


		const socketActuel = seat === 1 ? session.player1.socketId : session.player2.socketId;
		if (socketActuel !== socketId) return; // deja reco avec un autre socket

		this.emitTo(server, session, this.otherSeat(seat), 'game:opponent-left', {});
	}

	private otherSeat(seat: Seat): Seat {return seat === 1 ? 2 : 1;}

	private emitTo(server: Server, session: Session, seat: Seat, event: string, payload: unknown)
	{
		const socketId = seat === 1 ? session.player1.socketId : session.player2.socketId;
		server.to(socketId).emit(event, payload);
	}

	private seatOf(session: Session, userId: number): Seat | null {
		if (session.player1.userId === userId) return 1;
		if (session.player2.userId === userId) return 2;
		return null;
	}

	//////////////// Endgame
	// Pas de partie enregistrée, on vire la game
	// On previent les 2 joueurs, échec demarrage/err
	private async cancelSession(server: Server, session: Session, message: string)
	{
		this.emitTo(server, session, 1, 'game:error', { message });
		this.emitTo(server, session, 2, 'game:error', { message });
		await this.cleanupSession(session);
	}

	// Enregistre victoire ou match nul
	// maj ELO + envoie à chacun son avant/après (pour l'écran de fin de partie)
	// Les vues finales (game:state) sont envoyées juste après par interpretResult
	private async finishSession(server: Server, session: Session, code: 61 | 62 | 63) {

		if (session.vsAI)
		{
			await this.cleanupSession(session);
			return;
		}

		let matchResult: EloResult = 'DRAW';
		if (code === 61) matchResult = 'PLAYER1';
		if (code === 62) matchResult = 'PLAYER2';

		try
		{// On lit l'ELO actuel des 2 joueurs, on calcule le nouveau, puis on
			// écrit tout ça en base (le Match + les 2 ELO) en une seule transaction:
			// soit tout est enregistré, soit rien ne l'est (pas de résultat à moitié écrit).
			const user1 = await this.prisma.user.findUniqueOrThrow({
				where: { id: session.player1.userId },
				select: { elo: true },
			});
			const user2 = await this.prisma.user.findUniqueOrThrow({
				where: { id: session.player2.userId },
				select: { elo: true },
			});
			const { newElo1, newElo2 } = calculateElo(user1.elo, user2.elo, matchResult);

			// $transaction = tt les calls db regroupés en un seul
			const [match] = await this.prisma.$transaction([this.prisma.match.create({
					data: {
						player1Id: session.player1.userId,
						player2Id: session.player2.userId,
						faction1: session.player1.faction,
						faction2: session.player2.faction,
						result: matchResult,
					},
				}),
				this.prisma.user.update({ where: { id: session.player1.userId }, data: { elo: newElo1 } }),
				this.prisma.user.update({ where: { id: session.player2.userId }, data: { elo: newElo2 } }),
			]);

			// Envoyé seulement si la transaction a reussi à voir
			this.emitTo(server, session, 1, 'game:elo', { eloAvant: user1.elo, eloApres: newElo1 });
			this.emitTo(server, session, 2, 'game:elo', { eloAvant: user2.elo, eloApres: newElo2 });

			// Succès "1ere victoire avec cette faction contre celle-ci" : calculé ici
			// plutot que devine cote front par un delai (race avec /stats/me)
			if (matchResult === 'PLAYER1') {
				const nouveau = await this.estNouvelleVictoireMatchup(
					session.player1.userId, session.player1.faction, session.player2.faction, match.id,
				);
				if (nouveau) {
					this.emitTo(server, session, 1, 'game:succes', {
						myFaction: session.player1.faction, opponentFaction: session.player2.faction,
					});
				}
			}
			if (matchResult === 'PLAYER2') {
				const nouveau = await this.estNouvelleVictoireMatchup(
					session.player2.userId, session.player2.faction, session.player1.faction, match.id,
				);
				if (nouveau) {
					this.emitTo(server, session, 2, 'game:succes', {
						myFaction: session.player2.faction, opponentFaction: session.player1.faction,
					});
				}
			}
		} catch (error) {
			this.logger.error(`Échec de l'enregistrement de la partie (salle ${session.room}): ${error}`);
		}

		await this.cleanupSession(session);
	}

	// Vrai si userId n'avait encore jamais gagné avec maFaction contre safaction
	// (même logique que StatsService.getMyStats, cote match qu'on vient de creer exclu)
	private async estNouvelleVictoireMatchup(
		userId: number, maFaction: string, safaction: string, matchIdExclu: number,
	): Promise<boolean> {
		const dejaGagne = await this.prisma.match.findFirst({
			where: {
				id: { not: matchIdExclu },
				OR: [
					{ player1Id: userId, faction1: maFaction, faction2: safaction, result: 'PLAYER1' },
					{ player2Id: userId, faction2: maFaction, faction1: safaction, result: 'PLAYER2' },
				],
			},
		});
		return dejaGagne === null;
	}

	// Appelé à chaque fin de partie (succès ou annulation): on arrête les timers, on supprime les fichiers du moteur et on libère la salle
	private async cleanupSession(session: Session) {
		this.clearTimer(session.turnTimer);
		this.clearTimer(session.mulliganTimer1);
		this.clearTimer(session.mulliganTimer2);
		await this.motor.cleanup(session.room);
		this.rooms.free(session.room);
		this.sessions.delete(session.room);

		// cleanup post fix reconnexion
		this.roomByUserId.delete(session.player1.userId);
		this.roomByUserId.delete(session.player2.userId);
	}
}
