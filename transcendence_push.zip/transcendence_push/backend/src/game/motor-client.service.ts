import { Injectable, Logger } from '@nestjs/common';
import { execFile } from 'node:child_process';
import { readFile, unlink } from 'node:fs/promises';
import path from 'node:path';
import { promisify } from 'node:util';

// callbacks plutot qu'avec des asyncawait
// promisify() transforme la fonction pour pouvoir faire "await execFileAsync(...)" au lieu de devoir
// gerer un callback a la main
const execFileAsync = promisify(execFile);

const ENGINE_DIR = path.resolve(process.cwd(), 'game-engine');
const MOTOR_SCRIPT = path.join(ENGINE_DIR, 'motor.py');

// Si motor.py ne repond jamais (bug, boucle infinie...) on ne doit pas bloquer
// la partie indefiniment. 10s est large tant qu'il n'y a pas d'IA qui explore
// plein de coups a chaque appel (a remonter le jour ou il y en a une).

// si motor.py rep plus (pr éviter que ça bloque)
// attention aux call de l'ia qui voudraient tester plein de coups !!
const MOTOR_CALL_TIMEOUT_MS = 10_000;

export type MotorResult = {
	// null = non démarrage de python
	resultCode: number | null;
	// Contenu de roomM.json: etat complet de la partie, usage interne seulement
	// (jamais envoye aux joueurs).
	state: Record<string, any> | null;
	// Contenu de room1/2.json ce que chaque joueur a le droit de voir.
	view1: Record<string, any> | null;
	view2: Record<string, any> | null;
};

@Injectable()
export class MotorClientService {
	private readonly logger = new Logger(MotorClientService.name);

	// Le moteur peut ps apl 2 fois en mm temps sur la meme room (mélange de fichiers)
	// On force les apl à s'exec un par un ordre d'arrivée
	//  Map = le numero de salle et la valeur = la Promise de l'appel en cours (ou du dernier apl. Quand un nouvel appel arrive pour il doit attendre
	private readonly pendingCallByRoom = new Map<string, Promise<unknown>>();

	init(room: string, p1Token: string, p2Token: string): Promise<MotorResult>
		{return this.callInOrder(room, ['I', p1Token, p2Token]);} // I = init

	// codes: 1 ou 2 codes de mulligan
	// ... = transforme un tableau en liste d'args
	mulligan(room: string, codes: string[]): Promise<MotorResult>
		{return this.callInOrder(room, ['M', ...codes]);} // M = mulligan

	play(room: string, code: string): Promise<MotorResult>
		{return this.callInOrder(room, ['P', code]);} // P = play

	timeout(room: string): Promise<MotorResult>
		{return this.callInOrder(room, ['T']);} // T = timeout

	// Aucun delete cote moteur
	async cleanup(room: string) {
		await this.deleteRoomFile(room, 'M');
		await this.deleteRoomFile(room, '1');
		await this.deleteRoomFile(room, '2');
	}



	private callInOrder(room: string, args: string[]): Promise<MotorResult> {
		// ?? = si la salle n'a pas d'appel en cours, on met une Promise qui se resout tout de suite
		const previousCall = this.pendingCallByRoom.get(room) ?? Promise.resolve();

		// .then(runNow, runNow) blk si l'appel precedent a reussi ou echec, on lance quand meme une fois qu'il est termine.
		const runNow = () => this.runProcess(room, args);
		const thisCall = previousCall.then(runNow, runNow);

		this.pendingCallByRoom.set(room, thisCall);
		return thisCall;
	}
	private async deleteRoomFile(room: string, suffix: string) {
		try
		{
			// unlink = supprime le fichier, si existe pas err mais ignorée
			await unlink(path.join(ENGINE_DIR, `${room}${suffix}.json`));
		}
		catch {/**Le fichier n'existe plus ou pas*/}
	}

	// Lance vraiment "python3 motor.py <room> <args...>" et lit le resultat.
	private async runProcess(room: string, args: string[]): Promise<MotorResult> {
		try
		{
			// execFile != de exec : lance le script direct sans shell donc pas d'injec de cmd
			// si timeout node tue le proc (ps d'err numérique)mais traité plus bas comme échec de démarage
			await execFileAsync(
				'python3',
				[MOTOR_SCRIPT, room, ...args],
				{ timeout: MOTOR_CALL_TIMEOUT_MS }
			);

			// return 0 sinn on serait ps ici
			return await this.readResult(room, 0);
		}
		catch (error: any)
		{
			// Dans node un programme lancé avec execFile se termine avec un code de sortie non nul
			// (comme une erreur) nous c'est pas un souci
			// vrai code = error.code
			if (typeof error.code === 'number') {return await this.readResult(room, error.code);}

			if (error.killed)
			{
				// timeout = node fait sigterm == crash prblmatique
				this.logger.error(`Moteur tué apres ${MOTOR_CALL_TIMEOUT_MS}ms sans reponse (salle ${room})`);
			}
			else
			{
				// python et ps le moteur qui plante
				this.logger.error(`Le moteur n'a pas pu démarrer (salle ${room}): ${error.message}`);
			}

			return {
				resultCode: null, state: null, view1: null, view2: null
			};
		}
	}

	private async readResult(room: string, resultCode: number): Promise<MotorResult>
	{
		const state = await this.readRoomFile(room, 'M');
		const view1 = await this.readRoomFile(room, '1');
		const view2 = await this.readRoomFile(room, '2');
		return { resultCode, state, view1, view2 };
	}


	// code 3 = cmd invalide du coup faut lire l'ancien contenu
	private async readRoomFile(room: string, suffix: string): Promise<Record<string, any> | null>
	{
		try
		{
			const raw = await readFile(path.join(ENGINE_DIR, `${room}${suffix}.json`), 'utf-8');
			return JSON.parse(raw);
		}
		catch {return null;}
	}
}
