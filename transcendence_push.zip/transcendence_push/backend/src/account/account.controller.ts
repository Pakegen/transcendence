import { Body, Controller, Delete, Get, HttpCode, Post, Put, Query, Res, UploadedFile, UseGuards, UseInterceptors } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ThrottlerGuard, Throttle } from '@nestjs/throttler';
import { ApiBody, ApiConsumes, ApiOperation, ApiSecurity, ApiTags } from '@nestjs/swagger';
import type { Response } from 'express';
import { CurrentUser } from '../auth/decorators/current-user.decorator.js';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard.js';
import { AccountService, exportToCsv } from './account.service.js';
import type { UploadedAccountFile } from './account.service.js';
import { ApiKeyService } from './api-key.service.js';
import { BulkCreateApiKeysDto, BulkRevokeApiKeysDto } from './dto/bulk-api-keys.dto.js';
import { CreateApiKeyDto } from './dto/create-api-key.dto.js';
import { ExportFormatDto } from './dto/export-format.dto.js';
import { ImportQueryDto } from './dto/import-account.dto.js';
import { UpdateAccountDto } from './dto/update-account.dto.js';
import { ApiKeyGuard } from './guards/api-key.guard.js';
import { MAX_IMPORT_BYTES } from './import-file.js';

// Upload du fichier d'import : champ "file" du formulaire multipart.
// limits.fileSize : multer coupe l'upload au-dela (413) avant de tout lire en memoire
const importInterceptor = FileInterceptor('file', { limits: { fileSize: MAX_IMPORT_BYTES, files: 1 } });
const importBody = { schema: { type: 'object', properties: { file: { type: 'string', format: 'binary' } } } } as const;



// auth par clé != cookie
// 60 req/min != auth
@ApiTags('account (API publique)')
@UseGuards(ThrottlerGuard)
@Throttle({ default: { limit: 60, ttl: 60_000 } })
@Controller('account')
export class AccountController
{
	constructor(
		private readonly account: AccountService,
		private readonly apiKeys: ApiKeyService,
	) {}


	// pas de apiguard vu qu'il faut être co sur le site pour créer une cle
	@ApiOperation({ summary: "Cree une nouvelle cle API pour son compte (necessite d'etre connecte au site)" })
	@UseGuards(JwtAuthGuard)
	@Post('api-keys')
	createApiKey(@CurrentUser() user: { id: number }, @Body() dto: CreateApiKeyDto)
	{
		return this.apiKeys.create(user.id, dto.label);
	}

	//rgpd depuis site  
	// ApiOperation pour swagger pr doc la route
	@ApiOperation({ summary: "Export des données depuis le site (doit être co). ?format=json (defaut) ou csv" })
	@UseGuards(JwtAuthGuard)
	@Get('me/export')
	exportMyAccount(
		@CurrentUser() user: { id: number },
		@Query() query: ExportFormatDto,
		@Res({ passthrough: true }) res: Response,
	)
	{
		return this.sendExport(user.id, query, res);
	}

	@ApiOperation({ summary: 'Importe pseudo et/ou email depuis un fichier .json ou .csv (ex: son export). ?dryRun=true pour verifier sans enregistrer' })
	@ApiConsumes('multipart/form-data')
	@ApiBody(importBody)
	@UseGuards(JwtAuthGuard)
	// plus strict que le reste du controller : 10 imports / min
	@Throttle({ default: { limit: 10, ttl: 60_000 } })
	@UseInterceptors(importInterceptor)
	@Post('me/import')
	@HttpCode(200)
	importMyAccount(
		@CurrentUser() user: { id: number },
		@UploadedFile() file: UploadedAccountFile | undefined,
		@Query() query: ImportQueryDto,
	)
	{
		return this.account.importAccount(user.id, file, query.dryRun === 'true');
	}

	//Cles API en masse (connecte au site uniquement : une cle
	// volee ne doit pas pouvoir creer ou supprimer d'autres cles)

	@ApiOperation({ summary: 'Liste mes cles API (sans les cles elles-memes)' })
	@UseGuards(JwtAuthGuard)
	@Get('me/api-keys')
	listMyApiKeys(@CurrentUser() user: { id: number })
	{
		return this.apiKeys.list(user.id);
	}

	@ApiOperation({ summary: 'Cree plusieurs cles API d\'un coup (tout ou rien). Les cles ne sont montrees qu\'une fois' })
	@UseGuards(JwtAuthGuard)
	@Post('me/api-keys/bulk')
	createMyApiKeys(@CurrentUser() user: { id: number }, @Body() dto: BulkCreateApiKeysDto)
	{
		return this.apiKeys.createMany(user.id, dto.labels);
	}

	// POST et pas DELETE : un DELETE avec un body est mal supporte par certains clients
	@ApiOperation({ summary: 'Revoque plusieurs cles API d\'un coup (tout ou rien)' })
	@UseGuards(JwtAuthGuard)
	@Post('me/api-keys/revoke')
	@HttpCode(200)
	revokeMyApiKeys(@CurrentUser() user: { id: number }, @Body() dto: BulkRevokeApiKeysDto)
	{
		return this.apiKeys.revokeMany(user.id, dto.ids);
	}

	@ApiOperation({ summary: "Supprime le compte depuis le site" })
	@UseGuards(JwtAuthGuard)
	@Delete('me')
	deleteMyAccount(@CurrentUser() user: { id: number })
	{
		return this.account.deleteAccount(user.id);
	}

	// apiSecurity pour swagger permet de dire que cette route est protegée par X-API-Key
	@ApiSecurity('X-API-Key')
	@ApiOperation({ summary: 'Mon profil' })
	@UseGuards(ApiKeyGuard)
	@Get()
	getAccount(@CurrentUser() user: { id: number })
	{
		return this.account.getAccount(user.id);
	}

	@ApiSecurity('X-API-Key')
	@ApiOperation({ summary: 'Modifie mon pseudo et/ou mon email' })
	@UseGuards(ApiKeyGuard)
	@Put()
	updateAccount(@CurrentUser() user: { id: number }, @Body() dto: UpdateAccountDto)
	{
		return this.account.updateAccount(user.id, dto);
	}

	@ApiSecurity('X-API-Key')
	@ApiOperation({ summary: 'Supprime (anonymise) mon compte == droit a l\'oubli RGPD' })
	@UseGuards(ApiKeyGuard)
	@Delete()
	deleteAccount(@CurrentUser() user: { id: number })
	{
		return this.account.deleteAccount(user.id);
	}

	@ApiSecurity('X-API-Key')
	@ApiOperation({ summary: 'Export complet de mes donnees (profil + historique de parties) == RGPD. ?format=json (defaut) ou csv' })
	@UseGuards(ApiKeyGuard)
	@Get('export')
	exportAccount(
		@CurrentUser() user: { id: number },
		@Query() query: ExportFormatDto,
		@Res({ passthrough: true }) res: Response,
	)
	{
		return this.sendExport(user.id, query, res);
	}

	@ApiSecurity('X-API-Key')
	@ApiOperation({ summary: 'Importe pseudo et/ou email depuis un fichier .json ou .csv. ?dryRun=true pour verifier sans enregistrer' })
	@ApiConsumes('multipart/form-data')
	@ApiBody(importBody)
	@UseGuards(ApiKeyGuard)
	@Throttle({ default: { limit: 10, ttl: 60_000 } })
	@UseInterceptors(importInterceptor)
	@Post('import')
	@HttpCode(200)
	importAccount(
		@CurrentUser() user: { id: number },
		@UploadedFile() file: UploadedAccountFile | undefined,
		@Query() query: ImportQueryDto,
	)
	{
		return this.account.importAccount(user.id, file, query.dryRun === 'true');
	}

	// JSON : meme reponse qu'avant (objet { user, matches }), le front existant
	// continue de marcher. CSV : vrai fichier a telecharger
	private async sendExport(userId: number, query: ExportFormatDto, res: Response)
	{
		const exported = await this.account.exportAccount(userId);
		if (query.format !== 'csv') return exported;

		const day = new Date().toISOString().slice(0, 10);
		res.setHeader('Content-Type', 'text/csv; charset=utf-8');
		// attachment = le navigateur telecharge au lieu d'afficher
		res.setHeader('Content-Disposition', `attachment; filename="mes-donnees-${day}.csv"`);
		return exportToCsv(exported);
	}
}
