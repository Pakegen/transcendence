import { readIdentityFromFile } from './import-file.js';

const file = (text: string) => Buffer.from(text);

describe('readIdentityFromFile', () => {
	it('relit l\'export JSON tel quel et ignore tout le reste', () => {
		const exported = { user: { id: 1, username: 'bob', email: 'bob@x.fr', elo: 9999 }, matches: [] };
		expect(readIdentityFromFile('mes-donnees.json', file(JSON.stringify(exported)))).toEqual({ username: 'bob', email: 'bob@x.fr' });
	});

	it('accepte un JSON simple avec un seul des deux champs', () => {
		expect(readIdentityFromFile('a.json', file('{"email":" new@x.fr "}'))).toEqual({ email: 'new@x.fr' });
	});

	it('relit l\'export CSV (1re section) et le BOM d\'Excel', () => {
		const csv = '\uFEFFid,username,email,elo\r\n1,bob,bob@x.fr,1000\r\n\r\nmatchId,playedAt\r\n4,2026-01-01\r\n';
		expect(readIdentityFromFile('mes-donnees.CSV', file(csv))).toEqual({ username: 'bob', email: 'bob@x.fr' });
	});

	it('refuse les fichiers vides, mal formes, trop gros ou d\'un autre format', () => {
		expect(() => readIdentityFromFile('a.json', file('{oups'))).toThrow('JSON invalide');
		expect(() => readIdentityFromFile('a.json', file('[1,2]'))).toThrow('objet');
		expect(() => readIdentityFromFile('a.json', file('{"elo":3}'))).toThrow('ni "username" ni "email"');
		expect(() => readIdentityFromFile('a.csv', file('username,email\n'))).toThrow('ligne de valeurs');
		expect(() => readIdentityFromFile('a.csv', file('username\n"bob'))).toThrow('guillemet');
		expect(() => readIdentityFromFile('a.txt', file('bob'))).toThrow('Format non supporte');
		expect(() => readIdentityFromFile('a.json', Buffer.alloc(200 * 1024))).toThrow('trop gros');
	});
});
