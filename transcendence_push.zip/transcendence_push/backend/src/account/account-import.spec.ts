import type { MailService } from '../mail/mail.service.js';
import type { PrismaService } from '../prisma.service.js';
import { AccountService } from './account.service.js';

type FakeUser = { id: number; username: string; email: string; elo: number; twoFactorEnabled: boolean; createdAt: Date };

// Faux Prisma en memoire (juste ce qu'utilise l'import) + faux mail qui note les envois.
// Comme le vrai Prisma, les lectures renvoient des COPIES des lignes
function makeService(users: FakeUser[]) {
	const find = (where: Partial<FakeUser>) => users.find((u) => Object.entries(where).every(([k, v]) => u[k as keyof FakeUser] === v));
	const copy = (user: FakeUser | undefined) => (user ? { ...user } : null);
	const prisma = {
		user: {
			findUnique: async ({ where }: any) => copy(find(where)),
			findUniqueOrThrow: async ({ where }: any) => copy(find(where))!,
			update: async ({ where, data }: any) =>
				copy(Object.assign(find(where)!, Object.fromEntries(Object.entries(data).filter(([, v]) => v !== undefined)))),
		},
	} as unknown as PrismaService;
	const mails: { to: string; text: string }[] = [];
	const mail = { envoyer: async (to: string, _subject: string, text: string) => { mails.push({ to, text }); } } as unknown as MailService;
	return { service: new AccountService(prisma, mail), mails };
}

const players = (): FakeUser[] => [
	{ id: 1, username: 'bob', email: 'bob@x.fr', elo: 1000, twoFactorEnabled: false, createdAt: new Date() },
	{ id: 2, username: 'alice', email: 'alice@x.fr', elo: 1000, twoFactorEnabled: false, createdAt: new Date() },
];
const upload = (text: string, name = 'import.json') => ({ originalname: name, size: text.length, buffer: Buffer.from(text) });

describe('AccountService.importAccount', () => {
	it('dryRun : montre les changements sans rien modifier ni envoyer de mail', async () => {
		const users = players();
		const { service, mails } = makeService(users);
		const result = await service.importAccount(1, upload('{"username":"bobby"}'), true);
		expect(result).toMatchObject({ dryRun: true, updated: false, changes: { username: { before: 'bob', after: 'bobby' } } });
		expect(users[0].username).toBe('bob');
		expect(mails).toHaveLength(0);
	});

	it('enregistre et previent l\'ANCIENNE adresse email', async () => {
		const users = players();
		const { service, mails } = makeService(users);
		const result = await service.importAccount(1, upload('username,email\nbobby,new@x.fr\n', 'import.csv'), false);
		expect(result.updated).toBe(true);
		expect(users[0]).toMatchObject({ username: 'bobby', email: 'new@x.fr' });
		expect(mails[0].to).toBe('bob@x.fr');
	});

	it('valide avec les memes regles que PUT /account', async () => {
		const { service } = makeService(players());
		await expect(service.importAccount(1, upload('{"username":"b!","email":"pas-un-email"}'), false)).rejects.toMatchObject({
			response: { message: expect.arrayContaining([expect.stringContaining('pseudo'), 'email must be an email']) },
		});
	});

	it('refuse un pseudo deja pris par un autre compte, meme en dryRun', async () => {
		const { service } = makeService(players());
		await expect(service.importAccount(1, upload('{"username":"alice"}'), true)).rejects.toThrow('Pseudo déjà pris');
	});

	it('ne fait rien si le fichier contient les valeurs actuelles', async () => {
		const { service, mails } = makeService(players());
		const result = await service.importAccount(1, upload('{"username":"bob","email":"bob@x.fr"}'), false);
		expect(result).toMatchObject({ updated: false, changes: {} });
		expect(mails).toHaveLength(0);
	});
});
