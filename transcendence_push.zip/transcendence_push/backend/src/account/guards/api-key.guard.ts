import { Injectable, UnauthorizedException } from '@nestjs/common';
import type { CanActivate, ExecutionContext } from '@nestjs/common';
import type { Request } from 'express';
import { ApiKeyService } from '../api-key.service.js';

// protege les routes de l'API publique (header X-API-Key)
// Le site contuinue a utiliser le cookie de session

@Injectable()
export class ApiKeyGuard implements CanActivate
{
	constructor(private readonly apiKeys: ApiKeyService) {}

	async canActivate(context: ExecutionContext): Promise<boolean>
	{
		// lit le header et check si valide
		const req = context.switchToHttp().getRequest<Request>();
		const rawKey = req.headers['x-api-key'];
		if (typeof rawKey !== 'string' || !rawKey)
			{throw new UnauthorizedException('header X-API-Key manquant !!');}

		// check si la cle est valide et recupere l'utilisateur
		const user = await this.apiKeys.findUserByRawKey(rawKey);
		if (!user) throw new UnauthorizedException('Key API invalide :(');

		// attache l'utilisateur a la requete comme JwtStrategy pr le cookie de session
		req.user = { id: user.id, email: user.email, username: user.username };
		return true;
	}
}
