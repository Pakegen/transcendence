import type { PrismaService } from '../prisma.service.js';
import { ApiKeyService, MAX_KEYS_PER_USER } from './api-key.service.js';

type FakeKey = { id: number; userId: number; label: string | null; hash: string; createdAt: Date; lastUsedAt: Date | null };

// Faux Prisma en memoire. $transaction rejoue la fonction sur une COPIE et ne
// garde le resultat que si tout a reussi : on peut verifier le "tout ou rien"
function makeService(keys: FakeKey[]) {
	const client = (store: FakeKey[]) => ({
		apiKey: {
			count: async ({ where }: any) => store.filter((k) => k.userId === where.userId).length,
			findMany: async ({ where }: any) =>
				store.filter((k) => k.userId === where.userId && (!where.id || where.id.in.includes(k.id))),
			createManyAndReturn: async ({ data }: any) =>
				data.map((d: any) => {
					const key = { ...d, id: store.length + 1, createdAt: new Date(), lastUsedAt: null };
					store.push(key);
					return key;
				}),
			deleteMany: async ({ where }: any) => {
				const before = store.length;
				const kept = store.filter((k) => !(k.userId === where.userId && where.id.in.includes(k.id)));
				store.splice(0, store.length, ...kept);
				return { count: before - store.length };
			},
		},
	});
	const prisma: any = client(keys);
	prisma.$transaction = async (fn: any) => {
		const copy = keys.map((k) => ({ ...k }));
		const result = await fn(client(copy));
		keys.splice(0, keys.length, ...copy);
		return result;
	};
	return new ApiKeyService(prisma as PrismaService);
}

const key = (id: number, userId: number): FakeKey => ({ id, userId, label: null, hash: `h${id}`, createdAt: new Date(), lastUsedAt: null });

describe('ApiKeyService (operations en masse)', () => {
	it('createMany : cree toutes les cles et renvoie chaque cle en clair une fois', async () => {
		const keys: FakeKey[] = [];
		const created = await makeService(keys).createMany(1, ['stats', 'bot']);
		expect(created.map((k) => k.label)).toEqual(['stats', 'bot']);
		expect(created.every((k) => /^[0-9a-f]{64}$/.test(k.key))).toBe(true);
		expect(created.some((k) => 'hash' in k)).toBe(false);
		expect(keys).toHaveLength(2);
	});

	it('createMany : refuse de depasser la limite par compte, sans rien creer', async () => {
		const keys = Array.from({ length: MAX_KEYS_PER_USER - 1 }, (_, i) => key(i + 1, 1));
		await expect(makeService(keys).createMany(1, ['a', 'b'])).rejects.toThrow(`Limite de ${MAX_KEYS_PER_USER}`);
		expect(keys).toHaveLength(MAX_KEYS_PER_USER - 1);
	});

	it('revokeMany : supprime toutes les cles demandees', async () => {
		const keys = [key(1, 1), key(2, 1), key(3, 1)];
		expect(await makeService(keys).revokeMany(1, [1, 3])).toEqual({ revoked: 2, ids: [1, 3] });
		expect(keys.map((k) => k.id)).toEqual([2]);
	});

	it('revokeMany : tout ou rien si une cle est inconnue ou appartient a un autre compte', async () => {
		const keys = [key(1, 1), key(2, 2)];
		await expect(makeService(keys).revokeMany(1, [1, 2, 9])).rejects.toThrow('Cle(s) introuvable(s) : 2, 9');
		expect(keys).toHaveLength(2);
	});
});
