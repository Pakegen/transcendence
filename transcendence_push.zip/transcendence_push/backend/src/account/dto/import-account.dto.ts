import { IsIn, IsOptional } from 'class-validator';

// POST /account/me/import?dryRun=true : valide le fichier et montre les
// changements SANS les enregistrer. Texte car tout ce qui vient de l'URL est du texte
export class ImportQueryDto
{
	@IsOptional()
	@IsIn(['true', 'false'], { message: 'dryRun doit valoir true ou false.' })
	dryRun?: 'true' | 'false';
}
