import { IsIn, IsOptional } from 'class-validator';

// GET /account/me/export?format=csv (json si absent)
export class ExportFormatDto
{
	@IsOptional()
	@IsIn(['json', 'csv'], { message: 'format doit valoir json ou csv.' })
	format?: 'json' | 'csv';
}
