import { IsEmail, IsOptional, IsString, Matches, MaxLength, MinLength } from 'class-validator';




export class UpdateAccountDto {
	@IsOptional()
	@IsEmail()
	@MaxLength(254)
	email?: string;

	@IsOptional()
	@IsString()
	@MinLength(3)
	@MaxLength(20)
	@Matches(/^[a-zA-Z0-9_-]+$/, {
		message: 'Le pseudo ne peut contenir que des lettres, chiffres, "_" et "-".',
	})
	username?: string;
}
