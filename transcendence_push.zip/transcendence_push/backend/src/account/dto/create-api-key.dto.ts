import { IsOptional, IsString, MaxLength } from 'class-validator';

export class CreateApiKeyDto {
	// nom libre pour se souvenir a quoi sert cette clé
	@IsOptional()
	@IsString()
	@MaxLength(50)
	label?: string;
}
