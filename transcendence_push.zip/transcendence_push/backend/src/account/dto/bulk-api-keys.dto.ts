import { ArrayMaxSize, ArrayMinSize, ArrayUnique, IsArray, IsInt, IsString, MaxLength, Min } from 'class-validator';

// Nombre de cles creees en une seule requete (le total par compte est limite
// a part, voir MAX_KEYS_PER_USER dans api-key.service.ts)
export const MAX_KEYS_PER_REQUEST = 10;

// POST /account/me/api-keys/bulk  { "labels": ["script stats", "bot discord"] }
export class BulkCreateApiKeysDto
{
	@IsArray()
	@ArrayMinSize(1, { message: 'labels doit contenir au moins un nom.' })
	@ArrayMaxSize(MAX_KEYS_PER_REQUEST, { message: `${MAX_KEYS_PER_REQUEST} cles maximum par requete.` })
	// { each: true } = la regle s'applique a CHAQUE element du tableau
	@IsString({ each: true, message: 'chaque label doit etre du texte.' })
	@MaxLength(50, { each: true, message: 'chaque label fait 50 caracteres maximum.' })
	labels: string[];
}

// POST /account/me/api-keys/revoke  { "ids": [3, 7, 12] }
export class BulkRevokeApiKeysDto
{
	@IsArray()
	@ArrayMinSize(1, { message: 'ids doit contenir au moins un identifiant.' })
	@ArrayMaxSize(50, { message: '50 cles maximum par requete.' })
	@ArrayUnique({ message: 'ids contient des doublons.' })
	@IsInt({ each: true, message: 'chaque id doit etre un nombre entier.' })
	@Min(1, { each: true, message: 'chaque id doit etre positif.' })
	ids: number[];
}
