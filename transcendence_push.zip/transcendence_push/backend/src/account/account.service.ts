import { randomUUID } from 'node:crypto';
import { BadRequestException, ConflictException, Injectable } from '@nestjs/common';
import * as argon2 from 'argon2';
import { plainToInstance } from 'class-transformer';
import { validate } from 'class-validator';
import { MailService } from '../mail/mail.service.js';
import { normalizeEmail } from '../auth/normalize-email.js';
import { PrismaService } from '../prisma.service.js';
import { UpdateAccountDto } from './dto/update-account.dto.js';
import { toCsvSections, toCsvTable } from './csv.js';
import { readIdentityFromFile } from './import-file.js';

// Le fichier recu par l'upload (rempli par FileInterceptor de NestJS/multer)
export type UploadedAccountFile = { originalname: string; size: number; buffer: Buffer };

type Change = { before: string; after: string };

@Injectable()
export class AccountService
{
	constructor(
		private readonly prisma: PrismaService,
		private readonly mail: MailService,
	) {}

	async getAccount(userId: number)
	{
		const user = await this.prisma.user.findUniqueOrThrow(
		{
			where: { id: userId },
			select: { id: true, email: true, username: true, elo: true, twoFactorEnabled: true, createdAt: true },
		});
		return user;
	}

	async updateAccount(userId: number, dto: UpdateAccountDto)
	{
		if (dto.email) dto = { ...dto, email: normalizeEmail(dto.email) };

		// email / pseudo deja pris par un AUTRE compte ? (voir assertAvailable)
		await this.assertAvailable(userId, dto);

		// Le check ci-dessus est fait sans transaction: si 2 requetes passent la
		// verif en meme temps pour le meme email/pseudo, l'update ci dessous
		// peut quand meme violer la contrainte unique == on la rattrape ici
		// plutot que de laisser remonter un 500
		try
		{
			const user = await this.prisma.user.update(
			{
				where: { id: userId },
				data: { email: dto.email, username: dto.username },
				select: { id: true, email: true, username: true, elo: true, twoFactorEnabled: true, createdAt: true },
			});
			return user;
		}
		catch (error: any)
		{
			if (error?.code === 'P2002') throw new ConflictException('Email ou pseudo déjà pris');
			throw error;
		}
	}



	// Anon et pas suppression = pas de delete sql
	// Historique adversaire garde une trace qui a le droit de conserver son historique
	// suppr casserait la contrainte de clé étrangere sur Match.player1Id jamais nul != player2Id == IA
	async deleteAccount(userId: number) {

		// email d'origine a garder de cote psq apres il est ecrasé
		const avant = await this.prisma.user.findUniqueOrThrow({ where: { id: userId }, select: { email: true } });

		// rend inutilisable ni par mdp ni par 2FA
		const unusablePassword = await argon2.hash(randomUUID());

		// suffixe aleatoire : "deleted-{id}" serait previsible car id sequentiel et quelqu'un pourrait le pre enregistrer pour bloquer la suppr
		const suffixe = randomUUID().slice(0, 8);

		await this.prisma.$transaction(
		[
			this.prisma.apiKey.deleteMany({ where: { userId } }),
			this.prisma.user.update(
			{
				where: { id: userId },
				data: {
					email: `deleted-${userId}-${suffixe}@deleted.local`,
					username: `deleted-${userId}-${suffixe}`,
					password: unusablePassword,
					twoFactorEnabled: false,
					twoFactorSecret: null,
					// casse le lien avec le compte 42 : se reconnecter via 42 creera un nouveau compte
					fortyTwoId: null,
					deleted: true,
				},
			}),
		]);

		await this.mail.envoyer(
			avant.email,
			'Votre compte a été supprimé',
			"Votre compte et vos données personnelles ont été supprimés suite à votre demande",
		);

		return { ok: true };
	}

	// Export complet data perso
	async exportAccount(userId: number)
	{
		const user_data = await this.prisma.user.findUniqueOrThrow(
		{
			where: { id: userId },
			select: { id: true, email: true, username: true, elo: true, twoFactorEnabled: true, createdAt: true },
		});

		const matches = await this.prisma.match.findMany(
		{
			where: { OR: [{ player1Id: userId }, { player2Id: userId }] }, //OR = soit player1 soit player2
			orderBy: { playedAt: 'asc' },
			include: {
				player1: { select: { username: true } },
				player2: { select: { username: true } },
			},
		});

		await this.mail.envoyer(
			user_data.email,
			'Export de vos données',
			'Un export complet de vos données personnelles (profil + historique de parties) vient d\'être généré suite à votre demande',
		);

		return { user: user_data, matches };
	}

	// Import du pseudo et/ou de l'email depuis un fichier JSON ou CSV
	// (par ex. son propre export, modifie). dryRun = on valide et on montre
	// les changements, SANS rien enregistrer
	async importAccount(userId: number, file: UploadedAccountFile | undefined, dryRun: boolean)
	{
		if (!file) throw new BadRequestException('Aucun fichier recu (champ "file").');

		// 1. lecture : seuls username et email sont gardes
		const identity = readIdentityFromFile(file.originalname, file.buffer);

		// 2. validation : EXACTEMENT les memes regles que PUT /account
		// (UpdateAccountDto), appelee a la main car les donnees viennent du
		// fichier et pas du body de la requete
		const dto = plainToInstance(UpdateAccountDto, identity);
		const errors = await validate(dto);
		if (errors.length > 0)
			throw new BadRequestException(errors.flatMap((error) => Object.values(error.constraints ?? {})));
		// sinon "Toto@mail.com" vs "toto@mail.com" serait vu comme un changement
		if (dto.email) dto.email = normalizeEmail(dto.email);

		// 3. on ne garde que ce qui change vraiment
		const current = await this.prisma.user.findUniqueOrThrow({ where: { id: userId }, select: { username: true, email: true } });
		const changes: { username?: Change; email?: Change } = {};
		if (dto.username && dto.username !== current.username) changes.username = { before: current.username, after: dto.username };
		if (dto.email && dto.email !== current.email) changes.email = { before: current.email, after: dto.email };

		if (!changes.username && !changes.email)
			return { dryRun, updated: false, changes, account: await this.getAccount(userId) };

		const update: UpdateAccountDto = { username: changes.username?.after, email: changes.email?.after };

		// 4. pseudo / email deja pris par un autre compte ? (meme verif qu'updateAccount,
		// faite aussi en dryRun pour que la verification soit fiable)
		if (dryRun)
		{
			await this.assertAvailable(userId, update);
			return { dryRun, updated: false, changes, account: await this.getAccount(userId) };
		}

		// 5. enregistrement : updateAccount refait les verifs et gere la course
		// entre deux requetes (contrainte unique P2002)
		const account = await this.updateAccount(userId, update);

		// confirmation envoyee a l'ANCIENNE adresse : si quelqu'un d'autre a
		// change l'email, le vrai proprietaire est prevenu
		const lines = Object.entries(changes).map(([field, change]) => `- ${field} : ${change.before} -> ${change.after}`);
		await this.mail.envoyer(
			current.email,
			'Import de données sur votre compte',
			`Les informations de votre compte ont été modifiées par import de fichier :\n${lines.join('\n')}\n\nSi vous n'êtes pas à l'origine de ce changement, contactez-nous.`,
		);

		return { dryRun, updated: true, changes, account };
	}

	private async assertAvailable(userId: number, dto: UpdateAccountDto)
	{
		if (dto.email)
		{
			const owner = await this.prisma.user.findUnique({ where: { email: dto.email } });
			if (owner && owner.id !== userId) throw new ConflictException('Email déja pris');
		}
		if (dto.username)
		{
			const owner = await this.prisma.user.findUnique({ where: { username: dto.username } });
			if (owner && owner.id !== userId) throw new ConflictException('Pseudo déjà pris');
		}
	}
}

// Export au format CSV : deux tableaux dans le meme fichier, separes par une
// ligne vide. 1) le profil (1 ligne), 2) l'historique des parties.
// La 1re section est relisible telle quelle par l'import (colonnes username, email)
export function exportToCsv(exported: Awaited<ReturnType<AccountService['exportAccount']>>): string
{
	const profile = toCsvTable(['id', 'username', 'email', 'elo', 'twoFactorEnabled', 'createdAt'], [exported.user]);
	const matches = toCsvTable(
		['matchId', 'playedAt', 'player1', 'player2', 'faction1', 'faction2', 'result'],
		exported.matches.map((match) => ({
			matchId: match.id,
			playedAt: match.playedAt,
			player1: match.player1.username,
			// player2 null == partie contre l'IA
			player2: match.player2?.username ?? 'IA',
			faction1: match.faction1,
			faction2: match.faction2,
			result: match.result,
		})),
	);
	return toCsvSections([profile, matches]);
}
