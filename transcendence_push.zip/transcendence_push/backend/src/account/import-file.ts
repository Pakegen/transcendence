import { BadRequestException } from '@nestjs/common';
import { parseCsv } from './csv.js';

// Lecture du fichier d'import du compte : on n'en garde QUE le pseudo et
// l'email (tout le reste, ex: elo ou historique d'un export, est ignore).

export const MAX_IMPORT_BYTES = 100 * 1024; // 100 Ko, largement assez pour un export

export type ImportedIdentity = { username?: string; email?: string };


//un JSON simple : { "username": ..., "email": ... }
function readJson(text: string): ImportedIdentity
{
	let parsed: unknown;
	try
	{
		parsed = JSON.parse(text);
	}
	catch
	{
		throw new BadRequestException('JSON invalide.');
	}
	if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed))
		throw new BadRequestException('JSON invalide : un objet { "username", "email" } est attendu.');

	const root = parsed as Record<string, unknown>;
	const user = root.user && typeof root.user === 'object' ? (root.user as Record<string, unknown>) : root;
	return pick(user.username, user.email);
}

// Accepte l'export CSV tel quel (1re section = le profil) ou un CSV simple :
//   username,email
//   bob,bob@exemple.fr
// Seules les 2 premieres lignes non vides comptent (en-tete + valeurs)
function readCsv(text: string): ImportedIdentity
{
	const lines = parseCsv(text);
	if (!lines) throw new BadRequestException('CSV invalide : guillemet non ferme.');
	const [header, values] = lines;
	if (!header || !values) throw new BadRequestException('CSV invalide : une ligne d\'en-tete et une ligne de valeurs sont attendues.');

	const columns = header.map((name) => name.trim());
	const value = (column: string) =>
	{
		const index = columns.indexOf(column);
		return index === -1 ? undefined : values[index];
	};
	return pick(value('username'), value('email'));
}

// Garde seulement les valeurs texte non vides. Un champ absent ou vide = "ne pas modifier"
function pick(username: unknown, email: unknown): ImportedIdentity
{
	const identity: ImportedIdentity = {};
	if (typeof username === 'string' && username.trim()) identity.username = username.trim();
	if (typeof email === 'string' && email.trim()) identity.email = email.trim();
	if (!identity.username && !identity.email)
		throw new BadRequestException('Le fichier ne contient ni "username" ni "email".');
	return identity;
}

export function readIdentityFromFile(filename: string, content: Buffer): ImportedIdentity
{
	if (content.length > MAX_IMPORT_BYTES) throw new BadRequestException('Fichier trop gros (100 Ko maximum).');

	// BOM = caractere invisible qu'Excel ajoute au debut des CSV UTF-8
	const text = content.toString('utf8').replace(/^\uFEFF/, '');
	const extension = filename.toLowerCase().split('.').pop();
	if (extension === 'json') return readJson(text);
	if (extension === 'csv') return readCsv(text);
	throw new BadRequestException('Format non supporte : fichier .json ou .csv attendu.');
}
