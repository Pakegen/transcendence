import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { PassportModule } from '@nestjs/passport';
import { requireEnv } from '../env.js';
import { MailModule } from '../mail/mail.module.js';
import { AccountController } from './account.controller.js';
import { AccountService } from './account.service.js';
import { ApiKeyService } from './api-key.service.js';
import { ApiKeyGuard } from './guards/api-key.guard.js';

@Module({
	imports: [
		PassportModule.register({ defaultStrategy: 'jwt' }),
		JwtModule.register({ secret: requireEnv('JWT_SECRET') }),
		MailModule,
	],
	controllers: [AccountController],
	providers: [AccountService, ApiKeyService, ApiKeyGuard],
})
export class AccountModule {}
