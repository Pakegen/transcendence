import { randomBytes, createHash } from 'node:crypto';
import { BadRequestException, ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma.service.js';


// Nombre max de cles par compte : evite qu'un compte en cree des milliers
// (la creation en masse rendrait ca trivial)
export const MAX_KEYS_PER_USER = 20;

// Ce qu'on montre d'une cle : JAMAIS le hash
const PUBLIC_FIELDS = { id: true, label: true, createdAt: true, lastUsedAt: true } as const;

// détermiste = trouvable par findUnique
function hashKey(rawKey: string): string
{
	// update = permet de hasher raw<key; digest = transforme en hexa
	return createHash('sha256').update(rawKey).digest('hex');
}

@Injectable()
export class ApiKeyService
{
	constructor(private readonly prisma: PrismaService)
		{}

	// Cree une nouvelle clé pour ce user. La clé en clair n'est renvoyee
	// qu'ici, une seule fois: on ne stocke que son hash.

	//pas de stock de hash, envoyé en clair qu'ici une seule fois
	async create(userId: number, label: string | undefined)
	{

		await this.assertRoomForKeys(this.prisma, userId, 1);

		// randomBytes donne 32o, converti en hexa = 64 caracteres
		const rawKey = randomBytes(32).toString('hex');
		const apiKey = await this.prisma.apiKey.create(
		{
			data: { userId, label, hash: hashKey(rawKey) },
		});
		return { id: apiKey.id, label: apiKey.label, createdAt: apiKey.createdAt, key: rawKey };
	}

	// Retrouve l'utilisateur proprietaire d'une clé presentee en clair
	// (par le guard, a chaque requete sur l'API publique). null si invalide.

	// Cherhce l'user proprio de la clé en clair + null si invalide
	async findUserByRawKey(rawKey: string)
	{
		// include user true pour choper l'user
		const apiKey = await this.prisma.apiKey.findUnique(
		{
			where: { hash: hashKey(rawKey) },
			include: { user: true },
		});

		if (!apiKey) return null;

		// pas besoin d'att la fin de cette requete pour rep
		// + met a jour lastUsedAt
		// void pour juste attendre la fin de la req et pas besoin de sa reponse
		// .catch() : si la cle est supprimee entre temps (ex compte supprime
		// en parallele), l'update echoue (P2025) mais ne doit pas planter le process
		void this.prisma.apiKey.update(
		{
			where: { id: apiKey.id },
			data: { lastUsedAt: new Date() },
		}).catch(() => {});

		return apiKey.user;
	}

	// Operations en masse : bulk

	// Liste mes cles (sans jamais le hash ni la cle en clair)
	async list(userId: number)
	{
		return this.prisma.apiKey.findMany(
		{
			where: { userId },
			select: PUBLIC_FIELDS,
			orderBy: { createdAt: 'desc' },
		});
	}

	// Cree plusieurs cles d'un coup, tout ou rien. Comme pour create(), les
	// cles en clair ne sont renvoyees qu'ici, une seule fois
	async createMany(userId: number, labels: string[])
	{
		// les cles en clair sont generees ici, seuls leurs hash vont en base.
		// rawByHash permet de retrouver la cle en clair de chaque ligne creee
		const rawByHash = new Map<string, string>();
		for (let i = 0; i < labels.length; i++)
		{
			const rawKey = randomBytes(32).toString('hex');
			rawByHash.set(hashKey(rawKey), rawKey);
		}
		const hashes = [...rawByHash.keys()];

		try
		{
			// transaction interactive en isolation "Serializable" : le comptage et
			// la creation forment un seul bloc. Si deux requetes en parallele
			// depassaient ensemble la limite, PostgreSQL fait echouer l'une des deux
			const created = await this.prisma.$transaction(async (tx) =>
			{
				await this.assertRoomForKeys(tx, userId, labels.length);
				// createManyAndReturn = UN seul INSERT pour toutes les cles,
				// et renvoie les lignes creees
				return tx.apiKey.createManyAndReturn(
				{
					data: labels.map((label, i) => ({ userId, label: label.trim() || null, hash: hashes[i] })),
					select: { ...PUBLIC_FIELDS, hash: true },
				});
			}, { isolationLevel: 'Serializable' });

			// on remplace le hash (jamais montre) par la cle en clair
			return created.map(({ hash, ...apiKey }) => ({ ...apiKey, key: rawByHash.get(hash)! }));
		}
		catch (error: any)
		{
			// P2034 = conflit entre deux transactions simultanees (Serializable)
			if (error?.code === 'P2034') throw new ConflictException('Requetes simultanees, reessayez.');
			throw error;
		}
	}

	// Revoque (supprime) plusieurs cles d'un coup, tout ou rien : si UN seul id
	// n'existe pas ou appartient a quelqu'un d'autre, rien n'est supprime
	async revokeMany(userId: number, ids: number[])
	{
		return this.prisma.$transaction(async (tx) =>
		{
			// where userId : on ne voit que SES cles. Une cle d'un autre compte
			// est traitee exactement comme une cle inexistante (on ne revele rien)
			const owned = await tx.apiKey.findMany({ where: { id: { in: ids }, userId }, select: { id: true } });
			if (owned.length !== ids.length)
			{
				const ownedIds = new Set(owned.map((key) => key.id));
				const missing = ids.filter((id) => !ownedIds.has(id));
				throw new NotFoundException(`Cle(s) introuvable(s) : ${missing.join(', ')}. Aucune cle n'a ete revoquee.`);
			}

			// deleteMany = UN seul DELETE pour toutes les cles
			const { count } = await tx.apiKey.deleteMany({ where: { id: { in: ids }, userId } });
			return { revoked: count, ids };
		});
	}

	// tx = le client Prisma normal OU celui d'une transaction en cours
	private async assertRoomForKeys(tx: Pick<PrismaService, 'apiKey'>, userId: number, adding: number)
	{
		const current = await tx.apiKey.count({ where: { userId } });
		if (current + adding > MAX_KEYS_PER_USER)
		{
			throw new BadRequestException(
				`Limite de ${MAX_KEYS_PER_USER} cles par compte : vous en avez ${current}, impossible d'en ajouter ${adding}.`,
			);
		}
	}
}
