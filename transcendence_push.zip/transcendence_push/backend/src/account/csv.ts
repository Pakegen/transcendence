
export type CsvValue = string | number | boolean | Date | null | undefined;

// Une cellule qui commence par = + - @ serait executee comme une FORMULE par
// Excel/LibreOffice a l'ouverture ("CSV injection", recommandation OWASP) :
// on la desactive avec une apostrophe devant
function neutralizeFormula(text: string): string
{
	return /^[=+\-@\t\r]/.test(text) ? `'${text}` : text;
}

function csvCell(value: CsvValue): string
{
	if (value === null || value === undefined) return '';
	let text: string;
	if (value instanceof Date) text = value.toISOString();
	else if (typeof value === 'string') text = neutralizeFormula(value);
	else text = String(value);
	// guillemets obligatoires si la cellule contient , " ou un retour a la ligne,
	// et un " a l'interieur s'ecrit "" (norme RFC 4180)
	return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

// Un tableau CSV = une ligne d'en-tete (noms de colonnes) + une ligne par objet
export function toCsvTable(columns: string[], rows: Record<string, CsvValue>[]): string
{
	const lines = [columns.join(',')];
	for (const row of rows) lines.push(columns.map((column) => csvCell(row[column])).join(','));
	return lines.join('\r\n');
}

// Plusieurs tableaux dans un meme fichier, separes par une ligne vide
// (ex : le profil, puis l'historique de parties)
export function toCsvSections(tables: string[]): string
{
	return tables.join('\r\n\r\n') + '\r\n';
}

// Decoupe un CSV en lignes de cellules, caractere par caractere, pour gerer
// les "..." qui peuvent contenir des virgules, des "" et des retours a la ligne.
// Les lignes vides sont ignorees. null si un guillemet n'est jamais ferme
export function parseCsv(text: string): string[][] | null
{
	const lines: string[][] = [];
	let line: string[] = [];
	let cell = '';
	let quoted = false;

	for (let i = 0; i < text.length; i++)
	{
		const char = text[i];
		if (quoted)
		{
			if (char === '"' && text[i + 1] === '"') { cell += '"'; i++; }
			else if (char === '"') quoted = false;
			else cell += char;
		}
		else if (char === '"') quoted = true;
		else if (char === ',') { line.push(cell); cell = ''; }
		else if (char === '\n' || char === '\r')
		{
			// \r\n (Windows) compte pour UNE seule fin de ligne
			if (char === '\r' && text[i + 1] === '\n') i++;
			line.push(cell);
			lines.push(line);
			line = [];
			cell = '';
		}
		else cell += char;
	}
	if (quoted) return null;
	if (cell !== '' || line.length > 0)
	{
		line.push(cell);
		lines.push(line);
	}
	return lines.filter((l) => !(l.length === 1 && l[0].trim() === ''));
}
