import { parseCsv, toCsvSections, toCsvTable } from './csv.js';

describe('csv', () => {
	it('aller-retour : ce qui est ecrit se relit a l\'identique', () => {
		const rows = [{ a: 'avec, virgule', b: 'il a dit "salut"' }, { a: 'sur\ndeux lignes', b: '' }];
		expect(parseCsv(toCsvTable(['a', 'b'], rows))).toEqual([['a', 'b'], ['avec, virgule', 'il a dit "salut"'], ['sur\ndeux lignes', '']]);
	});

	it('ecrit les dates en ISO, les nombres et booleens en texte, null en vide', () => {
		const date = new Date('2026-10-08T12:00:00Z');
		expect(toCsvTable(['d', 'n', 'b', 'v'], [{ d: date, n: 3, b: false, v: null }])).toBe('d,n,b,v\r\n2026-10-08T12:00:00.000Z,3,false,');
	});

	it('neutralise les formules (CSV injection)', () => {
		expect(toCsvTable(['a'], [{ a: '=HYPERLINK("x")' }])).toBe(`a\r\n"'=HYPERLINK(""x"")"`);
	});

	it('plusieurs sections separees par une ligne vide, ignoree a la lecture', () => {
		const csv = toCsvSections([toCsvTable(['a'], [{ a: 1 }]), toCsvTable(['b'], [{ b: 2 }])]);
		expect(csv).toBe('a\r\n1\r\n\r\nb\r\n2\r\n');
		expect(parseCsv(csv)).toEqual([['a'], ['1'], ['b'], ['2']]);
	});

	it('renvoie null si un guillemet n\'est jamais ferme', () => {
		expect(parseCsv('a\n"oups')).toBeNull();
	});
});
