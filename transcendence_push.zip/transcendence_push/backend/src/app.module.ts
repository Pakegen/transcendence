import { Module } from '@nestjs/common';
import { AppController } from './app.controller.js';
import { AppService } from './app.service.js';
import { AccountModule } from './account/account.module.js';
import { AuthModule } from './auth/auth.module.js';
import { MatchmakingModule } from './matchmaking/matchmaking.module.js';
import { PrismaModule } from './prisma.module.js';
import { StatsModule } from './stats/stats.module.js';

@Module({
	imports: [PrismaModule, AuthModule, StatsModule, MatchmakingModule, AccountModule],
	controllers: [AppController],
	providers: [AppService],
})
export class AppModule {}
