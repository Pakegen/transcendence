#!/usr/bin/env python3

# #! is the launch instruction, tells the environment which program to find and launch
# Python itself treats that line as a comment. Running python3 motor.py also works.

# A module loaded is a Python file or library we can import and reuse.
# import is similar to includes, 
import copy # to use copy and deep copy, when you want to change the original or not
import itertools # useful for combinations, so we don't get the same group in a different order
import json # load to grab, dump to make
# from ... import ... brings in one particular name instead of the whole module.
from pathlib import Path # Path is a class: calling Path(...) creates an object representing a file path.
import random
import re # pattern matching tools for Python
import sys # argv for input arguments, stderr for errors, exit for the result code

# These imports come from our own neighbouring files, without the .py suffix.
# Importing loads a module and makes its definitions available; importing a function
# name does not call that function. Parentheses are what call it later.
from mulligan import InvalidCommand # Signal an invalid request.
from mulligan import StateError  # Custom Signal missing or inconsistent game data.
from mulligan import resolve_mulligans
from game_state import refresh_state

from turns import apply_command
from turns import apply_timeout
from turns import first_turn # Prepare round 1 and advance to the first player's input.
from turns import legal_commands
from turns import result_code  # Return the status number expected by the backend.

from ai import choose_command # Select the AI's next action.
from ai import prediction_folder


# Get this script's folder so files can be found regardless of where Python is launched
# Uppercase names are a convention for settings.
# __file__ is the path Python gives this module. = assigns a value to a name.
# __file__ is python syntax
BASE = Path(__file__)
# resolve() makes the path absolute and resolves symbolic links.
BASE = BASE.resolve()
# parent is the containing directory.
#  It is an attribute so no call ()
BASE = BASE.parent
# A dictionary stores key/value pairs written as key: value inside braces
PLAYER_TEMPLATES = {
	1: "player1_game_state_template copy.json",
	2: "player2_game_state_template.json",
}
CHANGE_NOTE = "Ok"

# Read a file, turn its JSON text into Python data, and require a dictionary result.
# Here JSON objects become dictionaries, arrays become lists, and null becomes None.
def read_json(path):
	# Read a JSON object from a UTF-8 file, accepting an optional BOM.
	# byte-order mark (BOM), a marker some editors add to UTF-8 files.
	text = path.read_text(encoding="utf-8-sig")
	# loads parses JSON text. The final s means we are passing a string, not a file.
	data = json.loads(text)
	# isinstance(value, type) checks a value's type, including subclasses of that type.
	if not isinstance(data, dict): # check if it's a dictionary
		raise StateError(f"{path.name} must contain a JSON object.") # f allows expressions inside {} to be inserted into the string
	return data

# Check the room and player tokens, then return each seat's player type and deck.
def parse_players(room, action, player1, player2):
	# re.fullmatch checks the entire string against a regular-expression pattern.
	if not re.fullmatch(r"[0-9]{2}", room): # [0-9] means one ASCII digit; {2} means exactly two repetitions
		raise ValueError("Room must be exactly two digits, 00 through 99.")
	# ValueError is Python's built-in error for an inappropriate value.
	if action != "I":
		raise ValueError("Initialization requires action I.")
	players = [] # it's to create an empty list
	# A list, made with [], stores an ordered sequence of items and can be changed.
	# A tuple, made here with (player1, player2), is ordered but cannot replace its items.
	# for repeats a block for each item. enumerate supplies both a count and the ite for repeats 
	for number, token in enumerate((player1, player2), start=1): # enumerate pairs each item with a number, here we start at 1
		# r raw-string  
		# [PI] aind [12] alloed
		if not re.fullmatch(rf"[PI]{number}[12]", token): # token here represents a player code like P11 P12 P21 P22
			raise ValueError(
				f"Player {number} must use P{number}1, P{number}2, "
				f"I{number}1, or I{number}2."
			)
		if token[0] == "I":
			kind = "AI"
		else:
			kind = "Human"
		if kind == "AI":
			deck = 1
		else:
		# int converts digit text to the integer
			deck = int(token[2])
		players.append((kind, deck))
	ai_count = 0
	# _ is an ordinary variable name conventionally used for a value we do not need.
	for kind, _ in players:
		if kind == "AI":
			ai_count = ai_count + 1
	if ai_count > 1:
		raise ValueError("At most one AI is allowed.")
	return players
# parse_players("07", "I", "P12", "I22") gives [("Human", 2), ("AI", 1)]


def mulligan_commands(hand, player):
	if player == 1:
		limit = 3
	else:
		limit = 2
	commands = []
	# sorted returns a new ordered list, it does not reorder hand itself
	sorted_hand = sorted(hand)
	# range(stop) supplies integers from 0 up to, but not including, stop
	# Adding 1 includes limit, so we offer exchanges of zero cards through the maximum
	for count in range(limit + 1):
		# combinations gives every group of count distinct positions, without rearranging
		# those positions. For [101, 102, 103] and count=2 it gives (101, 102), (101, 103),
		# then (102, 103). It does not also give the reversed pair (102, 101).
		# count=0 gives one empty tuple, which creates the keep-all command.
		for selected in itertools.combinations(sorted_hand, count):
			command = f"{player}5"
			empty_slots = limit - count
			# Multiplying text by a number repeats it; "000" * 2 gives "000000".
			command = command + "000" * empty_slots
			for card in selected:
				# :03d formats an integer with at least three digits, adding leading zeros.
				command = command + f"{card:03d}"
			commands.append(command)
	return commands


#player_view builds a dictionary containing only the information that player is allowed to see, plus their available commands.
def player_view(state, player):
	# dictionary[key] retrieves that key's value; a missing key raises KeyError.
	template_name = PLAYER_TEMPLATES[player]
	# For Path objects, / joins a directory and a child name instead of dividing.
	template_path = BASE / template_name
	view = read_json(template_path)
	# Looping over a dictionary gives its keys, not its values.
	for key in view:
		# "in" checks whether this key exists in the dictionary.
		if key in state:
			# deepcopy copies nested lists and dictionaries without sharing them.
			view[key] = copy.deepcopy(state[key])
	# str converts the player number to a string:
	player_key = str(player)
	player_commands = state["Available_Commands"][player_key]
	view["Available_Commands"] = copy.deepcopy(player_commands)
	# get returns the stored value, or CHANGE_NOTE if the key is missing.
	view["_comment"] = state.get("_comment", CHANGE_NOTE)
	return view


# Create a fresh match from templates, shuffle each deck, deal hands and save it.
# output_dir chooses where room files go; rng optionally supplies a random generator
# Defaults after = are used when the caller omits those arguments.
def initialize(room, action, player1, player2, output_dir=None, rng=None):
	players = parse_players(room, action, player1, player2)
	state = read_json(BASE / "motor_game_state_template.json")

	# Check whether either player is AI
	state["Game_Type"] = "PvP"
	for kind, deck in players:
		if kind == "AI":
			state["Game_Type"] = "AI"

	# Set the starting phase, counters and player priority
	state["Room_number"] = room
	state["Game_Phase"] = "Mulligan"
	# Assigning dictionary[key] creates or replaces that entry in the dictionary
	state["Mulligan"] = True
	state["Round_number"] = 0
	state["Active_Player"] = 0
	state["Active_Opponent"] = 0
	state["Card_has_been_played"] = 0
	state["Turn_number"] = 0
	state["Last_Command"] = f"I {player1} {player2}"
	state["_comment"] = CHANGE_NOTE

	if rng is None:
		rng = random.SystemRandom()

	# set() creates an empty set. Unlike a list, it stores no duplicate values and
	# is used here only for membership, not for an ordered sequence of card keys
	retained = set()

	for player, player_info in enumerate(players, start=1):
		# Unpack the player's tuple into its type and deck number.
		kind, deck = player_info
		prefix = f"Player_{player}"

		state[f"{prefix}_Type"] = kind # Select the key

		# range excludes its endpoint: range(1, 26) gives 1 through 25.
		if deck == 1:
			state[f"{prefix}_Decklist"] = "Witcher"
			short_ids = range(1, 26)
		else:
			state[f"{prefix}_Decklist"] = "Wild Hunt"
			short_ids = range(27, 52)

		# Build the player's card IDs and remember their record keys.
		cards = []
		for short_id in short_ids:
			# Numeric * multiplies. Player 1 with short ID 8 becomes card ID 108.
			# This is different from repeating text with *, as used in the command builder.
			card = player * 100 + short_id
			cards.append(card)

			# add inserts one value into a set.
			retained.add(f"Card_{card}")

		# shuffle changes the order of the existing list.
		rng.shuffle(cards)

		# A slice uses [start:stop]. The start is included and the stop is excluded.
		state[f"{prefix}_Hand"] = cards[:10] # cards[:10] takes the first 10 elements, at positions 0 through 9, and stores them in the hand.
		state[f"{prefix}_Deck"] = cards[10:]# cards[10:] takes everything from position 10 to the end and stores it in the deck.
		# Slicing Syntax

		# Hand uses zone code 2 and deck uses zone code 1. Positions are numbered from 1
		# Each pair contains a zone's name and its location code.
		zones = (("Hand", 2), ("Deck", 1))
		for zone_name, zone_code in zones:
			zone_cards = state[f"{prefix}_{zone_name}"]

			for position, card in enumerate(zone_cards, start=1):
				# No deep copy here
				entry = state[f"Card_{card}"]
				entry["Exist"] = True

				# :02d formats the position with at least two digits, such as 01.
				entry["Location"] = f"{player}{zone_code}{position:02d}"

		# unused
		deck_cards = state[f"{prefix}_Deck"]
		roach = player * 100 + 8
		winter_queen = player * 100 + 32
		state[f"Player {player} Roach in Deck"] = roach in deck_cards
		state[f"Player {player} Winter Queen in Deck"] = winter_queen in deck_cards

	# players[0] is P1's tuple; [1] selects its deck number.
	player1_deck = players[0][1]
	if player1_deck == 1:
		stratagem = 126
	else:
		stratagem = 152

	# Keep P1's stratagem aside, outside the hand and deck for now.
	stratagem_key = f"Card_{stratagem}"
	retained.add(stratagem_key)
	state[stratagem_key]["Exist"] = True
	state[stratagem_key]["Location"] = "0000"
	state["Player_1_Stratagem"] = stratagem

	# Copy the keys into a list before deleting entries from the dictionary.
	# list(state) snapshots the keys. Deleting keys while directly iterating state
	# would otherwise change the dictionary's size during iteration and raise an error.
	for key in list(state):
		# startswith checks the prefix; [5:] gets everything after "Card_".
		if key.startswith("Card_"):
			card_number = key[5:]

			# isdigit excludes non-card keys such as Card_has_been_played.
			# isdigit requires nonempty text made of digit characters. This keeps ordinary
			# tracking fields such as Card_has_been_played out of the card-removal logic.
			if card_number.isdigit():
				if key not in retained:
					# del removes the dictionary entry.
					del state[key]

	# Save the three documents  and return the result from write_room
	return write_room(room, state, output_dir)


# Refresh the private state and legal offers, build both player views, 
def write_room(room, state, output_dir=None):
	# This function updates the supplied state dictionary in place.
	refresh_state(state)

	# Load the card catalogue only when the game is in Turn phase.
	if state["Game_Phase"] == "Turn":
		library = read_json(BASE / "library.json")
	else:
		# {} creates an empty dictionary.
		library = {}

	# Build all offers before replacing the state's command dictionary.
	available_commands = {}
	for player in (1, 2):
		if state["Game_Phase"] == "Mulligan":
			# An f-string inserts the player number into the field name.
			hand = state[f"Player_{player}_Hand"]
			commands = mulligan_commands(hand, player)
		else:
			commands = legal_commands(state, player, library)

		available_commands[str(player)] = commands

	state["Available_Commands"] = available_commands

	documents = {
		f"{room}M.json": state,
		f"{room}1.json": player_view(state, 1),
		f"{room}2.json": player_view(state, 2),
	}

	# Building the documents dictionary evaluates each value in order. Both filtered
	# views therefore exist before writing starts; the full state remains private.

	# Convert every document to text before writing any files.
	serialized = {}

	# items() gives each dictionary entry as a key/value pair.
	for name, data in documents.items():
		# dumps creates JSON text; indent=2 uses two spaces in that text.
		# "\n" adds a newline at the end of the file.
		# dumps is the reverse of loads: Python data becomes JSON text.
		serialized[name] = json.dumps(data, indent=2) + "\n"

	if output_dir is None:
		destination = BASE
	else:
		destination = Path(output_dir)
	for name, content in serialized.items():
		# / joins a Path directory and a filename
		file_path = destination / name
		# write_text creates or replaces the file, then closes it
		file_path.write_text(content, encoding="utf-8")

	return documents

# Old See later
def refresh_cards(state):
	refresh_state(state)

# Save the accepted action, then run and save AI actions until human input is needed
def publish_and_run_ai(room, state, output_dir=None):
	if output_dir is None:
		directory = BASE
	else:
		directory = Path(output_dir)

	# Save the accepted state before checking whether the AI must act.
	documents = write_room(room, state, output_dir)

	library = None
	turn_identity = None

	# This loop may include several actions in one turn or several turns in sequence.
	# range(1000) allows at most 1,000 iterations but no decomp
	for _ in range(1000):
		if state["Game_Phase"] != "Turn":
			return documents

		# Check the phase first: a finished game has no active player.
		player = state["Active_Player"]
		if state[f"Player_{player}_Type"] != "AI":
			return documents

		# Load the catalogue once on the first AI iteration
		if library is None:
			library = read_json(BASE / "library.json")

		# A tuple groups the three values that identify the current turn.
		identity = (state["Round_number"], state["Turn_number"], player)

		# Tuple equality compares corresponding values. A different round, turn or player
		# means this is a new turn and its starting margin must be captured again.
		if identity != turn_identity:
			turn_identity = identity

			# With players 1 and 2, 3 - player gives the other player
			opponent = 3 - player
			own_score = state[f"Player_{player}_Board_Strength"]
			opponent_score = state[f"Player_{opponent}_Board_Strength"]
			start_margin = own_score - opponent_score

		# Keep start_margin unchanged for further actions in the same turn.
		views = {}
		for seat in (1, 2):
			# These keys are integers, unlike the state's command-map keys.
			views[seat] = documents[f"{room}{seat}.json"]

		# Choose an action, then apply it through the normal game rules.
		command = choose_command(room, state, views, library, directory, start_margin)

		# apply_command returns a new state; assignment replaces the local reference.
		state = apply_command(room, state, views, command, library)
		state["_comment"] = "AI action resolved through normal rules."
		documents = write_room(room, state, output_dir)

	# This is an internal safety guard, not a limit on a match's turns.
	raise StateError("AI automatic progression exceeded its internal safety bound.")


# Load the private state and both views, validate and apply the opening exchanges,
# start the first turn, then let the AI act if needed. Return the saved documents.
def mulligan(room, commands, output_dir=None, rng=None):
	# fullmatch checks the entire room string: exactly two digits.
	if not re.fullmatch(r"[0-9]{2}", room):
		raise InvalidCommand("Room must be exactly two digits, 00 through 99.")

	if output_dir is None:
		directory = BASE
	else:
		directory = Path(output_dir)

	# try marks operations whose errors we want to handle below.
	try:
		state = read_json(directory / f"{room}M.json")
		views = {}
		for player in (1, 2):
			views[player] = read_json(directory / f"{room}{player}.json")
	# OSError covers filesystem problems; ValueError includes malformed JSON.
	except (OSError, ValueError) as error:
		raise StateError(f"Cannot load room {room}: {error}") from error
	if state.get("Game_Type") == "AI":
		library = read_json(BASE / "library.json")
	else:
		library = None

	state = resolve_mulligans(room, state, views, commands, mulligan_commands, rng, library)

	if state["Game_Type"] == "AI":
		prediction_folder(directory, room, reset=True)

	# join combines strings with a space between each pair.
	state["Last_Command"] = "M " + " ".join(commands)

	# first_turn adds the reserved Stratagem to P1's hand and sets up turn priority.
	first_turn(state)
	state["_comment"] = "Mulligans resolved; stratagem in P1 hand; first turn ready."

	return publish_and_run_ai(room, state, output_dir)


# Load and resolve one player command or timeout, then save and process AI replies.
# rejects external commands on AI turns and delegates actual game rules.
# Default timeout=False selects a player action. None for command is used on timeout.
# The bare * makes timeout and rng keyword-only: use timeout=True or rng=... .
def play(room, command, output_dir=None, *, timeout=False, rng=None):
	if not re.fullmatch(r"[0-9]{2}", room):
		raise InvalidCommand("Room must be exactly two digits, 00 through 99.")

	if output_dir is None:
		directory = BASE
	else:
		directory = Path(output_dir)

	try:
		state = read_json(directory / f"{room}M.json")

		views = {}
		for player in (1, 2):
			views[player] = read_json(directory / f"{room}{player}.json")

		library = read_json(BASE / "library.json")

	except (OSError, ValueError) as error:
		raise StateError(f"Cannot load room/catalogue: {error}") from error

	# Nested if statements check player type only during Turn phase.
	if state.get("Game_Phase") == "Turn":
		player = state.get("Active_Player")
		if state.get(f"Player_{player}_Type") == "AI":
			raise InvalidCommand("AI turns are handled internally, not by Front or a timer.")

	# timeout selects the timer action instead of a supplied player command.
	if timeout:
		state = apply_timeout(room, state, views, library, rng)
	else:
		state = apply_command(room, state, views, command, library)

	state["_comment"] = "Mo Player action resolved and all state checks refreshed."
	return publish_and_run_ai(room, state, output_dir)


# Read the command-line request, call the appropriate operation and return a status.
# 0 means successful initialization; 1/2 mean a human seat has priority; 61/62/63
# 61/62/63 mean a winner or draw. 3 is an invalid request; 4 is a state or internal failure.
# Returning a status here is separate from exiting the process at the bottom.
def main(argv=None):
	if argv is None:
		args = sys.argv[1:]
	else:
		args = argv
	# this is for code testing

	# len gives the number of items; we need at least room and action
	if len(args) < 2:
		print(
			"Usage: ./motor.py XX I A1B C2D | XX M <human-code> "
			"[<human-code>] | XX P <code> | XX T",
			file=sys.stderr,
		)
		return 3

	try:
		room = args[0]
		action = args[1]
		# *payload collects all remaining arguments into a list.
		# list keeps payload a list even if a test supplied argv as a tuple.
		payload = list(args[2:])

		if action == "I" and len(payload) == 2:
			# *payload expands its two items into two separate arguments.
			# That was the earlier shorthand; here we supply both items explicitly.
			initialize(room, action, payload[0], payload[1])
			return 0

		if action == "M":
			docs = mulligan(room, payload)

			state = docs[f"{room}M.json"]
			return result_code(state)

		if action == "P" and len(payload) == 1:
			# [0] retrieves the first and only supplied command.
			docs = play(room, payload[0])
			state = docs[f"{room}M.json"]
			return result_code(state)

		# An empty list is false, so "not payload" means no extra arguments.
		if action == "T" and not payload:
			docs = play(room, None, timeout=True)
			state = docs[f"{room}M.json"]
			return result_code(state)

		raise InvalidCommand("Unsupported action or invalid argument count; use I, M, P or T.")

	except StateError as error:
		print(f"Room state error: {error}", file=sys.stderr)
		return 4

	except ValueError as error:
		if isinstance(error, json.JSONDecodeError):
			code = 4
		else:
			# InvalidCommand also inherits ValueError and reaches this branch.
			code = 3

		# str(error) converts the exception's message to text.
		print(str(error), file=sys.stderr)
		return code

	# KeyError means a required dictionary key was missing. TypeError means an
	# operation received an inappropriate type, such as adding a number to text.
	# Handle file errors, missing dictionary keys and invalid type operations
	except (OSError, KeyError, TypeError) as error:
		print(f"Motor failed: {error}", file=sys.stderr)
		return 4


# Python loads definitions from top to bottom, but a function's body runs only when
# called. This final check starts main for a direct launch, not when tests import it.
# Python sets __name__ to "__main__" when this file is launched as a script.
# Importing motor from another file does not execute this block.
if __name__ == "__main__":
	# main() returns a number; sys.exit sends it to the calling process.
	# The inner call main() runs first and returns its number. sys.exit then raises
	# SystemExit with that status so the operating system can report it to the backend.
	sys.exit(main())
