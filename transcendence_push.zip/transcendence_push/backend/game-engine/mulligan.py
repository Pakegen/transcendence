# This file checks the opening card exchanges and applies both choices together

import copy
import random
import re

# InvalidCommand inherits ValueError, so a handler for ValueError catches it too.
# The caller treats an invalid request as exit code 3 without saving changes.
class InvalidCommand(ValueError):
	# pass does nothing. It supplies the required body of an otherwise empty class.
	pass

# StateError means the saved data is missing or inconsistent; the caller uses code 4.
# Exception is Python's base type for ordinary errors.
class StateError(Exception):
	pass


# Check the saved opening state and both players' offers before changing cards
# views holds the saved player dictionaries
def validate_state(room, state, views, legal_commands):
	# isinstance(value, dict) checks whether value is a dictionary or a subtype.
	# get(key) reads a value, or returns None if the key is missing.
	if not isinstance(state, dict) or state.get("Room_number") != room:
		raise StateError("Motor state does not match the requested room.")

	if state.get("Game_Phase") != "Mulligan" or state.get("Mulligan") is not True:
		raise InvalidCommand("Mulligan phase is already over or has not started.")

	for k in ("Round_number", "Active_Player", "Active_Opponent"):
		if state.get(k) != 0:
			raise StateError("Unexpected round or active player during initial mulligans.")

	# [] creates an empty list.
	# A list is an ordered collection which we can change.
	types = []
	for p in (1, 2):
		# f before a string lets {p} insert the value of p into the text.
		types.append(state.get(f"Player_{p}_Type"))
	for t in types:
		if t not in ("Human", "AI"):
			raise StateError("Invalid player types in Motor state.")
	if types.count("AI") > 1:
		raise StateError("Invalid player types in Motor state.")
	if "AI" in types:
		expected_game_type = "AI"
	else:
		expected_game_type = "PvP"
	if state.get("Game_Type") != expected_game_type:
		raise StateError("Game type disagrees with player types.")

	for player in (1, 2):
		prefix = f"Player_{player}"
		deck_name = state.get(f"{prefix}_Decklist")
		if deck_name not in ("Witcher", "Wild Hunt"):
			raise StateError(f"Player {player}: unknown deck.")
		# Lists start at index 0, so player - 1 maps seats 1 and 2 to indices 0 and 1.
		# == compares values. and requires both conditions and stops if the first is false.
		if types[player - 1] == "AI" and deck_name != "Witcher":
			raise StateError("AI must use Witcher.")

		hand = state.get(f"{prefix}_Hand")
		deck = state.get(f"{prefix}_Deck")
		if not isinstance(hand, list) or not isinstance(deck, list):
			raise StateError(f"Player {player}: hand/deck must be lists.")
		# range includes its start and excludes its end: 1..25 or 27..51 here.
		if deck_name == "Witcher":
			short_ids = range(1, 26)
		else:
			short_ids = range(27, 52)
		if len(hand) != 10 or len(deck) != 15:
			raise StateError(f"Player {player}: invalid initial hand/deck contents.")
		# + joins two lists into a new list without changing either original.
		for c in hand + deck:
			# type(value) is int requires exactly an integer
			if type(c) is not int:
				raise StateError(f"Player {player}: invalid initial hand/deck contents.")
		# A set keeps unique values without promising a list-like order.
		# add inserts a value into a set. Repeated values are stored only once.
		expected_cards = set()
		for c in short_ids:
			# * multiplies numbers: the hundreds digit identifies the player.
			expected_cards.add(player * 100 + c)
		if set(hand + deck) != expected_cards:
			raise StateError(f"Player {player}: invalid initial hand/deck contents.")

		# No cards may already be on the board or in a graveyard during mulligans.
		for zone in ("Front_Row", "Back_Row", "Graveyard"):
			if state.get(f"{prefix}_{zone}") != []:
				raise StateError(f"Player {player}: initial {zone} must be empty.")

		# Unpacking assigns each pair's first value to zone and second value to code.
		for zone, code in ((hand, 2), (deck, 1)):
			# enumerate gives a position and an item. The 1 makes positions start at 1.
			for position, card in enumerate(zone, 1):
				entry = state.get(f"Card_{card}")
				# :02d writes an integer using at least two digits, adding a leading 0.
				if (not isinstance(entry, dict) or entry.get("Exist") is not True
					or entry.get("Location") != f"{player}{code}{position:02d}"):
					raise StateError(f"Card {card}: inconsistent existence/location.")

		# A player view must describe this seat, this phase and this exact hand.
		view = views.get(player)
		if (not isinstance(view, dict) or view.get("Client_Player_Number") != player
			or view.get("Game_Phase") != "Mulligan" or view.get("Mulligan") is not True
			or view.get(f"{prefix}_Hand") != hand):
			raise StateError(f"Player {player}: saved view is inconsistent with Motor state.")

		offered = view.get("Available_Commands")
		expected = legal_commands(hand, player)
		if not isinstance(offered, list):
			raise StateError(f"Player {player}: saved command list is inconsistent.")
		for c in offered:
			if not isinstance(c, str):
				raise StateError(f"Player {player}: saved command list is inconsistent.")
		if len(offered) != len(expected) or set(offered) != set(expected):
			raise StateError(f"Player {player}: saved command list is inconsistent.")


# Pick the AI's returns: Spells and Locations first, then the weakest Units.
# Lower card ID breaks ties. P1 returns up to three cards and P2 up to two.
def ai_selection(hand, player, library):
	# This nested function is local to ai_selection and can read its library value.
	# It converts a card into the three sorting values used below.
	def priority(card):
		entry = library.get(f"Card_{card}")
		if not isinstance(entry, dict) or entry.get("Type") not in ("Spell", "Location", "Unit"):
			raise StateError(f"Card {card}: missing or unsupported AI mulligan type.")
		if entry["Type"] in ("Spell", "Location"):
			# return sends a value back and immediately ends this function call.
			return (0, 0, card)
		strength = entry.get("Strength")
		if type(strength) is not int:
			raise StateError(f"Card {card}: invalid catalogue strength.")
		return (1, strength, card)

	# sorted creates a new list. key=priority supplies a function, without calling it
	# sorted calls it once for each card to obtain that card's sorting key.
	# Tuples compare left to right: category, then strength, then card ID.
	# Equal keys keep their original order. The input hand itself is not reordered.
	ordered = sorted(hand, key=priority)
	if player == 1:
		limit = 3
	else:
		limit = 2
	# [:limit] is a slice: take items before index limit, or all if there are fewer.
	return ordered[:limit]


# Validate every human choice, add the AI's choice, then exchange cards on a copy.
# rng=None and library=None are defaults used when the caller omits those arguments.
# Supplying rng lets tests repeat the same random choices.
def resolve_mulligans(room, state, views, commands, legal_commands, rng=None, library=None):
	validate_state(room, state, views, legal_commands)

	# Record which seats need an actual command from the backend.
	humans = set()
	for p in (1, 2):
		if state[f"Player_{p}_Type"] == "Human":
			humans.add(p)
	if len(commands) != len(humans):
		raise InvalidCommand(f"Expected {len(humans)} human mulligan command(s); omit AI placeholders.")

	# {} creates an empty dictionary. Each player number will map to a list of IDs.
	selections = {}
	for command in commands:
		# fullmatch requires the whole text to match. r before a string keeps backslashes
		# literal for the pattern. (?:...) groups alternatives and | means either one.
		# [0-9] is a digit, and {9} or {6} requires exactly that many repetitions.
		if not isinstance(command, str) or not re.fullmatch(r"(?:15[0-9]{9}|25[0-9]{6})", command):
			raise InvalidCommand("Malformed mulligan code: P1 needs 11 digits; P2 needs 8.")
		# [0] reads the first character. int converts digit text into an integer.
		player = int(command[0])
		if player not in humans or player in selections:
			raise InvalidCommand(f"Player {player}: unexpected or duplicate human command.")
		# Consecutive [] lookups read a dictionary inside another dictionary.
		if command not in views[player]["Available_Commands"]:
			raise InvalidCommand(f"Player {player}: command was not offered in the saved player view.")
		selections[player] = []
		# The third range argument is the step: move three characters each time.
		for i in range(2, len(command), 3):
			# [i:i+3] reads three characters; the ending index is excluded.
			if command[i:i+3] != "000":
				selections[player].append(int(command[i:i+3]))

	# Compute the AI selection only after every human command has been accepted
	for player in (1, 2):
		if player not in humans:
			# Empty collections and None are false in an if test.
			if library:
				catalogue = library
			else:
				catalogue = {}
			selections[player] = ai_selection(state[f"Player_{player}_Hand"], player, catalogue)

	result = copy.deepcopy(state)
	if rng is None:
		# SystemRandom uses operating-system randomness instead of a seeded sequence.
		rng = random.SystemRandom()
	for player in (1, 2):
		# These variables refer to the lists inside result; they are not new copies.
		hand = result[f"Player_{player}_Hand"]
		deck = result[f"Player_{player}_Deck"]
		returned = selections[player]
		if not returned:
			continue

		# Draw first while the returned cards are still outside the deck
		# The last list item is the deck's top; pop removes it and returns its value.
		replacements = []
		for _ in returned:
			replacements.append(deck.pop())
		kept = []
		for card in hand:
			if card not in returned:
				kept.append(card)
		# Assigning to [:] replaces the contents of the same list. Assigning to hand
		# alone would only change the local variable, leaving result's list unchanged.
		hand[:] = kept + replacements
		# extend appends each item from another collection, unlike append's single item.
		deck.extend(returned)
		# shuffle changes the existing deck's order in place.
		rng.shuffle(deck)

	# Both exchanges are complete. These moves  do not trigger card effects
	result["Mulligan"] = False
	result["Game_Phase"] = "Turn"
	result["Round_number"] = 1
	result["Active_Player"] = 1
	result["Active_Opponent"] = 2
	return result
