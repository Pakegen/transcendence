# This file chooses AI actions and writes private predictions for normal card plays
# Predictions use the real turn engine on independent copies of the current state.


import json
from pathlib import Path
import re

from game_state import refresh_state
from mulligan import StateError
from turns import action_code, apply_command, legal_commands, normal_hand


# Prepare this room's prediction directory, clearing only recognized prediction files.
# reset=True also removes the empty room directory before recreating it.
# All entries are checked before any deletion so unknown files are left untouched.
def prediction_folder(output_dir, room, reset=False):
	if not re.fullmatch(r"[0-9]{2}", room):
		raise StateError("Invalid prediction room identifier.")
	root = Path(output_dir) / "ai_prediction"
	folder = root / room

	# This is superflue but interesting
	# A symbolic link points to another path. Reject links for both directory levels,
	# including broken links, to avoid following them when clearing predictions.
	for path in (root, folder):
		# is_symlink checks for a link, exists checks presence, and is_dir checks type.
		if path.is_symlink() or (path.exists() and not path.is_dir()):
			raise StateError("Prediction directory must be a real directory, not a link.")
	if folder.exists():
		# iterdir gives the directory's immediate children. list collects them now so
		# validation and deletion can each loop over the same entries afterwards.
		entries = list(folder.iterdir())
	else:
		entries = []
	for path in entries:
		# is_file requires a regular file. name is the final filename without parents.
		# This pattern requires a seat digit, 13 more digits and a literal .json suffix.
		# In a regular expression, \. matches a dot rather than any character.
		if path.is_symlink() or not path.is_file() or not re.fullmatch(r"[12][0-9]{13}\.json", path.name):
			raise StateError("Prediction folder contains an unexpected entry; nothing was cleared.")

	# Only this room's verified generated files  are removed
	for path in entries:
		# unlink removes a file. rmdir below removes an empty directory.
		path.unlink()
	if reset and folder.exists():
		folder.rmdir()
	# mkdir creates a directory. Named arguments make the purpose of each value clear.
	# 0o700 is octal notation for requested owner-only access permissions on Unix.
	# exist_ok=True accepts an already existing directory; it does not change its mode.
	root.mkdir(mode=0o700, exist_ok=True)
	folder.mkdir(mode=0o700, exist_ok=True)
	return folder


# Turn a score margin into a preference number, where lower is better.
# The exact preference order is +1, 0, -1, +2, -2, +3, -3 and so on.
def margin_rank(margin):
	if margin == 1:
		return 0
	if margin == 0:
		return 1
	if margin < 0:
		# abs gives the distance from zero: abs(-2) is 2.
		return 2 * abs(margin)
	return 2 * margin - 1


# Try Stratagem, Power, End Turn and Pass Round in that order.
# Return None if normal card plays must be compared instead.
# start_margin is the lead at turn start; it stays fixed after a Stratagem action.
def special_command(state, start_margin):
	player = state["Active_Player"]
	opponent = 3 - player
	# str converts the player number to text, matching the command dictionary's keys.
	offers = state["Available_Commands"][str(player)]
	stratagem = state["Player_1_Stratagem"]

	# Prefer an offered Stratagem when exactly one normal card remains in hand.
	if len(normal_hand(state, player)) == 1:
		for command in offers:
			if command[1] == "3" and int(command[2:5]) == stratagem:
				return command

	# Check the existing Power policy separately for each round
	power = action_code(player, 2)
	round_number = state["Round_number"]
	first_turn = state[f"Player_{player}_Completed_Turns_This_Round"] == 0
	use_power = False
	if round_number == 1:
		# In round one, lead after an opponent's completed turn while they have not passed.
		if (not state[f"Player_{opponent}_has_passed"]
			and state[f"Player_{opponent}_Completed_Turns_This_Round"] > 0
			and start_margin > 0):
			use_power = True
	elif round_number == 2:
		# In round two, use the first playable turn when behind by one crown to zero.
		if (first_turn and state[f"Player_{opponent}_Crown"] == 1
			and state[f"Player_{player}_Crown"] == 0):
			use_power = True
	elif round_number == 3:
		# In round three, prefer Power on this seat's first playable turn.
		if first_turn:
			use_power = True
	if power in offers and use_power:
		return power

	# End a completed play  before considering a voluntary round pass
	end = action_code(player, 6)
	if end in offers:
		return end
	passing = action_code(player, 0)
	if passing in offers:
		# Pass with a lead or deficit of at least five if the opponent has no crown.
		if state[f"Player_{opponent}_Crown"] == 0 and abs(start_margin) >= 5:
			return passing
		# Also pass when ahead of an opponent who has already passed.
		if state[f"Player_{opponent}_has_passed"] and start_margin > 0:
			return passing
	return None


# Choose an action, saving each normal-card simulation in the private prediction folder.
# Keep the command with the best margin rank; command text breaks equal-rank ties.
def choose_command(room, state, views, library, output_dir, start_margin):
	command = special_command(state, start_margin)
	if command is not None:
		return command

	# Keep only offered normal-card plays, preserving the order of the original offers.
	player = state["Active_Player"]
	candidates = []
	for c in state["Available_Commands"][str(player)]:
		if c[1] == "3" and int(c[2:5]) != state["Player_1_Stratagem"]:
			candidates.append(c)
	if not candidates:
		raise StateError("AI has neither an eligible control action nor a normal play.")

	# Clear previous predictions once then evaluate every candidate from the same state
	folder = prediction_folder(output_dir, room)
	best = None
	for command in candidates:
		projected = apply_command(room, state, views, command, library)
		refresh_state(projected)
		# Build both players' new offers before replacing the projected command map.
		available_commands = {}
		for p in (1, 2):
			available_commands[str(p)] = legal_commands(projected, p, library)
		projected["Available_Commands"] = available_commands
		# This is a data field written to JSON, not a Python comment. Its existing text
		# stays unchanged so generated file contents remain the same as before.
		projected["_comment"] = "Private AI command projection, not a live room state."

		content = json.dumps(projected, indent="\t") + "\n"
		path = folder / f"{command}.json"
		path.write_text(content, encoding="utf-8")

		# Evaluate the resulting board scores; do not base this choice on hidden cards.
		margin = projected[f"Player_{player}_Board_Strength"] - projected[f"Player_{3-player}_Board_Strength"]
		choice = (margin_rank(margin), command)
		# Tuple comparison checks rank first, then command text. or avoids comparing
		# a tuple to None before the first candidate has supplied an initial best value.
		if best is None or choice < best:
			best = choice

	# Index 1 contains the command; index 0 contains its ranking number.
	# The caller applies it again through the real engine. Current effects are
	# deterministic; random effects would need an agreed simulation/replay policy.
	return best[1]
