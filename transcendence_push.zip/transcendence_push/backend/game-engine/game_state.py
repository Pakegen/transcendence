# This file checks the shared game state and recalculates values derived from it

from mulligan import StateError


# Each dictionary entry has the form key: value. These numbers encode locations.
# The uppercase name is a convention meaning this mapping should stay constant.
ZONES = {"Deck": 1, "Hand": 2, "Front_Row": 3, "Back_Row": 4, "Graveyard": 5}


# Supply missing tracking fields without overwriting values already in the state.
# This lets earlier initialized states acquire these particular default fields.
def ensure_turn_fields(state):
	# setdefault inserts the default only if the key is absent. An existing value,
	# even None or 0, is kept. Its return value is not needed here.
	state.setdefault("Card_has_been_played", 0)
	state.setdefault("Stratagem_has_been_played", 0)
	state.setdefault("Turn_number", 0)
	state.setdefault("Last_Command", "")
	state.setdefault("Last_Phases", [])
	state.setdefault("Winner", 0)
	state.setdefault("End_Reason", "")

	# Each player has separate round counters, Power usage and a board bonus
	for player in (1, 2):
		state.setdefault(f"Player_{player}_Completed_Turns_This_Round", 0)
		state.setdefault(f"Player_{player}_Power_Used", False)
		state.setdefault(f"Player_{player}_Round_Bonus", 0)
		# Ages 1 to 5 hold damage from this player's five most recent own turns.
		for age in range(1, 6):
			state.setdefault(f"Player_{player}_Frost_Damage_Turn_{age}", 0)


# Check zone contents, then refresh card locations, scores, counts and status flags.
# Call this before publishing views so they contain values consistent with the zones.
def refresh_state(state):
	ensure_turn_fields(state)

	# A single seen set covers every zone of both players, so a card cannot appear
	# in two places. Invalid contents stop the refresh with a StateError.
	seen = set()
	for player in (1, 2):
		# items() gives each dictionary key and its associated value as a pair.
		for zone, code in ZONES.items():
			cards = state.get(f"Player_{player}_{zone}")
			if not isinstance(cards, list):
				raise StateError(f"Player {player}: {zone} must be a list.")
			for position, card in enumerate(cards, 1):
				if type(card) is not int or card in seen or not isinstance(state.get(f"Card_{card}"), dict):
					raise StateError("Zone contents have missing or duplicate card records.")
				seen.add(card)
				# The zone list is the source of truth for position and existence.
				state[f"Card_{card}"]["Location"] = f"{player}{code}{position:02d}"
				state[f"Card_{card}"]["Exist"] = True

	# Recalculate scores from current card strengths.
	for player in (1, 2):
		bonus = state[f"Player_{player}_Round_Bonus"]
		if type(bonus) is not int or bonus < 0:
			raise StateError("Round bonus must be a nonnegative integer.")
		if type(state[f"Player_{player}_Power_Used"]) is not bool:
			raise StateError("Power use must be a boolean.")
		for row in ("Front", "Back"):
			strength = 0
			for card in state[f"Player_{player}_{row}_Row"]:
				value = state[f"Card_{card}"].get("Current_Strength")
				if type(value) is not int:
					raise StateError(f"Card {card}: strength must be an integer.")
				strength = strength + value
			state[f"Player_{player}_{row}_Row_Strength"] = strength
		state[f"Player_{player}_Board_Strength"] = (
			bonus
			+ state[f"Player_{player}_Front_Row_Strength"]
			+ state[f"Player_{player}_Back_Row_Strength"]
		)

		# Counts use zone membership. An unused Stratagem in hand counts as a card;
		# a removed card record outside all zones does not count.
		for zone in ("Hand", "Deck", "Graveyard"):
			state[f"Player_{player}_{zone}_Count"] = len(state[f"Player_{player}_{zone}"])

	# Track the special deck card only for the faction that actually uses it
	for player in (1, 2):
		deck = state[f"Player_{player}_Deck"]
		for name, faction, short_id in (("Roach", "Witcher", 8), ("Winter Queen", "Wild Hunt", 32)):
			key = f"Player {player} {name} in Deck"
			if state[f"Player_{player}_Decklist"] == faction:
				state[key] = player * 100 + short_id in deck
			else:
				# Dictionary pop(key, default) removes that key if present. The default
				# None prevents an error if it is absent. This differs from list.pop().
				state.pop(key, None)

	# Refresh every retained card record, including cards currently outside zones.
	for key, entry in state.items():
		# startswith tests the beginning of text. [5:] takes everything from index 5.
		# isdigit is true for nonempty text made only of digit characters.
		if not key.startswith("Card_"):
			continue
		if not key[5:].isdigit():
			# This excludes Card_has_been_played, which is a turn flag, not a card.
			continue
		if not isinstance(entry, dict):
			raise StateError(f"{key}: invalid card record.")
		base = entry.get("Base Strength")
		current = entry.get("Current_Strength")
		if type(base) is not int or type(current) is not int:
			raise StateError(f"{key}: strengths must be integers.")
		# Comparisons produce booleans that can be stored directly in the dictionary.
		entry["Boosted"] = current > base
		entry["Hurt"] = current < base

	# Validate all five history values  before replacing this player's public total
	for player in (1, 2):
		buckets = []
		for age in range(1, 6):
			buckets.append(state[f"Player_{player}_Frost_Damage_Turn_{age}"])
		for value in buckets:
			if type(value) is not int or value < 0:
				raise StateError("Frost damage history must contain nonnegative integers.")
		total = 0
		for value in buckets:
			total = total + value
		state[f"Frost Dmg on last 5 turns P{player}"] = total
