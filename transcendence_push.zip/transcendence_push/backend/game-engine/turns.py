# This file lists legal actions and handles turns, timeouts, rounds and game results
# State helpers change their supplied dictionary. apply_command and apply_timeout
# first copy it, so their callers receive a separate result to save.

import copy
import random

# Several names can be imported from the same module, separated by commas.
from game_state import ensure_turn_fields, refresh_state
from mulligan import InvalidCommand, StateError

# Build the existing command text: player, action, card, source zone and position,
# destination zone, two placement zeros and three target zeros. Valid codes have
# 14 digits. Optional fields default to zero for actions that do not use a card.
def action_code(player, action, card=0, source=0, position=0, destination=0):
	# :03d pads card to at least three digits; :02d pads position to at least two.
	return f"{player}{action}{card:03d}{source}{position:02d}{destination}00000"

# Read a card's category from the catalogue, rejecting missing or unsupported data.
def card_type(library, card):
	entry = library.get(f"Card_{card}")
	if not isinstance(entry, dict) or entry.get("Type") not in ("Unit", "Spell", "Location", "Stratagem"):
		raise StateError(f"Card {card}: missing or unsupported catalogue type.")
	return entry["Type"]

# Build the commands this player can use now, in the same order each time.
# Actions are 0=pass round, 1=concede, 2=Power, 3=play card and 6=end turn.
def legal_commands(state, player, library):
	# Only the active, non-passed player in Turn phase receives any commands.
	if state["Game_Phase"] != "Turn" or state["Active_Player"] != player or state[f"Player_{player}_has_passed"]:
		return []

	# A player with priority  can always concede
	commands = [action_code(player, 1)]
	played = state["Card_has_been_played"] == 1
	if played:
		# Normal play or Power enables ending the turn.
		commands.append(action_code(player, 6))
	else:
		# Using the Stratagem blocks passing this round during the current turn.
		if state["Stratagem_has_been_played"] == 0:
			commands.append(action_code(player, 0))
		# Power requires an unused Power and a hand containing a normal card.
		if not state[f"Player_{player}_Power_Used"] and normal_hand(state, player):
			commands.append(action_code(player, 2))

	# Examine hand cards in their stored order so source positions stay accurate.
	for position, card in enumerate(state[f"Player_{player}_Hand"], 1):
		kind = card_type(library, card)
		if kind == "Stratagem":
			# Only P1 may use the Stratagem. Before a normal play, a Stratagem-only
			# hand does not allow this action, because empty-hand passing takes over.
			if player != 1 or (not played and not normal_hand(state, player)):
				continue
		elif played:
			# elif is else if in python
			# A normal card cannot be played after another normal card or Power.
			continue
		if position > 99:
			raise StateError("The current command format supports hand positions 01-99.")

		# Units may go to either row; other card types use the graveyard destination.
		if kind == "Unit":
			destinations = (3, 4)
		else:
			# The comma makes this a one-item tuple. (5) alone would just be 5.
			destinations = (5,)
		for destination in destinations:
			commands.append(action_code(player, 3, card, 2, position, destination))
	return commands


# Switch player, reset action flags, age that player's frost history and open a turn.
# Passed players also use this routine for automatic turns without input.
def start_turn(state):
	if state["Game_Phase"] in ("Round_End", "Game_End"):
		raise StateError("Cannot start another turn after round or game end.")
	if (state["Active_Player"], state["Active_Opponent"]) not in ((1, 2), (2, 1)):
		raise StateError("Turn start needs two distinct player identities.")
	ensure_turn_fields(state)

	# Remember the old player before either field is overwritten, then swap seats.
	previous_player = state["Active_Player"]
	state["Active_Player"] = state["Active_Opponent"]
	state["Active_Opponent"] = previous_player
	state["Game_Phase"] = "Turn_Start"
	state["Last_Phases"].append("Turn_Start")
	state["Turn_number"] = state["Turn_number"] + 1
	state["Card_has_been_played"] = 0
	state["Stratagem_has_been_played"] = 0

	# Move older damage toward age 5, working backwards so values are not lost
	# before they are copied. range(5, 1, -1) produces 5, 4, 3, 2.
	player = state["Active_Player"]
	for age in range(5, 1, -1):
		state[f"Player_{player}_Frost_Damage_Turn_{age}"] = state[f"Player_{player}_Frost_Damage_Turn_{age-1}"]
	state[f"Player_{player}_Frost_Damage_Turn_1"] = 0

	# Reduce only this player's frost durations. Actual frost damage is not implemented.
	for row in ("Front", "Back"):
		key = f"Player_{player}_{row}_Frost"
		# max returns the largest argument; zero prevents a negative duration.
		state[key] = max(0, state[key] - 1)
	state[f"Frost on 2 Rows in P{player}"] = (
		state[f"Player_{player}_Front_Frost"] > 0
		and state[f"Player_{player}_Back_Frost"] > 0
	)
	state["Game_Phase"] = "Turn"
	state["Last_Phases"].append("Turn")


# Return a new list containing the hand cards except P1's retained Stratagem.
# These are the cards counted for empty-hand passing and eligible for AFK removal.
def normal_hand(state, player):
	cards = []
	for card in state[f"Player_{player}_Hand"]:
		if card != state["Player_1_Stratagem"]:
			cards.append(card)
	return cards


# Store the result and remove input priority from both players.
# winner is 1 or 2 for a sole winner, or 0 for a draw.
def end_game(state, winner, reason):
	state["Winner"] = winner
	state["End_Reason"] = reason
	state["Game_Phase"] = "Game_End"
	state["Last_Phases"].append("Game_End")
	state["Active_Player"] = 0
	state["Active_Opponent"] = 0


# Score the completed round and award crowns. If the match continues, clear the
# board, draw up to three cards per player and prepare the next round's starter.
def resolve_round(state):
	state["Game_Phase"] = "Round_End"
	state["Last_Phases"].append("Round_End")
	# Scores must be fresh before comparing them. Round-end card effects are deferred.
	refresh_state(state)
	scores = []
	for p in (1, 2):
		scores.append(state[f"Player_{p}_Board_Strength"])
	if scores[0] == scores[1]:
		winner = 0
	elif scores[0] > scores[1]:
		winner = 1
	else:
		winner = 2

	# A tie awards a crown to both players; otherwise only the winner gets one.
	for player in (1, 2):
		if winner in (0, player):
			state[f"Player_{player}_Crown"] = state[f"Player_{player}_Crown"] + 1
	finished = []
	for p in (1, 2):
		if state[f"Player_{p}_Crown"] >= 2:
			finished.append(p)
	if finished:
		# Check both crown totals before deciding whether this is a win or a draw.
		if len(finished) == 1:
			end_game(state, finished[0], "Crowns")
		else:
			end_game(state, 0, "Crowns")
		# A bare return ends this function and returns None. No cleanup after game end.
		return

	# A round winner starts next. After a tie the previous nonstarter starts
	starter = state["Round_Starting_Player"]
	state["Previous_Round_Starting_Player"] = starter
	if winner != 0:
		state["Round_Starting_Player"] = winner
	else:
		# For seats 1 and 2, subtracting from 3 gives the other seat.
		state["Round_Starting_Player"] = 3 - starter

	# Reset board cards to base strength and move them to their owner's graveyard.
	for player in (1, 2):
		for row in ("Front", "Back"):
			zone = state[f"Player_{player}_{row}_Row"]
			for card in zone:
				entry = state[f"Card_{card}"]
				entry["Current_Strength"] = entry["Base Strength"]
			state[f"Player_{player}_Graveyard"].extend(zone)
			# clear empties the existing list, also updating the list stored in state.
			zone.clear()
			state[f"Player_{player}_{row}_Frost"] = 0
		# Round-only fields reset. Frost history, hands, unused Stratagem, Power usage
		# and the global turn count keep their existing values.
		state[f"Frost on 2 Rows in P{player}"] = False
		state[f"Player_{player}_has_passed"] = False
		state[f"Player_{player}_Round_Bonus"] = 0
		state[f"Player_{player}_Completed_Turns_This_Round"] = 0

	# Start the next round and draw only as many cards as each deck still contains.
	state["Round_number"] = state["Round_number"] + 1
	state["Game_Phase"] = "Round_Start"
	state["Last_Phases"].append("Round_Start")
	for player in (1, 2):
		deck = state[f"Player_{player}_Deck"]
		# min returns the smallest argument, so a short deck is never overdrawn.
		for _ in range(min(3, len(deck))):
			state[f"Player_{player}_Hand"].append(deck.pop())
		# not turns an empty normal-hand list into True and a nonempty one into False.
		state[f"Player_{player}_has_passed"] = not normal_hand(state, player)

	# start_turn will swap these fields, giving priority to starter.
	starter = state["Round_Starting_Player"]
	state["Active_Player"] = 3 - starter
	state["Active_Opponent"] = starter


# Keep advancing automatic turns and rounds until someone may act or the game ends.
# This loop avoids a chain of functions calling themselves for passed players.
def advance_to_input(state):
	while True:
		# Resolve a round before opening any extra turn when both players have passed.
		if state["Player_1_has_passed"] and state["Player_2_has_passed"]:
			resolve_round(state)
			if state["Game_Phase"] == "Game_End":
				return
			# Draws may have left both new hands empty, so check both pass flags again.
			continue

		start_turn(state)
		player = state["Active_Player"]
		# Empty-hand passing happens at the start of that player's own turn.
		if not normal_hand(state, player): #empty hand
			state[f"Player_{player}_has_passed"] = True
		if not state[f"Player_{player}_has_passed"]: #has not passed
			# The caller can now publish this player's available commands.
			return

		# A passed player still gets start/end phases and frost aging, but no input
		# and no increment of the completed playable-turn counter.
		state["Game_Phase"] = "Turn_End"
		state["Last_Phases"].append("Turn_End")
		# Actual end-turn card effects are not implemented here yet.


# Count the completed playable turn, then advance through any automatic phases.
def finish_turn(state):
	# The inner lookup finds the active seat before building that seat's field name.
	# Single quotes inside this f-string avoid ending its outer double-quoted text.
	state[f"Player_{state['Active_Player']}_Completed_Turns_This_Round"] = (
		state[f"Player_{state['Active_Player']}_Completed_Turns_This_Round"] + 1
	)
	state["Game_Phase"] = "Turn_End"
	state["Last_Phases"].append("Turn_End")
	advance_to_input(state)


# After mulligans, put the reserved Stratagem into P1's hand and start round one.
def first_turn(state):
	ensure_turn_fields(state)
	stratagem = state["Player_1_Stratagem"]
	# The reserved Stratagem must still be outside every zone before we add it.
	for p in (1, 2):
		for zone in ("Deck", "Hand", "Front_Row", "Back_Row", "Graveyard"):
			if stratagem in state[f"Player_{p}_{zone}"]:
				raise StateError("P1 stratagem was already placed in a zone before round 1.")
	state["Player_1_Hand"].append(stratagem)

	# Set the round counters and diagnostic phase trace  before the first swap
	state["Round_number"] = 1
	state["Round_Starting_Player"] = 1
	state["Previous_Round_Starting_Player"] = 0
	state["Turn_number"] = 0
	state["Game_Phase"] = "Round_Start"
	state["Last_Phases"] = ["Round_Start"]
	state["Active_Player"] = 2
	state["Active_Opponent"] = 1
	advance_to_input(state)


# Check the saved turn and player views before accepting an action or timeout.
# refresh_state also updates derived fields in this supplied state during validation.
# This is mostly protection for weak code, but in proper usage it can't happen. It was needed
# for tests and stayed for dependencies.
def validate_turn_state(room, state, views, library):
	# First check the room, phase and identities before reading player-specific data.
	if not isinstance(state, dict) or state.get("Room_number") != room:
		raise StateError("Motor state does not match the requested room.")
	if state.get("Game_Phase") != "Turn":
		raise InvalidCommand("Player actions require Turn phase.")
	if (state.get("Active_Player"), state.get("Active_Opponent")) not in ((1, 2), (2, 1)):
		raise StateError("Exactly one player must have turn priority.")

	# Turn counters must describe an ongoing match whose opening mulligans are over.
	if type(state.get("Card_has_been_played")) is not int or state["Card_has_been_played"] not in (0, 1):
		raise StateError("Card_has_been_played must be 0 or 1.")
	if type(state.get("Turn_number")) is not int or state["Turn_number"] < 1 or state.get("Mulligan") is not False:
		raise StateError("Turn state has inconsistent phase counters.")
	if state.get("Round_Starting_Player") not in (1, 2) or state.get("Previous_Round_Starting_Player") not in (0, 1, 2):
		raise StateError("Round starter tracking is missing or invalid; initialize a fresh match.")

	# Validate each seat's pass flag, crowns and frost durations.
	for player in (1, 2):
		if type(state.get(f"Player_{player}_has_passed")) is not bool:
			raise StateError("Round pass flags must be booleans.")
		if (type(state.get(f"Player_{player}_Crown")) is not int
			or state[f"Player_{player}_Crown"] < 0
			or state[f"Player_{player}_Crown"] >= 2):
			raise StateError("An ongoing game must have fewer than two crowns per player.")
		for row in ("Front", "Back"):
			value = state.get(f"Player_{player}_{row}_Frost")
			if type(value) is not int or value < 0:
				raise StateError("Frost duration must be a nonnegative integer.")
	if state[f"Player_{state['Active_Player']}_has_passed"]:
		raise StateError("A passed player cannot await input.")

	# Validate zone records before generating any commands that read card types.
	refresh_state(state)
	for player in (1, 2):
		completed = state[f"Player_{player}_Completed_Turns_This_Round"]
		if type(completed) is not int or completed < 0:
			raise StateError("Completed playable turns must be nonnegative integers.")
	if type(state["Stratagem_has_been_played"]) is not int or state["Stratagem_has_been_played"] not in (0, 1):
		raise StateError("Stratagem turn flag must be 0 or 1.")

	# Each saved view must belong to its seat and match the current turn and offers.
	for player in (1, 2):
		view = views.get(player)
		if not isinstance(view, dict) or view.get("Client_Player_Number") != player:
			raise StateError(f"Player {player}: invalid saved view.")
		for key in ("Active_Player", "Active_Opponent", "Game_Phase", "Turn_number", "Card_has_been_played", f"Player_{player}_Hand"):
			if view.get(key) != state[key]:
				raise StateError(f"Player {player}: stale or inconsistent saved view ({key}).")
		if view.get("Available_Commands") != legal_commands(state, player, library):
			raise StateError(f"Player {player}: saved legal commands are inconsistent.")


# Apply an offered player command to an independent state copy and return that copy.
# The caller is responsible for refreshing and saving the returned result.
def apply_command(room, state, views, command, library):
	result = copy.deepcopy(state)
	validate_turn_state(room, result, views, library)
	player = result["Active_Player"]
	if command not in views[player]["Available_Commands"]:
		raise InvalidCommand("Command was not offered to the player with priority.")

	# Record the accepted input and start a fresh diagnostic trace for this action.
	result["Last_Command"] = f"P {command}"
	result["Last_Phases"] = ["Turn"]
	action = int(command[1])
	if action == 1:
		# Conceding immediately gives the opponent the match.
		end_game(result, result["Active_Opponent"], "Concede")
	elif action == 0:
		# Passing lasts for the rest of this round and completes the current turn.
		result[f"Player_{player}_has_passed"] = True
		finish_turn(result)
	elif action == 2:
		# Power is used once per match and takes the place of a normal card play.
		result[f"Player_{player}_Power_Used"] = True
		deck = result[f"Player_{player}_Deck"]
		if deck:
			result[f"Player_{player}_Hand"].append(deck.pop())
		# Even an empty deck consumes Power, enables End Turn and avoids AFK removal.
		result["Card_has_been_played"] = 1
	elif action == 3:
		# Decode the source card and destination from the already validated offer.
		card = int(command[2:5])
		destination = int(command[8])
		zones = {3: "Front_Row", 4: "Back_Row", 5: "Graveyard"}
		# A dictionary lookup keeps the existing error if an unsupported code gets here.
		zone = zones[destination]
		# remove deletes the first matching value, not the item at that index.
		result[f"Player_{player}_Hand"].remove(card)

		if card_type(library, card) == "Stratagem":
			# Award a single +5 board bonus only if a Unit is already on either row.
			board = result[f"Player_{player}_Front_Row"] + result[f"Player_{player}_Back_Row"]
			for unit in board:
				if card_type(library, unit) == "Unit":
					result[f"Player_{player}_Round_Bonus"] = result[f"Player_{player}_Round_Bonus"] + 5
					# break ends just this loop as soon as the first Unit is found.
					break
			# Keep the record but mark it outside the game, without a graveyard move.
			result[f"Card_{card}"]["Exist"] = False
			result[f"Card_{card}"]["Location"] = "0000"
			result["Stratagem_has_been_played"] = 1
			# Preserve the previous normal-play flag and the player's priority.
			return result

		# Normal cards move to the offered row or graveyard. General card effects
		# are deferred. The player keeps priority until End Turn or Concede.
		result[f"Player_{player}_{zone}"].append(card)
		result["Card_has_been_played"] = 1
	elif action == 6:
		finish_turn(result)
	else:
		raise StateError("An unsupported action was generated as legal.")
	return result


# Apply the current turn's timeout to a copy, then complete that turn.
# The backend owns timer expiry and must prevent stale timers from reaching here.
def apply_timeout(room, state, views, library, rng=None):
	result = copy.deepcopy(state)
	validate_turn_state(room, result, views, library)
	result["Last_Command"] = "T"
	result["Last_Phases"] = ["Turn"]
	player = result["Active_Player"]

	# Remove a random normal card only if neither normal play nor Power was used.
	if result["Card_has_been_played"] == 0:
		eligible = normal_hand(result, player)
		if eligible:
			if rng is None:
				rng = random.SystemRandom()
			# choice returns one random item without removing it from the given list.
			card = rng.choice(eligible)
			result[f"Player_{player}_Hand"].remove(card)
			# The removed card remains recorded but belongs to no zone.
			result[f"Card_{card}"]["Exist"] = False
			result[f"Card_{card}"]["Location"] = "0000"

	# Always end the turn including when there was no eligible card to remove
	finish_turn(result)
	return result


# Translate the state into the number returned to the backend: active seat 1 or 2,
# winner 61 or 62, or draw 63. Game_End distinguishes a draw from an unset winner.
def result_code(state):
	if state["Game_Phase"] == "Game_End":
		if state["Winner"]:
			return 60 + state["Winner"]
		return 63
	return state["Active_Player"]
