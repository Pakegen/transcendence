*This project has been created as part of the 42 curriculum by cydubois, niarefi, quenalla, lpantign.*

# ft_transcendence, gwentscendence

## Description

An online Gwent card game with matchmaking, ranked matches and a dedicated game
engine. An AI opponent is also implemented so the game can be played solo !

Each part of the project has its own documentation :

- Backend : [readme/README_BACKEND.md](readme/README_BACKEND.md)
- Frontend : [readme/README_FRONTEND.md](readme/README_FRONTEND.md)
- Game engine : [motor/docs/Motor intern rm.md](motor/docs/Motor%20intern%20rm.md). The other files in motor/docs are shorter guides for the backend and the frontend

## Instructions

### Requirements

- Docker + Docker Compose of course. You can run it with podman too
- make
- Free ports on the machine : 8443 (HTTPS), 8080 (HTTP, redirects to HTTPS) and 8025 (Mailhog)

Versions we tested with :

- Podman 5.8.7 with podman-compose 1.6.0 (42 computers, without root)
- Docker 29.1.3 with Docker Compose 2.40.3

### Configuration

- Copy `.env.example` to `.env` and fill in the values (`JWT_SECRET`,
  `POSTGRES_*`, and `FORTY_TWO_CLIENT_ID` / `FORTY_TWO_CLIENT_SECRET` for 42 OAuth)
- For the login with 42, the redirect URI of the application on the 42 intranet must be the same as `FORTY_TWO_CALLBACK_URL` (https://localhost:8443/api/auth/42/callback by default)

### Running the project

- `make` : builds and starts everything (frontend, backend, postgres, nginx, mailhog)
- `make re` : restarts after a change
- `make down` : stops the containers
- `make logs` : live logs
- A set of other rules to check some stuff (detailled in the makefile)
- The application is served at https://localhost:8443 (self signed certificate)

The Makefile uses podman-compose when it is installed, and docker compose otherwise.

### Makefile rules

- `make` or `make up` : build and start, with the backend compiled once. This is the mode used for the evaluation
- `make dev` : same, but the backend restarts when the code changes. For Docker on our own machines only
- `make build` : build the images without starting
- `make down` : stop the containers
- `make re` : down, then up
- `make logs` : follow the logs of all the containers
- `make clean` : same as down
- `make fclean` : down, then remove the unused images and containers
- `make db` : open a psql shell in the database
- `make db_users` : list the users
- `make db_matches` : list the last 20 matches
- `make db_apikeys` : list the API keys (never the key itself of course !)
- `make db_oauth` : list the accounts created with 42
- `make rate-limit-test` : send 65 requests to the public API to see the rate limit answer 429

### Useful addresses and checks

- Application : https://localhost:8443
- Public API documentation (Swagger) : https://localhost:8443/api/docs
- Emails sent by the application (Mailhog) : http://localhost:8025
- Backend unit tests : `npm install` then `npm run test` in the backend folder
- To play a match between two humans on one machine, use two different browsers, or one normal window plus one private window
- More test commands (curl) are in the backend documentation

## Team

quenalla (Quentin) : Project Manager
- Chooses which features to do first
- Makes the link between the frontend and the backend
- Decides the look of the application and the vision of the project in the medium and long term
- Frontend (interface, routing, real-time game rendering, themes)

lpantign (Lucas) : Technical Lead
- Chooses the technical stack, the protocols and the architecture of the project
- Reviews and maintains the branches where the different parts of the code are
- Takes quick decisions on some critical changes in the code

cydubois (Cyril) : Scrum Master
- Organises the meetings with the whole group
- Organises the Discord group used to communicate
- Creates Excel tables and diagrams to keep the team synchronised
- Manages the risks about blockers in a pragmatic way, and sets deadlines

niarefi (Nima)  : Developper
- Important support for others team mates and their respectives tasks  

## Project management

### How the work was organised

The work was mostly organised around the Discord server created by our Project
Manager. There are separate channels for the frontend, the game, the backend and
the bugs. This kept the work well separated and made things easy to find

### Tools used

- Git and GitHub : needed for the code
- Discord : to share the work and to talk about progress and bugs
- Excel : to follow the grading scale and the priority tasks. With Discord, it helped us to organise without searching for information for hours
- Draw.io : to make diagrams, mostly at the start of the project. They helped us to plan and to start the work calmly

### Communication channel

Discord !

## Tech stack

- Frontend : React + TypeScript + Vite
- Backend : NestJS (Node and TypeScript)
- Database : PostgreSQL + Prisma as ORM
- Real time : Socket.IO (matchmaking and gameplay)
- Game engine : Python (dedicated process, state exchanged through JSON files)
- TLS : nginx
- Containers : Docker Compose
- Email : Mailhog

### Why these choices, on the frontend

We chose React over plain JavaScript manipulating the DOM by hand. The board
holds four card rows, a hand, two graveyards, two scores and a turn timer, and
any of those can change with every message the server sends. In plain JavaScript
we would have to write the code that compares the old state to the new one and
updates the right elements. With React we re-describe the whole board from the
new state and React works out the difference

TypeScript over JavaScript, because one file describes the exact shape of the
state the engine sends. If the backend renames a field, the error shows up at
build time instead of during the evaluation

Vite, because the browser can read neither TypeScript nor JSX: a build step has
to turn them into JavaScript. Vite produces a fully static folder. There is no
Node process running on the frontend side in production - nginx serves the
generated files

The application is a single page application: one HTML file, and React replaces
the content when the user navigates

### Why these choices, on the backend

NestJS, because it gives a clear structure, one module per feature, guards to
protect the routes, validation of the requests, Websocks support and Swagger
documentation. We use all of them !

PostgreSQL, because our data is relational so a match is linked to two users and
an API key is linked to one user

The Python engine is a separate program. The backend calls it for each action
and reads the result in JSON files. All the game rules are in one place !

## Database schema

The schema is in backend/prisma/schema.prisma. There are three tables.

```
    User {
        Int id PK
        String email UK
        String username UK
        String password "optional"
        Int fortyTwoId UK "optional"
        String twoFactorSecret "optional"
        Boolean twoFactorEnabled
        Int elo
        Boolean deleted
        DateTime createdAt
        DateTime updatedAt
    }
    Match {
        Int id PK
        Int player1Id FK
        Int player2Id FK "optional"
        String faction1
        String faction2
        MatchResult result
        DateTime playedAt
    }
    ApiKey {
        Int id PK
        Int userId FK
        String hash UK
        String label "optional"
        DateTime createdAt
        DateTime lastUsedAt "optional"
    }
```

User : a player account
- id : Int, primary key
- email : String, unique
- username : String, unique
- password : String, optional, hashed with argon2
- fortyTwoId : Int, optional, unique (42 intranet id)
- twoFactorSecret : String, optional
- twoFactorEnabled : Boolean
- elo : Int, 1000 by default
- deleted : Boolean, true when the account was deleted (GDPR)
- createdAt, updatedAt : DateTime

Match : a finished match
- id : Int, primary key
- player1Id : Int, linked to User
- player2Id : Int, optional, linked to User
- faction1, faction2 : String
- result : PLAYER1, PLAYER2 or DRAW
- playedAt : DateTime

ApiKey : a key for the public API
- id : Int, primary key
- userId : Int, linked to User
- hash : String, unique. We store only the hash of the key
- label : String, optional
- createdAt, lastUsedAt : DateTime

Relations:
- One User has many Match (as player 1 or as player 2)
- One User has many ApiKey

## Features

- Sign-up, login, logout : Niarefi and lpantign
- Two-factor authentication through TOTP, with a QR code : Niarefi
- Login through the 42 intranet (OAuth) : Niarefi
- Matchmaking between human players : lpantign
- Solo matches against an AI : lpantign and cydubois
- Real-time Gwent matches, with a turn timer and reconnection : quenalla, lpantign
- Choice of the deck before a match : Witcher or Wild Hunt : cydubois, quenalla, niarefi, lpantign
- Statistics, match history, Elo leaderboard : quenalla and lpantign
- Badges earned for achievements : quenalla and lpantign
- Themes and sound settings : quenalla
- Export and import of personal data (GDPR), account deletion : niarefi and lpantign
- API keys to reach your own data from an external client : niarefi and lpantign

## Modules

Claimed total : 25 points, for a minimum of 14 required by the subject.
A major module is worth 2 points, a minor module 1 point.

Still to add for each module : who worked on it.

### Web

- Framework for the frontend and the backend (major, 2) : React with TypeScript, built by Vite, on the frontend. NestJS on the backend
- Real time features with WebSockets (major, 2) : one Socket.IO connection shared by the whole application. The backend sends the game state to each player and handles connection, disconnection and reconnection to an ongoing match so necessary to make a game
- Public API (major, 2) : API key sent in the X-API-Key header, rate limiting, GET, POST, PUT and DELETE plus a fifth endpoint. Swagger documentation at https://localhost:8443/api/docs. Keys are created, listed and revoked from the settings page, in the future we can maybe need it so we added this major
- ORM for the database (minor, 1) : Prisma on PostgreSQL, because life is more easy with an ORM for this type of project
- Custom-made design system (minor, 1) : everything is written by hand. 19 reusable components ! The palette, typography and spacing are CSS custom properties declared once. Icons come from lucide react , we chose this module because it's cool to work with a nice website

### Accessibility and internationalization

- Support for additional browsers (minor, 1) : tested on Chrome, Brave and Firefox, which is two different rendering engines. Gameplay, authentication, two-factor authentication, statistics and real-time matches work on all three

Limitations:
- The TLS certificate is self-signed, so on the first visit the browser shows a security warning that has to be accepted
- A browser keeps a single session cookie for the site, so only one account can be signed in per browser. To test a match between two human players, use two different browsers, or one normal window plus one private window. This applies to all three browsers
- On Chrome and Brave, going back during matchmaking takes the player out of the queue while the timer keeps running. Reloading the page, or cancelling and searching again, is enough. We could not reproduce it on Firefox
- Versions and operating systems tested : Linux (fedora and ubuntu)

### User management

- Game statistics and match history (minor, 1) : wins, losses and Elo, the match history with date, result and opponent, and the global leaderboard. The backend records the matches and computes the Elo. We chose it because it's an important part of our game aspect
- Remote authentication with OAuth 2.0 (minor, 1) : login with the 42 intranet. After the login, the backend redirects to the menu, to the 2FA page or to the login page with an error message. Because it's an interesting feature to learn some stuff and it's usefull for other futures implementations
- Complete 2FA (minor, 1) : TOTP. A QR code is shown when enabling it, with the secret for manual entry. It can be enabled and disabled from the settings. Same justification for remote auth OAuth

### Artificial intelligence

- AI opponent (major, 2) : the AI is in backend/game-engine/ai.py and uses the same commands a human player does. We chose it by interest and we need it to occuper players during matchmaking

### Gaming and user experience

- Web-based game (major, 2) : real-time play against another user, live matches, clear win and loss conditions, 2D rendering. Our game need it
- Remote players (major, 2) : two players on two separate machines, with latency, disconnection and reconnection handled. Same, our game need it too
- Multiplayer game (major, 2) : several game rooms at the same time, fair gameplay mechanics, proper synchronisation across clients because it's complementary for the 2 points above
- Game customization (minor, 1) : two visual themes, witcher and wild hunt, and sound settings. Preferences are stored in the browser and a default option is always available. Easy to add, so we took it
- Gamification (minor, 1) : the end of match page shows the Elo before and after the match, and the achievement unlocked by that match if there is one. The leaderboard and the badges are on the statistics page. We choose it because it's fun and easy to implement

For the game and the remote players, the server is the authority. The frontend
knows no Gwent rule. It receives a state with the list of allowed actions and
sends back a code taken from that list. All the logic is in the Python engine,
and the server validates every action before applying it

### Data and analytics

- Data export and import (minor, 1) : export of personal data in several formats, import with a dry-run check first, validation on import, bulk operations. We choose it to take some points only
- GDPR compliance (minor, 1) : export request, account deletion with confirmation, confirmation emails through Mailhog. Same justification as Data export/import

### Module of choice

- The Python game engine (minor, 1) : Python in backend/game-engine/, with 103 cards defined in library.json. Because cydubois love that and it's a very cool feature and drasticly improve the user experience. Cydubois was very curious and proactive for this task. (see his documentation for more details)

## Individual contributions

- quenalla : Frontend, reviews
- cydubois : Game, organisation, points planifications
- niarefi : Backend, support for others tasks
- lpantign : Backend, infra support, reviewer

The details of each part, with the challenges faced, are in the documentation of
that part (links at the top of this file).

## Resources

- Frontend : the list of documentation and tutorials is at the end of [readme/README_FRONTEND.md](readme/README_FRONTEND.md)
- Backend : to be completed
- Game engine : see end of [motor/docs/Motor intern rm.md](motor/docs/Motor%20intern%20rm.md)

### Use of AI

Quentin : see the end of [readme/README_FRONTEND.md](readme/README_FRONTEND.md)

Nima : to be completed

Cyril : see end of [motor/docs/Motor intern rm.md](motor/docs/Motor%20intern%20rm.md)