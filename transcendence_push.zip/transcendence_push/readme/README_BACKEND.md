# Backend

Written by lpantign and niarefi. Back to the [main README](../README.md).

The backend is a NestJS application in the backend folder. This file has two parts :

1. Authentication and Account : sign up, login, 2FA, 42 OAuth, API keys, public API, export, import, account deletion
2. Game server and infrastructure : real-time server, matchmaking, link with the Python engine, statistics, containers

The game rules themselves are not in the backend. They are in the Python engine : see [motor/docs/Motor intern rm.md](../motor/docs/Motor%20intern%20rm.md).

# Part 1

## Authentication and Account

### What this part does

This part covers everything about who the user is and what they can do with their own account. It lives in two NestJS modules. `backend/src/auth/` handles sign up, login, logout, the session cookie, two-factor authentication (TOTP) and login with the 42 intra (OAuth 2.0). `backend/src/account/` handles the account itself once you are logged in: API keys, a small public API for external scripts, data export (JSON or CSV), import of username/email from a file, and account deletion (GDPR "right to be forgotten").

The frontend talks to these modules through `frontend/src/api/auth.ts` and `frontend/src/api/compte.ts`. Everything goes through nginx, which serves HTTPS (port 8443 on the machine) and forwards `/api/*` to the backend, so `/auth/login` in the code is `https://localhost:8443/api/auth/login` from the browser.

### Stack and libraries

Only what is actually imported in these two folders:

- **NestJS** (`@nestjs/common`, `@nestjs/platform-express`): controllers, guards, DTO validation pipe, file upload interceptor (multer).
- **Prisma** with **PostgreSQL**: all reads and writes on `User` and `ApiKey`.
- **argon2**: password hashing. argon2 generates and stores a random salt inside each hash.
- **@nestjs/jwt**, **@nestjs/passport**, **passport-jwt**: signing the session JWT and checking it on protected routes.
- **cookie-parser** (set up in `main.ts`): reads the `access_token` cookie.
- **otplib**: TOTP secret generation and code verification for 2FA.
- **qrcode**: turns the `otpauth://` URI into a PNG data URL the frontend can put in an `<img>`.
- **@nestjs/throttler**: rate limiting per route.
- **class-validator** / **class-transformer**: DTO validation, also reused by hand to validate imported files.
- **@nestjs/swagger**: documentation of the public API, served at `https://localhost:8443/api/docs`.
- **node:crypto**: random API keys, SHA-256 of API keys, OAuth `state` values.
- Native `fetch` for the two calls to `api.intra.42.fr`. No OAuth library.
- `MailService` (from `backend/src/mail/`, nodemailer) is used by the account module to send confirmation emails.

### How the code is organized

| File / folder | Role |
|---|---|
| `auth/auth.controller.ts` | All `/auth/*` routes, cookie handling (session, 2FA pending, OAuth state) |
| `auth/auth.service.ts` | Signup, login, `openSession` (full session or 2FA pending), 2FA second step |
| `auth/two-factor.service.ts` | TOTP setup, enable, disable, code check |
| `auth/forty-two.service.ts` | OAuth 42: authorize URL, code exchange, profile fetch, find or create user |
| `auth/strategies/jwt.strategy.ts` | Reads the JWT from the cookie, rejects 2FA-pending tokens and deleted users |
| `auth/guards/`, `auth/decorators/` | `JwtAuthGuard` and `@CurrentUser()`, reused by other modules |
| `auth/dto/` | `SignupDto`, `LoginDto`, `TwoFactorCodeDto` |
| `account/account.controller.ts` | `/account/*` routes, both session-based (`/account/me/...`) and API-key based |
| `account/account.service.ts` | Get/update profile, export, import, deletion by anonymization |
| `account/api-key.service.ts` | Create, list, bulk create, bulk revoke, look up a key |
| `account/guards/api-key.guard.ts` | Checks the `X-API-Key` header |
| `account/csv.ts`, `account/import-file.ts` | Hand-written CSV writer/parser and import file reader |
| `*.spec.ts` | Vitest unit tests for 2FA, OAuth 42, bulk keys, CSV and import |

### Features

- **Sign up** with email, username and password. Email and username must be unique, and the API returns a 409 with a clear message if one of them is taken. The user is logged in right after.
- **Login / logout** with email and password. Login returns the same error message whether the email does not exist or the password is wrong. Logout clears the three cookies.
- **Session** in a JWT stored in an `httpOnly`, `secure`, `sameSite=lax` cookie, valid 7 days. `GET /auth/me` returns the current user.
- **2FA (TOTP)** compatible with Google Authenticator, Authy, etc. Setup gives a QR code and the secret in clear for manual entry, but 2FA is only switched on after the user types a valid code. Disabling also asks for a code.
- **Login with 42** (OAuth 2.0 authorization code flow, scope `public`). First login creates an account with the 42 login as username (or `login-42`, or `login-xxxx` if taken). If 2FA is on, the 42 login also goes through the 2FA step.
- **API keys**: a logged-in user can create keys (one at a time or up to 10 per request), list them, and revoke several at once. Max 20 keys per account. The key is shown only once.
- **Public API** protected by `X-API-Key`: read profile, update username/email, export, import, delete account.
- **Export** of personal data (profile + full match history) as JSON or as a downloadable CSV file.
- **Import** of username and/or email from a `.json` or `.csv` file (for example a modified export), with a `dryRun=true` mode that shows what would change without saving.
- **Account deletion** by anonymization, with a confirmation modal on the frontend and a confirmation email.
- **Confirmation emails** on export, import and deletion.

### API endpoints

All paths below are behind `/api` when going through nginx.

| Method | Route | Auth | Role |
|---|---|---|---|
| POST | `/auth/signup` | none (5/min) | Create account, set session cookie |
| POST | `/auth/login` | none (5/min) | Login, or start the 2FA step |
| POST | `/auth/logout` | none | Clear cookies |
| GET | `/auth/me` | cookie | Current user |
| POST | `/auth/2fa/verify` | `twofa_pending` cookie (5/min) | Second login step with a 6-digit code |
| POST | `/auth/2fa/setup` | cookie | Generate secret + QR code |
| POST | `/auth/2fa/enable` | cookie | Turn 2FA on after a valid code |
| POST | `/auth/2fa/disable` | cookie | Turn 2FA off (code required) |
| GET | `/auth/42` | none | Redirect to the 42 intra |
| GET | `/auth/42/callback` | `oauth42_state` cookie | OAuth return, redirect to `/menu`, `/2fa` or `/connexion?erreur=...` |
| POST | `/account/api-keys` | cookie | Create one API key |
| GET | `/account/me/api-keys` | cookie | List my keys (id, label, dates, never the key) |
| POST | `/account/me/api-keys/bulk` | cookie | Create 1 to 10 keys, all or nothing |
| POST | `/account/me/api-keys/revoke` | cookie | Revoke 1 to 50 keys, all or nothing |
| GET | `/account/me/export?format=json\|csv` | cookie | Export my data |
| POST | `/account/me/import?dryRun=true\|false` | cookie (10/min) | Import username/email from a file |
| DELETE | `/account/me` | cookie | Delete (anonymize) my account |
| GET | `/account` | X-API-Key | My profile |
| PUT | `/account` | X-API-Key | Update username and/or email |
| DELETE | `/account` | X-API-Key | Delete (anonymize) my account |
| GET | `/account/export?format=json\|csv` | X-API-Key | Export my data |
| POST | `/account/import?dryRun=true\|false` | X-API-Key (10/min) | Import from a file |

Every `/account` route is limited to 60 requests per minute unless a lower limit is given.

### Data model

Two models are owned by this part. `Match` is read for the export.

```mermaid
erDiagram
    User ||--o{ ApiKey : "has (onDelete: Cascade)"
    User ||--o{ Match : "player1"
    User |o--o{ Match : "player2 (null = AI)"
    User {
        Int id PK
        String email UK
        String username UK
        String password "nullable, null for 42 accounts"
        Int fortyTwoId UK "nullable"
        String twoFactorSecret "nullable"
        Boolean twoFactorEnabled
        Boolean deleted
        Int elo
        DateTime createdAt
    }
    ApiKey {
        Int id PK
        Int userId FK
        String hash UK "SHA-256 of the key"
        String label "nullable"
        DateTime createdAt
        DateTime lastUsedAt "nullable"
    }
```

`password` is null for accounts created through 42, and `fortyTwoId` is null for accounts created with email and password. `deleted` is set by account deletion; the row stays in the table so that the opponents' match history keeps working (`Match.player1Id` is not nullable).

### Main flows

**Login with password.** `AuthService.login` looks up the email and checks the password with `argon2.verify`. Then `openSession` decides: if 2FA is off, it signs a 7-day JWT `{ sub, username }` and the controller puts it in the `access_token` cookie. If 2FA is on, no session is opened. Instead it signs a short JWT `{ sub, type: '2fa_pending' }` valid 5 minutes, put in the `twofa_pending` cookie, and the response is `{ twoFactorRequired: true }`. The frontend then sends the user to `/2fa`.

**2FA second step.** `POST /auth/2fa/verify` reads the pending cookie, checks that the token is valid and really of type `2fa_pending`, reloads the user and checks the TOTP code against the stored secret (`epochTolerance: 30`, so a code from the previous or next 30 s window still passes). Only then the real session cookie is set. `JwtStrategy` refuses any token of type `2fa_pending`, so the pending cookie can never be used as a session even if someone moves it into `access_token`.

**Enabling 2FA** is done in two steps on purpose: `setup` stores a new secret but leaves `twoFactorEnabled` false, and `enable` flips it only after a correct code. A user who closes the page before scanning the QR code is not locked out.

**OAuth 42.**

```mermaid
sequenceDiagram
    participant B as Browser
    participant N as Backend (/auth)
    participant I as api.intra.42.fr
    participant DB as PostgreSQL
    B->>N: GET /auth/42
    N-->>B: set cookie oauth42_state, 302 to /oauth/authorize?state=...
    B->>I: user accepts
    I-->>B: 302 to /auth/42/callback?code&state
    B->>N: GET /auth/42/callback (with oauth42_state cookie)
    N->>N: compare state with cookie
    N->>I: POST /oauth/token (code + client secret)
    I-->>N: access_token
    N->>I: GET /v2/me
    I-->>N: id, login, email
    N->>DB: find by fortyTwoId, or create user
    N-->>B: session cookie (or twofa_pending) + 302 to /menu or /2fa
```

The 42 access token is used once to read the profile and is never stored. If a password account already uses the same email, we refuse with `email_pris` instead of linking the two accounts. The reason is in the code: sign up does not verify emails, so someone could create an account with another person's 42 email and get their access the day they log in with 42. All errors end as a redirect to `/connexion?erreur=<code>` (`oauth_indisponible`, `oauth_refuse`, `oauth_state`, `oauth_echec`, `email_pris`). The OAuth config is read on each request, so the backend starts fine without 42 credentials, only this login is unavailable.

**API key.** On creation we generate 32 random bytes (64 hex characters), return them once, and store only the SHA-256 hash. On each public API call, `ApiKeyGuard` hashes the `X-API-Key` header and does a `findUnique` on the hash. That is why it is SHA-256 and not argon2: argon2 is salted, so the same key would give a different hash and could not be searched directly. `lastUsedAt` is updated in the background without waiting. Bulk creation runs in a `Serializable` transaction so two parallel requests cannot go over the 20-key limit together; if Postgres detects the conflict, the user gets a 409 and can retry. Bulk revoke checks that every id belongs to the user first, and revokes nothing if one is missing (keys of another user are reported as "not found", same as non-existent ones).

**Import.** The file goes through multer (100 KB max, one file). `readIdentityFromFile` accepts `.json` (either `{ username, email }` or the export format `{ user: {...} }`) or `.csv` (only the header line and the first value line are read, so the CSV export can be re-imported as is). Everything except `username` and `email` is ignored. The values are then validated with the same `UpdateAccountDto` as `PUT /account`, and uniqueness is checked even in dry run. When something really changes, a summary email is sent to the old address.

**Deletion.** We do not delete the row. In one transaction we delete all API keys and replace email and username with `deleted-<id>-<random>`, set an argon2 hash of a random UUID as password, clear the 2FA secret and `fortyTwoId`, and set `deleted = true`. The random suffix is there because `deleted-<id>` alone is predictable (ids are sequential) and someone could pre-register it to block a deletion. Since `JwtStrategy` reloads the user on each request and checks `deleted`, existing sessions stop working immediately.

### Security choices

- Passwords are hashed with argon2 (salt included), never returned. `toPublicUser` only exposes `id`, `email`, `username`, `twoFactorEnabled`.
- Session and pending JWTs are signed with `JWT_SECRET`. `requireEnv` makes the backend crash at startup if it is missing, instead of signing tokens with `undefined`.
- Cookies are `httpOnly` (no JS access), `secure` (HTTPS only) and `sameSite: 'lax'` (not sent on cross-site POSTs, which is our CSRF protection).
- The OAuth `state` is 16 random bytes stored in a 5-minute cookie and compared on return. The 42 client secret only ever leaves the backend in the server-to-server token request.
- The TOTP secret is stored in plain text in `User.twoFactorSecret`, because the server needs it to compute codes. It is cleared on disable and on deletion. Disabling 2FA requires a code, so a stolen session cookie is not enough.
- API keys are stored as SHA-256 hashes; the clear key is shown once. Keys can only be created or revoked with a site session, not with another key, so a leaked key cannot create more keys.
- Input validation: a global `ValidationPipe` with `whitelist` and `forbidNonWhitelisted`, so unknown fields are rejected. Emails go through `@IsEmail` (max 254), usernames are 3 to 20 characters of `[a-zA-Z0-9_-]`, passwords 8 to 128 characters, 2FA codes exactly 6 digits, query params `format` and `dryRun` are restricted to fixed values.
- CSV export neutralizes cells starting with `=`, `+`, `-`, `@`, tab or CR (prefixed with `'`) to avoid CSV injection when the file is opened in Excel/LibreOffice.
- Rate limiting with `@nestjs/throttler`: 5 requests/min for signup, login and 2FA verify, 60/min for every `/account` route, 10/min for imports.
- Unique-constraint races (`P2002`) on update and OAuth user creation are caught and turned into a 409 or a retry, instead of a 500.

### Configuration

Variables read by these two folders (names only, see `.env.example`):

- `JWT_SECRET`: key used to sign session and 2FA-pending JWTs. Required.
- `FORTY_TWO_CLIENT_ID`, `FORTY_TWO_CLIENT_SECRET`: credentials of the 42 intra application.
- `FORTY_TWO_CALLBACK_URL`: must be exactly the redirect URI declared on the intra (`.../api/auth/42/callback`).
- `SMTP_HOST`, `SMTP_PORT`, `MAIL_FROM`: used by `MailService` for confirmation emails. By default they point to MailHog (web UI on port 8025).

The backend also needs `DATABASE_URL` (Prisma) and `FRONTEND_ORIGIN` (CORS, in `main.ts`), which are shared with the rest of the project.

### Trying it out

With the stack running, from a terminal (`-k` because the nginx certificate is self-signed, `-c`/`-b` to keep cookies):

```bash
# sign up, then check the session
curl -k -c jar -H 'Content-Type: application/json' \
  -d '{"email":"bob@example.com","username":"bob","password":"password123"}' \
  https://localhost:8443/api/auth/signup
curl -k -b jar https://localhost:8443/api/auth/me

# create an API key (the "key" field is only shown here)
curl -k -b jar -H 'Content-Type: application/json' -d '{"label":"test"}' \
  https://localhost:8443/api/account/api-keys

# use the public API with that key
curl -k -H "X-API-Key: <key>" https://localhost:8443/api/account
curl -k -X PUT -H "X-API-Key: <key>" -H 'Content-Type: application/json' \
  -d '{"username":"bob2"}' https://localhost:8443/api/account
curl -k -H "X-API-Key: <key>" "https://localhost:8443/api/account/export?format=csv" -o export.csv

# dry-run import of the exported file
curl -k -b jar -F file=@export.csv "https://localhost:8443/api/account/me/import?dryRun=true"
```

For 2FA, the easiest is the Settings page: click enable, scan the QR code with an authenticator app, type the code, log out and log in again. For OAuth 42, use the 42 button on the login page (`/connexion`) (needs the three `FORTY_TWO_*` variables). The confirmation emails can be seen in MailHog on `http://localhost:8025`. The full public API is browsable in Swagger at `https://localhost:8443/api/docs`.

### Known limitations

- Logout only clears the cookie on the client. A copied JWT stays valid until it expires (7 days); the only server-side invalidation is account deletion.
- The throttler counts per IP, but the backend does not set Express `trust proxy`. Behind nginx every request probably comes from the nginx container IP, so the 5/min login limit may be shared by all users instead of being per client. This needs to be checked and fixed.
- Emails are never verified at sign up. That is why OAuth refuses to link accounts by email.
- No password change or password reset route, and no 2FA recovery codes. Losing the phone means losing the account.
- The TOTP secret is stored unencrypted in the database. A used 2FA code is not marked as used, so it can be replayed within its validity window.
- From the website, username and email can only be changed through the import feature; `PUT /account` exists only on the API-key side.
- Emails are best-effort: if SMTP fails, the operation still succeeds and we only log a warning. With the default config they land in MailHog, not in a real inbox.
- Export sends an email every time, even for repeated exports.

### Modules covered

Proposed mapping for the modules list (6 points from this part):

| Module | Type | Points | Why it is covered |
|---|---|---|---|
| Web: public API with secured API key, rate limiting, documentation, at least 5 endpoints | Major | 2 | `GET`, `PUT`, `DELETE /account`, `GET /account/export`, `POST /account/import` all use `X-API-Key` (hashed keys), throttled at 60/min (10/min for import), documented with Swagger at `/api/docs`, and they read and write the database. |
| User Management: remote authentication with OAuth 2.0 (42) | Minor | 1 | Full authorization code flow with `state` check in `forty-two.service.ts` and `/auth/42`, `/auth/42/callback`. |
| User Management: complete 2FA system | Minor | 1 | TOTP setup with QR code, enable/disable with code, and a second login step for both password and 42 logins. |
| Data and Analytics: data export and import | Minor | 1 | Export in JSON and CSV, import of JSON or CSV with validation and dry run. "Bulk operations support" is covered by bulk create/revoke of API keys (all or nothing): **to confirm** with the evaluators that this counts, since the bulk part is not on the imported data itself. Also only two formats (the subject lists JSON, CSV, XML as examples): **to confirm** that two is enough. |
| Data and Analytics: GDPR compliance | Minor | 1 | Users can get their data (`/account/me/export`) in a readable format (JSON or CSV), delete it with a confirmation modal on the frontend, and receive confirmation emails for export, import and deletion. Emails go to MailHog by default: **to confirm** that this is accepted for the demo. |

The mandatory "sign up and log in with email and password, hashed and salted" requirement is also covered here (argon2), but it is not a module.

### Contribution

**niarefi**: designed and wrote the `auth` and `account` modules described above: password signup/login with JWT cookie sessions, 2FA, OAuth 42, API keys and the public API, export/import and GDPR deletion, the related Prisma fields (`ApiKey` model, `password`, `fortyTwoId`, 2FA fields, `deleted`) and the unit tests in these folders. The first version of `SignupDto` and of the `User` model came with the initial project commit; everything else in these two folders was added in my commits (2FA, OAuth 42, data export and import).

Challenges I ran into and how I handled them:

- **Concurrent requests on unique fields.** Checking "is this email or username free?" and then writing is not atomic, so two requests at the same time can both pass the check. Instead of letting the Prisma unique error (`P2002`) end as a 500, `updateAccount` turns it into a 409, and `findOrCreateUser` for 42 accounts just tries the next username candidate. The same kind of race existed for the 20-key limit in bulk creation; there I used a `Serializable` transaction so count and insert happen as one block, and a conflict (`P2034`) becomes a 409 the user can retry.
- **Finding a user from an API key.** Hashing keys with argon2 like passwords does not work here: argon2 is salted, so the same key never gives the same hash and a direct lookup is impossible. Since the keys are 64 random hex characters and not human passwords, I used SHA-256, which is deterministic and lets `findUnique` work on the hash.
- **Deleting an account without breaking match history.** A real `DELETE` fails because `Match.player1Id` is a non-nullable foreign key, and it would also erase games from the opponents' history. I went with anonymization plus a `deleted` flag. That created a second problem: the user's JWT was still valid after deletion. I fixed it by having `JwtStrategy` reload the user on every request and reject `deleted` accounts, which costs one DB query per protected call.
- **2FA edge cases.** Two things needed care. Turning 2FA on directly at setup would lock out a user who closed the page before scanning the QR code, so activation is split into `setup` then `enable`. And the short token given between password and code must never count as a session, so it carries `type: '2fa_pending'` and `JwtStrategy` refuses it.
- **Linking 42 accounts by email.** Matching a 42 login to an existing account with the same email looked natural, but sign up does not verify emails, so anyone could pre-register someone else's 42 email and take over their account later. I chose to refuse with `email_pris` instead. It is less convenient for a user who already has a password account.
- **Swagger behind nginx.** The generated docs called `/auth/signup` while nginx only forwards paths starting with `/api/`, so "Try it out" got a 405. Adding `/api` as the server in the Swagger config fixed it.

# Part 2

## Game server and infrastructure

### What this part does

This part is the rest of the backend : the real-time server, the matchmaking, the link with the Python game engine, the statistics and the Elo, and the containers (nginx, PostgreSQL, Makefile).

### How the code is organized

In backend/src :

- main.ts : starts the application. It enables cookie parsing, the validation of every request body, and Swagger
- matchmaking/matchmaking.gateway.ts : the Socket.IO server. It checks the session cookie on each connection, puts the players in the queue, pairs them and relays their actions
- matchmaking/matchmaking-queue.ts : the waiting queue, first in first out
- game/game.service.ts : one session per match. It handles the timers, the mulligan, the reconnection and the end of the match
- game/motor-client.service.ts : the only file that calls the Python engine
- game/room-allocator.service.ts : gives a room number, from 00 to 99, to each match
- stats/ : statistics, match history and leaderboard. The Elo is computed in elo.ts
- mail/ : sends the emails

Outside of src :

- backend/prisma : the database schema and the migrations
- backend/game-engine : the Python engine
- nginx : the nginx configuration and the image that builds the frontend
- docker-compose.yml, docker-compose.dev.yml and Makefile at the root

### Real-time events

The game uses one Socket.IO connection per player. The connection is refused without a valid session cookie.

Sent by the client :

- queue:join : look for a match, with the chosen faction. With vsAI set to true, the match starts directly against the AI
- queue:leave : leave the queue
- game:action : play, with the room number and a command code

Sent by the server :

- queue:joined : the player is in the queue
- queue:error : the search could not start (already in the queue, already in a match, no room left)
- match:found : an opponent was found, with the room number and the name of the opponent
- game:state : the new state of the match, as this player is allowed to see it
- game:error : the command was refused, or the match was cancelled
- game:opponent-left and game:opponent-reconnected : the opponent lost or recovered the connection
- game:elo : the Elo before and after the match
- game:succes : an achievement was unlocked by this match

### How a match runs

1. Two players in the queue are paired, or one player starts a match against the AI
2. The backend reserves a room and asks the engine to create the match
3. Both players choose their mulligan. The backend waits for both choices and sends them to the engine together
4. On each action, the backend first checks that the code is in the list of commands the engine offered to this player. Anything else is refused
5. The backend calls the engine and waits for it to finish
6. The engine writes three files for the room : the full state, kept on the server, and one view per player. The backend sends each view to its player
7. At the end, the result is saved and the room is freed

How the engine is called :

- The command is python3 motor.py, then the room number, then the action : I to create the match, M for the mulligan, P to play, T when the time is over
- It is started without a shell, so nothing sent by a player can be run as a command
- Two calls for the same room never run at the same time, they wait for each other
- A call that does not answer in 10 seconds is killed and the match is cancelled

The engine answers with its exit code :

- 0 : match created, waiting for the mulligans
- 1 or 2 : waiting for player 1 or player 2
- 3 : command refused, nothing changed
- 4 : internal error, the match is cancelled
- 61, 62, 63 : player 1 won, player 2 won, draw

Timers and connection :

- A player has 60 seconds for the mulligan. After that, the backend keeps all his cards for him
- A turn lasts 60 seconds at most. After that, the backend asks the engine to end the turn
- When a player reconnects, the backend sends him the last view again and tells the opponent

End of a match between two humans :

- The match and the two new Elo ratings are written in one database transaction, so a result is never half saved
- Each player receives his Elo before and after
- The first win with a faction against another faction unlocks an achievement

### Statistics routes

These routes need the session cookie. They are behind /api when going through nginx.

- GET /stats/me : Elo, wins, losses, draws and achievements of the player
- GET /stats/history : the last matches of the player. The limit parameter is 20 by default, 100 at most
- GET /stats/leaderboard : the players sorted by Elo, with the same limit parameter

### Containers

docker-compose.yml starts four services :

- postgres : the database. The data is kept in a named volume
- backend : the NestJS application and the Python engine. The migrations are applied each time the container starts
- mailhog : catches the emails sent by the application
- nginx : the only entry point. It serves the frontend files and forwards /api/ to the backend

Only nginx (ports 8443 and 8080) and the Mailhog page (port 8025) can be reached from the machine. The backend and the database are only reachable from the other containers.

The self-signed certificate is created when the nginx image is built.

The backend image has two versions. The prod version is the default one : the code is copied in the image and compiled once. The dev version, with make dev, reloads the backend when the code changes.

For podman without root, the main compose file has no port under 1024, uses full image names (docker.io/...), and does not mount the code from the machine.

### Configuration

The variables are in the .env file, see .env.example :

- POSTGRES_USER, POSTGRES_PASSWORD, POSTGRES_DB : the database. The backend builds its connection address from them
- JWT_SECRET : signs the session tokens. The backend does not start without it
- FRONTEND_ORIGIN : allowed origin for CORS, only useful with the Vite development server
- SMTP_HOST, SMTP_PORT, MAIL_FROM : where the emails are sent, Mailhog by default
- FORTY_TWO_CLIENT_ID, FORTY_TWO_CLIENT_SECRET, FORTY_TWO_CALLBACK_URL : login with 42

### Tests

The unit tests use Vitest. In the backend folder : npm install, then npm run test.

They cover the Elo computation, the matchmaking queue, the room allocation, the match service, the two-factor authentication, the 42 OAuth, the bulk API keys, and the CSV export and import.

### Known limitations

- 100 matches at most can run at the same time, one per room
- The matches against the AI are not saved : they are not in the history and do not change the Elo
- The ongoing matches are kept in the memory of the backend. If the backend restarts, they are lost

### Use of AI

Lucas : AI was helpful for understanding and fixing issues I couldnt find answers to online. It also helped me get started with nest, prisma, NGINX setups and other notions at the beginning of the project. Once everything was working, I used it for Q&A sessions to review and deepen what I learned. I used it too to learn how to debug this kind of app because I never did web apps before. I also used it to fix my English when writing this markdown files and to complete more easily some README requierements.

Nima :  I used AI (Claude Code) mostly as a teacher and a reviewer for my part of the project: authentication, 2FA, OAuth with 42, public API keys and data export/import. I was new to NestJS, Prisma and to topics like TOTP and OAuth, so I used it to understand how they work and to get unstuck on problems I couldn't solve alone.
Once things were working, I asked it to walk me through my own auth and account code file by file, to quiz me on it and to point out weak spots.

### Contribution

lpantign and niarefi
