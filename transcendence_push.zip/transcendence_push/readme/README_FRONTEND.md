*This project has been created as part of the 42 curriculum by cydubois niarefi, quenalla, lpantign*

# ft_transcendence, gwentscendence

## Description

An online Gwent card game with matchmaking, ranked matches and a dedicated game
engine. An AI opponent is also implemented so the game can be played solo.

Note on the code: identifiers, file names and comments in the source are written
in French. This README is in English, but the names it quotes (`Vignette`,
`connecter`, `src/api/partie.ts`) are the real names in the codebase.

## Instructions

### Requirements
- Docker + Docker Compose
- Copy `.env.example` to `.env` and fill in the values (`JWT_SECRET`,
  `POSTGRES_*`, and `FORTY_TWO_CLIENT_ID` / `FORTY_TWO_CLIENT_SECRET` for 42 OAuth)

### Running the project
- `make` : builds and starts everything (frontend, backend, postgres, nginx, mailhog)
- `make re` : restarts after a change
- `make down` : stops the containers
- `make logs` : live logs
- The application is served at `https://localhost:8443` (self-signed certificate)

## Team

- quenalla : frontend (interface, routing, real-time game rendering, themes)
- cydubois : to be completed
- niarefi : to be completed
- lpantign : to be completed

## Project management

- How the work was organised : to be completed
- Tools used : to be completed
- Communication channel : to be completed

## Tech stack

- Frontend : React + TypeScript + Vite
- Backend : NestJS (Node.js / TypeScript)
- Database : PostgreSQL + Prisma (ORM)
- Real time : Socket.IO (matchmaking and gameplay)
- Game engine : Python (dedicated process, state exchanged through JSON files)
- Reverse proxy / TLS : nginx
- Containers : Docker Compose
- Email (GDPR) : Mailhog

### Why these choices, on the frontend

We chose React over plain JavaScript manipulating the DOM by hand. The board
holds four card rows, a hand, two graveyards, two scores and a turn timer, and
any of those can change with every message the server sends. In plain JavaScript
we would have to write the code that compares the old state to the new one and
updates the right elements. With React we re-describe the whole board from the
new state and React works out the difference.

TypeScript over JavaScript, because `src/types-moteur.ts` describes the exact
shape of the state the engine sends. If the backend renames a field, the error
shows up at build time instead of during the evaluation.

Vite, because the browser can read neither TypeScript nor JSX: a build step has
to turn them into JavaScript. Vite produces a fully static `dist/` folder. There
is no Node process running on the frontend side in production - nginx serves the
generated files.

No CSS framework. Colours, spacing and radii are CSS custom properties declared
in `src/index.css` and mirrored in `src/theme.ts` so they can be used from
JavaScript. That gives a single place to change, and it is also what makes
multiple themes possible.

The application is a single-page application: one HTML file, and React replaces
the content when the user navigates.

Justification for the backend, Prisma, the Python engine and nginx : to be completed

## Frontend architecture

### Files at the root

- `index.html` : the only HTML file in the project. It contains an empty div and the entry script.
- `vite.config.ts` : build tool configuration
- `eslint.config.js` : static analysis rules
- `tsconfig*.json` : TypeScript compiler configuration

### Files in `src/`

- `main.tsx` : the entry point. It attaches React to the `#root` div in `index.html`.
- `App.tsx` : the routing table, that is, which URL renders which component
- `index.css` : the global CSS custom properties (colours, themes)
- `theme.ts` : the same values, exposed to JavaScript
- `types-moteur.ts` : the types of the game state sent by the engine

### Folders in `src/`

`api/` holds everything that talks to the server, and it is the only way out. No
component contains a URL: they call functions such as `connecter(email,
motDePasse)` or `lireStats()`. If a backend route changes, there is a single
file to update.

- `auth.ts` : sign-up, login, logout, two-factor authentication, 42 OAuth
- `stats.ts` : statistics, match history, leaderboard
- `compte.ts` : GDPR export, import, API keys, account deletion
- `socket.ts` : the Socket.IO connection, a single instance shared by the whole application
- `partie.ts` : the local trace of the current match, which survives a page reload
- `reglages.ts` : user preferences (theme, sound)
- `son.ts` : sound effects

`pages/` holds one component per screen: `Connexion`, `Inscription`,
`DeuxFacteurs`, `Menu`, `Combat`, `Attente`, `Jeu`, `FinPartie`, `Stats`,
`Parametres`, `Regles`, `Confidentialite`, `Conditions`.

`components/` holds the reusable pieces: `Vignette` (a single card),
`DetailCarte`, `Modale`, `Champ`, `Bouton`, `Tableau`, `RoutePrivee`, `ClesApi`,
`ImportCompte`, and a few others.

`data/` holds the static game data. `cartes.ts` maps a card id to its name, type
and strength. `commandes.ts` decodes the engine's 14-digit action codes.

### The difference between a page and a component

A page matches a URL. The router mounts it, it drives its own server calls and
its own state, and it is never imported by another page.

A component has no URL. It receives parameters, called props, and renders a
piece of the interface. It is imported by pages or by other components, and it
is meant to be reused.

For example the `Jeu` page matches the `/jeu` URL, and it renders about ten
`Vignette` components, one per card visible on the board. `Vignette` is written
once and called as many times as there are cards.

### The difference between `.ts` and `.tsx`

The `x` means the file contains JSX, a syntax that looks like HTML but is
written inside JavaScript. It is not HTML: the build step turns it into function
calls.

So everything that renders something is `.tsx`, which means `pages/` and
`components/`. All the logic that renders nothing is `.ts`, which means `api/`,
`data/`, `theme.ts` and `types-moteur.ts`.

## How the frontend connects to the rest of the project

### What it talks to

The frontend only talks to nginx. It knows neither the backend's address, nor
the database's, nor even that the Python engine exists.

The browser requests `https://localhost`. nginx serves the static frontend build
for everything that is not `/api/`, and forwards the rest to the backend on port
3000. The backend then talks to PostgreSQL through Prisma, to Mailhog for the
GDPR emails, and to the Python engine which owns the game rules and with which
it exchanges match state through JSON files.

### What nginx does

Port 80 redirects to 443, so everything goes over HTTPS with a self-signed
certificate generated when the image is built.

There are two routing rules:

nginx
location /api/ {
    proxy_pass http://backend:3000/;
}

location / {
    try_files $uri /index.html;
}

The trailing slash in `proxy_pass` strips the prefix, so a request to
`/api/auth/login` reaches the backend as `/auth/login`.

The `try_files $uri /index.html` is essential for a single-page application. If
someone types `https://localhost/menu` straight into the address bar, that file
does not exist on disk. nginx returns `index.html`, React starts, and the router
reads the URL to render the right page. Without that line, reloading on any
route other than the root would return a 404.

Routing everything through nginx buys four things: a single exposed port, a
single TLS certificate, a backend that is never reachable from outside, and no
CORS problem in production since the frontend and the API are served from the
same origin.

### The two communication channels

The first one is HTTP through `fetch`, for everything one-off: authentication,
statistics, settings, account export.

```ts
fetch(`${API_URL}/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "include",
    body: JSON.stringify(donnees),
});
```

`credentials: "include"` is required, otherwise the browser does not send the
session cookie with the request. That cookie is `httpOnly`, so it cannot be read
from JavaScript, which protects it from being stolen through script injection.

The second one is the WebSocket through Socket.IO, for the game itself. HTTP is
not enough: the client asks and the server answers, so there is no way to learn
that the opponent has played. A WebSocket is a permanent, bidirectional
connection, encrypted as `wss`, which lets the server push information. nginx
lets it through thanks to its `map $http_upgrade` directive.

The application opens a single connection, shared by every screen. If each
component opened its own, the server would see several connections for the same
player and would not know which one to send the game state to.

The events exchanged are `queue:join`, `queue:leave`, `queue:joined`,
`queue:error`, `match:found`, `game:state`, `game:action`, `game:error`,
`game:opponent-left`, `game:opponent-reconnected`, `game:elo` and `game:succes`.

### The server is the authority

The frontend knows no Gwent rule at all. It receives a state that contains,
among other things, the list of actions allowed at that exact moment, in
`Available_Commands`. When the player clicks a card, the frontend sends back a
14-digit code taken verbatim from that list. It never builds one.

Someone editing the JavaScript in their browser could send any code they like,
but the server checks that the code matches a valid action in the current state
and that the player really holds that seat in that match. Otherwise it returns
an error and changes nothing.

For the same reason, the `RoutePrivee` component that guards pages on the
frontend is not a security measure. It only avoids rendering a page that would
be empty anyway. The real protection is the `JwtAuthGuard` on the server, which
is present on every sensitive endpoint.

### The HTTP status codes we use

- `200` : the request succeeded, the frontend reads the JSON body
- `400` : server-side validation failed, the frontend shows the first message of the error array
- `401` : missing or expired session, wrong credentials, or invalid API key. The frontend shows a message, or redirects to `/connexion`
- `404` : the resource does not exist, for example an unknown API key
- `409` : conflict, typically an email or username already taken
- `429` : more than 5 requests in 60 seconds on the authentication routes

A rejected login attempt prints a `POST /api/auth/login 401` line in the browser
console. That is not an application error: developer tools log every HTTP
response that is not a 2xx, and 401 is the correct code for a failed
authentication. The error is caught by the code and the user sees a readable
message. That status code is also required by the API key module, because a
client calling with a wrong key must receive a 401, otherwise no standard tool
can work with the API.

## Public API

The API is meant for external scripts, not for the website itself. The website
keeps using the session cookie.

Authentication uses an API key sent in the `X-API-Key` header. A key is created
from the account settings page, or through `POST /api/account/api-keys` while
logged in.

Interactive documentation is served by Swagger at **`https://localhost/api/docs`**,
with every endpoint, its parameters and its responses.

The five endpoints protected by the API key are:

- `GET /api/account` : the current profile
- `PUT /api/account` : update username and/or email
- `DELETE /api/account` : delete (anonymise) the account, GDPR right to erasure
- `GET /api/account/export?format=json|csv` : full export of the profile and match history
- `POST /api/account/import?dryRun=true|false` : import username and/or email from a `.json` or `.csv` file

Rate limiting is applied globally on the authentication routes (5 requests per
60 seconds) and specifically on the import endpoint (10 per 60 seconds).

## Supported browsers

The application was tested on Google Chrome, Brave and Mozilla Firefox, which
means two different rendering engines: Blink for the first two, Gecko for the
third. Gameplay, authentication, two-factor authentication, statistics and
real-time matches work on all three.

Versions and operating systems tested : Not the same size on certains objects

The TLS certificate is self-signed, so on the first visit the browser shows a
security warning that has to be accepted.

## Known limitations

### One signed-in account at a time per browser

The session cookie is `httpOnly` and unique per origin. A browser keeps a single
cookie for `https://localhost`, not one per tab. So when a second account signs
in, its cookie overwrites the first one.

The first player's tab still finishes its match, because the identity of a
WebSocket connection is fixed when the connection is established and is never
read again. It switches to the second account on its first HTTP request, for
example when returning to the menu. The match result is still credited to the
right account, since it is recorded from the socket's identity.

This is not an application defect but a consequence of the `httpOnly` cookie,
which we chose for security: it cannot be read from JavaScript, so it cannot be
stolen through script injection. Working around it would mean keeping a token in
memory per tab, which would be less safe.

To test a match between two human players, use two different browsers, or one
normal window plus one private window. All the private windows of a single
browser share one session, so that is two accounts maximum per browser.

This applies to all three browsers.

### The matchmaking queue after a browser back navigation

On Chrome and Brave, going back puts the page in the browser's Back-Forward
Cache, which closes the WebSocket. The application disconnects deliberately
before the page is cached and reconnects when it is restored, but React does not
remount the component in that case, so no `queue:join` is sent again. The player
is reconnected to the server but no longer in the queue, while the timer keeps
running.

Reloading the page, or cancelling and searching again, is enough.

We could not reproduce it on Firefox.

### Cancelling a search that has already found a match

Two seconds pass between the moment an opponent is found and the game screen
appearing. Cancelling during those two seconds does not cancel the match on the
server, which already exists. It has to be resumed from the menu.

## Database schema

- `User` : to be described (key fields, relations)
- `Match` : to be described
- `ApiKey` : to be described

## Features

- Sign-up, login, logout
- Two-factor authentication through TOTP, with a QR code
- Login through the 42 intranet (OAuth)
- Matchmaking between human players
- Solo matches against an AI
- Real-time Gwent matches, with a turn timer and reconnection
- Statistics, match history, Elo leaderboard
- Themes and sound settings
- Export and import of personal data (GDPR), account deletion
- API keys to reach your own data from an external client

## Modules

**Claimed total: 23 points**, for a minimum of 14 required by the subject.

Each module is listed once below, with its points. Most of them have a frontend
half and a backend half, so they are grouped by which side carries them. The
detailed descriptions that follow repeat no point values, to keep the count
unambiguous.

### Frontend-led - 3 points

- Custom-made design system - 1
- Support for additional browsers - 1
- Game customization - 1

### Backend-led - 6 points

- Public API - 2
- ORM for the database - 1
- AI opponent - 2
- Module of choice: the Python game engine - 1

### Shared, each side doing half - 10 points

- Framework (React on the frontend, NestJS on the backend) - 2
- Real-time features over WebSocket - 2
- Remote authentication with OAuth 2.0 (42) - 1
- Complete 2FA - 1
- Game statistics and match history - 1
- Gamification - 1
- Data export and import - 1
- GDPR compliance - 1

### Relying on the whole chain - 4 points

- Web-based game - 2
- Remote players - 2

### What the frontend does, module by module

No point values below: they are all in the list above.

**Framework.** React with TypeScript, built by Vite, plus React Router for
client-side routing. The entry point is `src/main.tsx` and the routing table is
`src/App.tsx`. The application follows the single-page application model: one
HTML file, and React swaps the content on navigation.

**Custom-made design system.** No CSS framework, everything is written by hand.
19 reusable components in `src/components/`: `Vignette`, `DetailCarte`,
`Modale`, `Champ`, `Bouton`, `Tableau`, `Badge`, `Message`, `Onglets`,
`Panneau`, `Titre`, `Icone`, `Chargement`, `LienRetour`, `PiedDePage`,
`RoutePrivee`, `ClesApi`, `ImportCompte`, `BoutonConnexion42`. The palette,
typography and spacing are 47 CSS custom properties declared once in
`src/index.css` and mirrored in `src/theme.ts` so they can be used from
JavaScript. Typography goes through the `--police` property. Icons come from
lucide-react, wrapped in our own `Icone` component so size and colour stay
consistent everywhere.

**Support for additional browsers.** Tested on Chrome, Brave and Firefox, which
is two different rendering engines, Blink and Gecko. The per-browser limitations
are described in the "Known limitations" section above.

**Game customization.** Two visual themes, `witcher` and `wild-hunt`, selectable
from the settings and applied through the `data-theme` attribute on the document
root. Sound settings live in `src/api/son.ts`. Preferences are stored in the
browser and a default option is always available.

**Real-time features over WebSocket.** `src/api/socket.ts` holds a single
Socket.IO connection shared by the whole application, with two specific
mechanisms. First a buffer: the module listens to `game:state` itself and keeps
the last state received, because the first one arrives before the game screen
exists. Second, handling of the browser's Back-Forward Cache: we disconnect
deliberately before the page is cached and reconnect when it is restored,
otherwise the client keeps retrying from a frozen page.

**Game statistics and match history.** The `Stats` page shows wins, losses and
Elo, the match history with game mode, date, result and opponent, and the global
leaderboard. The calls are in `src/api/stats.ts`.

**Gamification.** The `FinPartie` page shows the Elo before and after a match,
and the matchup achievement unlocked by that match if there is one. The
leaderboard and progression badges are on the `Stats` page.

**Complete 2FA.** The `DeuxFacteurs` page for entering the code, the QR code
shown when enabling it along with the secret for manual entry if scanning fails,
and enabling and disabling from the settings.

**Remote authentication with OAuth 2.0 (42).** The `BoutonConnexion42`
component. It is a real navigation to the backend and not a `fetch`, because the
browser has to actually go to the 42 intranet. On the way back, the backend
redirects to `/menu`, `/2fa` or `/connexion?erreur=<code>`, and the frontend
turns each error code into a readable message.

**Public API.** The `ClesApi` component to create, list and revoke keys, with
copy to clipboard. The calls are in `src/api/compte.ts`.

**Data export and import.** Export of personal data in several formats, and
import with a dry-run check first, through the `ImportCompte` component.

**GDPR compliance.** Export request, account deletion with confirmation, and the
`/confidentialite` and `/conditions` pages.

### What the backend does, module by module

**Framework** : NestJS

**Public API** : secured API key through the `X-API-Key` header, rate limiting, GET, POST, PUT and DELETE plus a fifth endpoint, and Swagger documentation served at `https://localhost/api/docs`

**ORM for the database** : Prisma on PostgreSQL

**Real-time features over WebSocket** : state broadcasting, connection and disconnection handling, reconnection to an ongoing match

**Remote authentication** : the OAuth 2.0 flow with the 42 intranet

**Complete 2FA** : TOTP secret generation, verification, enabling and disabling

**Game statistics and match history** : match recording, Elo computation, leaderboard

**Gamification** : achievement computation and progression, stored in the database


**Data export and import** : file generation, validation on import, bulk operations

**GDPR compliance** : data deletion, confirmation emails through Mailhog

**AI opponent** : the AI lives in `backend/game-engine/ai.py` and uses the same commands a human player does

### Module of choice: the Python game engine

Justification required by the subject: to be completed

The engine is roughly 900 lines of Python in `backend/game-engine/`, split into
`motor.py`, `turns.py`, `mulligan.py`, `ai.py` and `game_state.py`, with 103
cards defined in `library.json`.

### Web-based game and remote players

The game itself: real-time play against another user, live matches, clear win
and loss conditions, 2D rendering. Two players on two separate machines, with
latency, disconnection and reconnection handled.

On both of these the design principle is the same, and it is the important one:
**the server is the authority**. The frontend knows no Gwent rule. It receives a
state containing the list of allowed actions and returns a 14-digit code taken
verbatim from that list. All the logic lives in the Python engine, and the server
validates every action before applying it.

Claimed total: 23 points, for a minimum of 14 required by the subject.

## Resources

### Official documentation

- MDN Web Docs, for HTML, CSS, JavaScript and the browser APIs
  (`fetch`, WebSocket, `localStorage`, the Back-Forward Cache) : https://developer.mozilla.org
- React, mainly the pages on components, `useState` and `useEffect` : https://react.dev
- TypeScript, the official handbook : https://www.typescriptlang.org/docs/
- Vite, for configuration and production builds : https://vite.dev
- React Router, for client-side routing : https://reactrouter.com
- Socket.IO, the JavaScript client and reconnection handling : https://socket.io/docs/v4/
- nginx, for the `try_files`, `proxy_pass` and `map` directives : https://nginx.org/en/docs/

### Tutorials

- GeeksforGeeks, JavaScript tutorial : https://www.geeksforgeeks.org/javascript/javascript-tutorial/
- YouTube channels : Grafikart
- GitHub repositories 

### Use of AI

We used AI as a teacher and as a reviewer: to learn concepts that were new to
us, and to help locate errors we could not pin down on our own. Every suggestion
was read, tested and rewritten by hand before being kept.

## Privacy policy and terms of use

- Privacy policy : `/confidentialite`
- Terms of use : `/conditions`