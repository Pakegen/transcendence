export type CarteLibrairie = {
	"Full ID": number;
	"Short ID": number;
	Name: string;
	Type: string;
	Tag: string;
	Strength: number;
	Play_target: string;
	Played: boolean;
	Battlecry: boolean;
	Graveyard: boolean;
	"End Turn": boolean;
	"End Round": boolean;
	"Card Desciption": string;
};

export type VueJoueur = {
	Client_Player_Number: 1 | 2;
	Game_Phase: string;
	Round_number: number;
	Turn_number: number;
	Active_Player: number;
	Active_Opponent: number;
	Mulligan: boolean;
	Card_has_been_played: number;

	Player_1_Crown: number;
	Player_1_has_passed: boolean;
	Player_1_Power_Used?: boolean;
	Player_1_Hand?: number[];
	Player_1_Front_Row: number[];
	Player_1_Back_Row: number[];
	Player_1_Graveyard: number[];
	Player_1_Front_Row_Strength: number;
	Player_1_Back_Row_Strength: number;
	Player_1_Board_Strength: number;
	Player_1_Hand_Count?: number;
	Player_1_Deck_Count?: number;
	Player_1_Graveyard_Count?: number;

	Player_2_Crown: number;
	Player_2_has_passed: boolean;
	Player_2_Power_Used?: boolean;
	Player_2_Hand?: number[];
	Player_2_Front_Row: number[];
	Player_2_Back_Row: number[];
	Player_2_Graveyard: number[];
	Player_2_Front_Row_Strength: number;
	Player_2_Back_Row_Strength: number;
	Player_2_Board_Strength: number;
	Player_2_Hand_Count?: number;
	Player_2_Deck_Count?: number;
	Player_2_Graveyard_Count?: number;

	Available_Commands: string[];

	Winner: number;
	End_Reason: string;

	//null hors phase Turn
	turnDeadline: number | null;
};
