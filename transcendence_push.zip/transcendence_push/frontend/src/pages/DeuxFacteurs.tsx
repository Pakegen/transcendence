import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { verifierDeuxFacteurs } from "../api/auth";
import type { SyntheticEvent } from "react";
import { PiedDePage } from "../components/PiedDePage";
import { couleurs, styleChamp, styleLabel, styleBouton } from "../theme";

// login quand la 2FA est active
// le mot de passe est deja valide, on demande le code de l'appli
function DeuxFacteurs() {
	const [code, setCode] = useState("");
	const [erreur, setErreur] = useState("");
	const [enCours, setEnCours] = useState(false);
	const navigate = useNavigate();

	function soumettre(e: SyntheticEvent) {
		e.preventDefault();
		if (!/^\d{6}$/.test(code)) {
			setErreur("Le code doit contenir exactement 6 chiffres.");
			return;
		}
		setErreur("");
		setEnCours(true);
		verifierDeuxFacteurs(code)
			.then(() => navigate("/menu"))
			.catch((err) => setErreur(err instanceof Error ? err.message : "Erreur de connexion au serveur !"))
			.finally(() => setEnCours(false));
	}

	return (
		<div style={{ maxWidth: 320, margin: "80px auto" }}>
			<h1 style={{ color: couleurs.or, textAlign: "center" }}>Gwent</h1>
			<p style={{ color: couleurs.texteDoux, fontSize: 13, textAlign: "center" }}>
				Saisissez le code à 6 chiffres affiché dans votre application d'authentification.
			</p>

			<form onSubmit={soumettre} style={{ display: "flex", flexDirection: "column", gap: 12 }}>
				<div>
					<label htmlFor="code" style={styleLabel}>Code de vérification</label>
					<input
						id="code"
						type="text"
						inputMode="numeric"
						autoComplete="one-time-code"
						autoFocus
						maxLength={6}
						value={code}
						onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))}
						style={{ ...styleChamp, letterSpacing: 6, textAlign: "center", fontSize: 18 }}
					/>
				</div>

				{erreur && <div role="alert" style={{ color: couleurs.erreur, fontSize: 12 }}>{erreur}</div>}

				<button type="submit" disabled={enCours} style={styleBouton(enCours)}>
					{enCours ? "Vérification..." : "Valider"}
				</button>
			</form>

			<div style={{ marginTop: 16, textAlign: "center", fontSize: 12, color: couleurs.texteDiscret }}>
				<Link to="/connexion" style={{ color: couleurs.or }}>Retour à la connexion</Link>
			</div>
			<PiedDePage />
		</div>
	);
}

export default DeuxFacteurs;
