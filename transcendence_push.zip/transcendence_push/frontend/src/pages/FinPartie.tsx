import { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { mesStats } from "../api/stats";
import { couleurs, styleBouton } from "../theme";

function nomFaction(f: string) {
	return f.replace("_", " ");
}

type Resultat = "victoire" | "defaite" | "egalite";

type EtatFin = {
	resultat: Resultat;
	adversaire: string | null;
	couronnesMoi: number;
	couronnesAdversaire: number;
	eloAvant: number | null;
	eloApres: number | null;
	raison: string;
	// null si pas de nouveau succes de matchup débloqué par cette partie (calculé côté back, voir GameService.finishSession)
	nouveauSucces: { myFaction: string; opponentFaction: string } | null;
};

const defaut: EtatFin = {
	resultat: "victoire",
	adversaire: "geralt42",
	couronnesMoi: 2,
	couronnesAdversaire: 1,
	eloAvant: null,
	eloApres: null,
	raison: "Crowns",
	nouveauSucces: null
};

function FinPartie() {
	const navigate = useNavigate();
	const location = useLocation();
	const etat = (location.state as EtatFin) ?? defaut;
	const nouveauSucces = etat.nouveauSucces;

	const [eloActuel, setEloActuel] = useState<number | null>(null);

	useEffect(() => {
		mesStats()
			.then((s) => setEloActuel(s.elo))
			.catch(() => setEloActuel(null));
	}, []);

	const titres = {
		victoire: "Victoire",
		defaite: "Défaite",
		egalite: "Égalité"
	};

	const couleursResultat = {
		victoire: couleurs.or,
		defaite: couleurs.erreur,
		egalite: couleurs.texteDoux
	};

	return (
		<div style={{ maxWidth: 380, margin: "100px auto", textAlign: "center", display: "flex", flexDirection: "column", gap: 24 }}>
			<h1 style={{ color: couleursResultat[etat.resultat], fontSize: 40, margin: 0 }}>
				{titres[etat.resultat]}
			</h1>

			{etat.raison === "Concede" && (
				<div style={{ fontSize: 13, color: couleurs.texteDoux }}>
					{etat.resultat === "victoire" ? "Votre adversaire a abandonné." : "Vous avez abandonné."}
				</div>
			)}

			{nouveauSucces && (
				<div style={{ padding: 14, background: couleurs.panneau, border: `1px solid ${couleurs.or}`, borderRadius: 8 }}>
					<div style={{ fontSize: 12, color: couleurs.or, fontWeight: "bold", marginBottom: 4 }}>Nouveau succès débloqué</div>
					<div style={{ fontSize: 13, color: couleurs.texteDoux }}>
						Gagner avec {nomFaction(nouveauSucces.myFaction)} contre {nomFaction(nouveauSucces.opponentFaction)}
					</div>
				</div>
			)}

			<div style={{ padding: 20, background: couleurs.panneau, borderRadius: 8 }}>
				<div style={{ fontSize: 12, color: couleurs.texteDoux, marginBottom: 8 }}>Manches</div>
				<div style={{ fontSize: 32, color: couleurs.texte }}>
					{etat.couronnesMoi} <span style={{ color: couleurs.texteDiscret, fontSize: 20 }}>-</span> {etat.couronnesAdversaire}
				</div>
				<div style={{ fontSize: 12, color: couleurs.texteDiscret, marginTop: 8 }}>
					contre {etat.adversaire ?? "l'IA"}
				</div>
			</div>

			{etat.eloAvant !== null && etat.eloApres !== null ? (
				<div style={{ padding: 16, background: couleurs.panneau, borderRadius: 8 }}>
					<div style={{ fontSize: 12, color: couleurs.texteDoux, marginBottom: 6 }}>Classement ELO</div>
					<div style={{ fontSize: 28, fontWeight: "bold", color: couleurs.texte, display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
						<span style={{ color: couleurs.texteDoux, fontSize: 18 }}>{etat.eloAvant}</span>
						<span style={{ color: couleurs.texteDiscret, fontSize: 18 }}>→</span>
						<span style={{ color: couleurs.or }}>{etat.eloApres}</span>
					</div>
					<div
						style={{
							fontSize: 13,
							marginTop: 4,
							color: etat.eloApres > etat.eloAvant ? couleurs.or : etat.eloApres < etat.eloAvant ? couleurs.erreur : couleurs.texteDoux
						}}
					>
						{etat.eloApres > etat.eloAvant && `+${etat.eloApres - etat.eloAvant}`}
						{etat.eloApres < etat.eloAvant && `${etat.eloApres - etat.eloAvant}`}
						{etat.eloApres === etat.eloAvant && "±0"}
					</div>
				</div>
			) : eloActuel !== null && (

				<div style={{ padding: 16, background: couleurs.panneau, borderRadius: 8 }}>
					<div style={{ fontSize: 12, color: couleurs.texteDoux, marginBottom: 6 }}>Classement ELO</div>
					<div style={{ fontSize: 28, fontWeight: "bold", color: couleurs.or }}>{eloActuel}</div>
				</div>
			)}

			<div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
				<button onClick={() => navigate("/combat")} style={styleBouton(false)}>
					Rejouer
				</button>
				<button
					onClick={() => navigate("/menu")}
					style={{ background: "none", border: "none", color: couleurs.texteDiscret, fontSize: 13, cursor: "pointer", fontFamily: "inherit" }}
				>
					Retour au menu
				</button>
			</div>
		</div>
	);
}

export default FinPartie;
