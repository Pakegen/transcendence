import { useNavigate } from "react-router-dom";
import { couleurs } from "../theme";

function Regles() {
	const navigate = useNavigate();
	const styleTitre = { color: couleurs.or, fontSize: 17, marginTop: 24, marginBottom: 8 };
	const styleTexte = { fontSize: 13, lineHeight: 1.7, color: couleurs.texteDoux };

	return (
		<div style={{ maxWidth: 700, margin: "40px auto", padding: "0 20px" }}>
			<button
				onClick={() => navigate(-1)}
				style={{ background: "none", border: "none", color: couleurs.or, fontSize: 12, cursor: "pointer", padding: 0, fontFamily: "inherit" }}
			>
				← Retour
			</button>
			<h1 style={{ color: couleurs.or, marginTop: 16 }}>Règles du jeu</h1>

			<p style={styleTexte}>
				Gwentscendence se joue à deux, un joueur contre un autre ou contre une IA.
				Chaque joueur possède un deck de 25 cartes et un pouvoir héroïque
			</p>

			<h2 style={styleTitre}>Avant la partie</h2>
			<p style={styleTexte}>
				Un tirage au sort désigne qui commence
				Chaque joueur pioche 10 cartes, puis peut faire un mulligan (remplacer certaines cartes de sa main) :
				jusqu'à 3 cartes pour le joueur qui commence, 2 pour l'autre
			</p>

			<h2 style={styleTitre}>Déroulement d'un tour</h2>
			<p style={styleTexte}>
				À son tour, un joueur peut jouer une carte (en mêlée, à distance, ou en
				sort), utiliser son pouvoir héroïque une fois par partie, ou passer la
				manche. Le stratagème, s'il en a un, ne peut être utilisé que par le
				joueur qui commence la partie. Une fois une carte jouée, le joueur peut
				terminer son tour ou continuer à jouer si une action le permet encore
			</p>

			<h2 style={styleTitre}>Fin de manche et couronnes</h2>
			<p style={styleTexte}>
				Quand les deux joueurs ont passé, la manche se termine : on compare la
				somme des forces des cartes posées de chaque côté. Le joueur avec le
				score le plus élevé remporte une couronne (égalité : les deux joueurs en
				reçoivent une). Une nouvelle manche démarre ensuite, chacun pioche
				jusqu'à 3 cartes supplémentaires
			</p>

			<h2 style={styleTitre}>Fin de la partie</h2>
			<p style={styleTexte}>
				La partie se termine dès qu'un joueur remporte 2 manches. En cas
				d'égalité à 2 manches partout, la partie se termine sur un match nul

				Un joueur peut aussi abandonner à tout moment !
			</p>
		</div>
	);
}

export default Regles;
