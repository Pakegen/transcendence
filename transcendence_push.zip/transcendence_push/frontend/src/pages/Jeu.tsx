import { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { Crown, Skull } from "lucide-react";
import { getSocket, getDernierEtat, getAdversaireParti, getConnexionPerdue, oublierEtat, fermerSocket } from "../api/socket";
import { oublierPartieEnCours, lireDernierGameId } from "../api/partie";
import type { VueJoueur } from "../types-moteur";
import { nomCarte } from "../data/cartes";
import { decoder } from "../data/commandes";
import { DetailCarte } from "../components/DetailCarte";
import { Vignette } from "../components/Vignette";
import { Icone } from "../components/Icone";
import { couleurs, styleBouton } from "../theme";
import { jouerSon } from "../api/son";

function Jeu() {
	const [etat, setEtat] = useState<VueJoueur | null>(getDernierEtat());
	const [erreur, setErreur] = useState("");
	const [selection, setSelection] = useState<number | null>(null);
	const [inspection, setInspection] = useState<number | null>(null);
	const [choixMulligan, setChoixMulligan] = useState<number[]>([]);
	const [cimetiereOuvert, setCimetiereOuvert] = useState<"moi" | "lui" | null>(null);
	const [adversaireParti, setAdversaireParti] = useState<boolean>(getAdversaireParti());
	const [connexionPerdue, setConnexionPerdue] = useState<boolean>(getConnexionPerdue());
	const [maintenant, setMaintenant] = useState<number>(() => Date.now());
	const [elo, setElo] = useState<{ avant: number; apres: number } | null>(null);
	const [succes, setSucces] = useState<{ myFaction: string; opponentFaction: string } | null>(null);
	const navigate = useNavigate();
	const location = useLocation();

	const sauvegarde = (() => {
		try {
			return JSON.parse(localStorage.getItem("partieEnCours") ?? "null");
		} catch {
			return null;
		}
	})();
	const room = (location.state?.gameId as string) ?? sauvegarde?.gameId ?? lireDernierGameId() ?? "";
	const adversaire = (location.state?.adversaire as string) ?? sauvegarde?.adversaire ?? null;

	useEffect(() => {
		const socket = getSocket();

		function surEtat(nouvel: VueJoueur) {
			setEtat(nouvel);
			setErreur("");
			setSelection(null);
			setChoixMulligan([]);
			setConnexionPerdue(false);
		}
		function surErreur(donnees: { message: string }) {
			setErreur(donnees.message);
		}
		function surAdversaireParti() {
			setAdversaireParti(true);
		}
		function surAdversaireReconnecte() {
			setAdversaireParti(false);
		}
		function surDeconnexion() {
			setConnexionPerdue(true);
		}
		function surReconnexion() {
			setConnexionPerdue(false);
		}
		function surElo(donnees: { eloAvant: number; eloApres: number }) {
			setElo({ avant: donnees.eloAvant, apres: donnees.eloApres });
		}
		function surSucces(donnees: { myFaction: string; opponentFaction: string }) {
			setSucces(donnees);
		}
		socket.on("game:state", surEtat);
		socket.on("game:error", surErreur);
		socket.on("game:opponent-left", surAdversaireParti);
		socket.on("game:opponent-reconnected", surAdversaireReconnecte);
		socket.on("disconnect", surDeconnexion);
		socket.on("connect", surReconnexion);
		socket.on("game:elo", surElo);
		socket.on("game:succes", surSucces);

		return () => {
			socket.off("game:state", surEtat);
			socket.off("game:error", surErreur);
			socket.off("game:opponent-left", surAdversaireParti);
			socket.off("game:opponent-reconnected", surAdversaireReconnecte);
			socket.off("disconnect", surDeconnexion);
			socket.off("connect", surReconnexion);
			socket.off("game:elo", surElo);
			socket.off("game:succes", surSucces);
		};
	}, []);

	useEffect(() => {
		if (etat === null || etat.Game_Phase !== "Turn")
			return;
		if (etat.Card_has_been_played !== 0)
			return;
		if (Number(etat.Active_Player) === Number(etat.Client_Player_Number))
			jouerSon("tour");
	}, [etat]);

	// Decompte du minuteur de tour = retick chaque sec tant qu'une deadline est connue
	useEffect(() => {
		if (etat?.turnDeadline == null)
			return;
		const id = setInterval(() => setMaintenant(Date.now()), 1000);
		return () => clearInterval(id);
	}, [etat?.turnDeadline]);

	useEffect(() => {
		if (etat === null)
			return;
		if (etat.Game_Phase !== "Game_End")
			return;
		oublierPartieEnCours();
		oublierEtat();
		const n = etat.Client_Player_Number;
		const autre = n === 1 ? 2 : 1;
		const vue = etat as unknown as Record<string, number>;

		navigate("/fin", {
			state: {
				resultat:
					etat.Winner === 0 ? "egalite" :
						etat.Winner === n ? "victoire" : "defaite",
				adversaire,
				couronnesMoi: vue[`Player_${n}_Crown`] ?? 0,
				couronnesAdversaire: vue[`Player_${autre}_Crown`] ?? 0,
				eloAvant: elo?.avant ?? null,
				eloApres: elo?.apres ?? null,
				raison: etat.End_Reason,
				nouveauSucces: succes
			},
			replace: true
		});
	}, [etat, navigate, adversaire, elo, succes]);

	if (etat === null)
		return (
			<div style={{ margin: "120px auto", textAlign: "center", color: couleurs.texteDoux, display: "flex", flexDirection: "column", gap: 16 }}>
				<div>En attente de la partie…</div>
				<button
					onClick={() => { oublierPartieEnCours(); oublierEtat(); navigate("/menu", { replace: true }); }}
					style={{ background: "none", border: "none", color: couleurs.texteDiscret, fontSize: 12, cursor: "pointer", fontFamily: "inherit" }}
				>
					Quitter et revenir au menu
				</button>
			</div>
		);
	const moi = etat.Client_Player_Number;
	const lui = moi === 1 ? 2 : 1;

	function champ<T>(joueur: number, suffixe: string): T {
		return (etat as unknown as Record<string, T>)[`Player_${joueur}_${suffixe}`];
	}
	const mesCommandes: string[] = Array.isArray(etat.Available_Commands) ? etat.Available_Commands : [];
	const enMulligan = etat.Game_Phase === "Mulligan";

	const monTour = enMulligan ? mesCommandes.length > 0 : Number(etat.Active_Player) === Number(moi);
	const secondesRestantes = etat.turnDeadline != null
		? Math.max(0, Math.ceil((etat.turnDeadline - maintenant) / 1000))
		: null;
	const maMain: number[] = champ<number[]>(moi, "Hand") ?? [];
	const maMelee: number[] = champ<number[]>(moi, "Front_Row") ?? [];
	const maDistance: number[] = champ<number[]>(moi, "Back_Row") ?? [];
	const monCimetiere: number[] = champ<number[]>(moi, "Graveyard") ?? [];

	const saMelee: number[] = champ<number[]>(lui, "Front_Row") ?? [];
	const saDistance: number[] = champ<number[]>(lui, "Back_Row") ?? [];
	const sonCimetiere: number[] = champ<number[]>(lui, "Graveyard") ?? [];

	const monTotal = champ<number>(moi, "Board_Strength") ?? 0;
	const sonTotal = champ<number>(lui, "Board_Strength") ?? 0;
	const mesCouronnes = champ<number>(moi, "Crown") ?? 0;
	const sesCouronnes = champ<number>(lui, "Crown") ?? 0;
	const jaiPasse = champ<boolean>(moi, "has_passed") ?? false;
	const ilAPasse = champ<boolean>(lui, "has_passed") ?? false;

	const monPouvoirUtilise = champ<boolean | undefined>(moi, "Power_Used");
	const sonPouvoirUtilise = champ<boolean | undefined>(lui, "Power_Used");
	const monDeck = champ<number | undefined>(moi, "Deck_Count");
	const sonDeck = champ<number | undefined>(lui, "Deck_Count");
	const saMainNombre = champ<number | undefined>(lui, "Hand_Count");

	const codesMulligan = mesCommandes.filter((c) => c.length < 14);
	const maxMulligan = codesMulligan.length > 0
		? Math.max(...codesMulligan.map((c) => (c.length - 2) / 3))
		: 0;

	function codeMulligan(): string | null {
		const tries = [...choixMulligan].sort((a, b) => a - b);
		const vides = maxMulligan - tries.length;
		const corps = [
			...Array(vides).fill("000"),
			...tries.map((id) => String(id).padStart(3, "0"))
		].join("");
		return codesMulligan.find((c) => c.slice(2) === corps) ?? null;
	}
	const carteChoisie = selection !== null ? maMain[selection] : null;

	const codesPourCarte = carteChoisie === null ? [] :
		mesCommandes
			.filter((c) => c.length === 14)
			.map(decoder)
			.filter((c) => c.action === "jouer" && c.carteId === carteChoisie);

	function codeVersZone(zone: number): string | null {
		return codesPourCarte.find((c) => c.zone === zone)?.code ?? null;
	}
	const codeMelee = enMulligan ? null : codeVersZone(3);
	const codeDistance = enMulligan ? null : codeVersZone(4);
	const codeSort = enMulligan ? null : codeVersZone(5);

	function codeAction(type: string): string | null {
		return mesCommandes
			.filter((c) => c.length === 14)
			.map(decoder)
			.find((c) => c.action === type)?.code ?? null;
	}
	const codePasser = codeAction("passer");
	const codeFinTour = codeAction("finTour");
	const codeAbandonner = codeAction("abandonner");
	const codePouvoir = codeAction("pouvoir");

	const codesInconnus = enMulligan ? [] : mesCommandes
		.filter((c) => c.length === 14)
		.map(decoder)
		.filter((c) => c.action === "autre");

	function envoyer(code: string) {
		getSocket().emit("game:action", { room, code });
	}

	function ligneJoueur(
		nom: string,
		couronnes: number,
		passe: boolean,
		deck?: number,
		pouvoirUtilise?: boolean,
		main?: number
	): string {
		const bouts = [nom, `${couronnes}`];
		if (main !== undefined)
			bouts.push(`main ${main}`);
		if (deck !== undefined)
			bouts.push(`deck ${deck}`);
		if (pouvoirUtilise !== undefined)
			bouts.push(pouvoirUtilise ? "pouvoir utilisé" : "pouvoir disponible");
		if (passe)
			bouts.push("a passé");
		return bouts.join(" - ");
	}

	const styleRangee = {
		display: "flex",
		alignItems: "center",
		gap: 6,
		minHeight: "clamp(76px, 12vh, 110px)",
		flexShrink: 0,
		padding: 8,
		background: couleurs.champ,
		border: `1px solid ${couleurs.bordure}`,
		borderRadius: 6,
		overflowX: "auto" as const,
		overflowY: "hidden" as const
	};
	const styleLigneInfo = {
		display: "flex",
		justifyContent: "space-between",
		flexWrap: "wrap" as const,
		gap: 8,
		fontSize: "clamp(10px, 2.6vw, 12px)",
		color: couleurs.texteDoux
	};
	function styleCimetiere(vide: boolean) {
		return {
			background: "none",
			border: "none",
			color: vide ? couleurs.texteDoux : couleurs.or,
			fontSize: "inherit",
			fontFamily: "inherit",
			cursor: vide ? "default" : "pointer",
			padding: 0,
			textDecoration: vide ? "none" : "underline"
		};
	}
	const messageErreur = erreur.toLowerCase().includes("invalide")
		? "Votre plateau n'est plus à jour."
		: erreur;
	function messageGuide(): string {
		if (connexionPerdue)
			return "Connexion perdue, reconnexion en cours.";
		if (adversaireParti)
			return "Votre adversaire s'est déconnecté, on attend son retour.";
		if (enMulligan) {
			if (mesCommandes.length === 0)
				return "En attente de l'adversaire pour le mulligan.";
			return choixMulligan.length === 0
				? `Cliquez jusqu'à ${maxMulligan} carte(s) à remplacer, ou validez directement.`
				: `${choixMulligan.length}/${maxMulligan} carte(s) sélectionnée(s), validez pour continuer.`;
		}
		if (jaiPasse)
			return "Vous avez passé la manche, en attente de l'adversaire.";
		if (!monTour)
			return "C'est au tour de l'adversaire.";
		if (mesCommandes.length === 0)
			return "Le moteur ne propose plus aucune action : la partie ne peut pas continuer.";
		if (carteChoisie === null)
			return codePouvoir !== null
				? "Sélectionnez une carte, ou utilisez votre pouvoir héroïque (une carte ou le pouvoir, pas les deux)."
				: "Sélectionnez une carte de votre main pour la jouer.";
		if (codeMelee === null && codeDistance === null && codeSort === null)
			return "Cette carte ne peut pas être jouée pour le moment.";
		if (codeSort !== null)
			return "Cliquez sur le bouton pour jouer cette carte.";
		if (codeMelee !== null && codeDistance !== null)
			return "Choisissez une rangée : mêlée ou distance.";
		return codeMelee !== null
			? "Cliquez sur votre rangée de mêlée pour poser la carte."
			: "Cliquez sur votre rangée de distance pour poser la carte.";
	}

	return (
		<div style={{ maxWidth: 900, margin: "20px auto", display: "flex", flexDirection: "column", gap: 6 }}>

			<div style={styleLigneInfo}>
				<span>Manche {etat.Round_number} - tour {etat.Turn_number}</span>
				<span>{enMulligan ? "Mulligan" : etat.Game_Phase}</span>
				<span
					style={secondesRestantes !== null && secondesRestantes <= 10
						? { color: couleurs.erreur, fontWeight: "bold" }
						: undefined}
				>
					{monTour ? "À vous de jouer" : "Tour de l'adversaire"}
					{secondesRestantes !== null && ` - ${secondesRestantes}s`}
				</span>
			</div>

			{connexionPerdue && (
				<div style={{ padding: 8, background: couleurs.erreur, color: couleurs.blanc, borderRadius: 6, fontSize: 13, textAlign: "center" }}>
					Connexion perdue - tentative de reconnexion…
				</div>
			)}

			{adversaireParti && !connexionPerdue && (
				<div style={{ padding: 8, background: couleurs.champ, border: `1px solid ${couleurs.erreur}`, color: couleurs.erreur, borderRadius: 6, fontSize: 13, textAlign: "center" }}>
					Adversaire déconnecté - en attente de sa reconnexion…
				</div>
			)}

			<div style={styleLigneInfo}>
				<span style={{ display: "flex", alignItems: "center", gap: 4 }}>
					<Icone icone={Crown} taille={14} titre="Couronnes" />
					{ligneJoueur(adversaire ?? "Adversaire", sesCouronnes, ilAPasse, sonDeck, sonPouvoirUtilise, saMainNombre)}
				</span>
				<button
					onClick={() => setCimetiereOuvert("lui")}
					disabled={sonCimetiere.length === 0}
					style={{ ...styleCimetiere(sonCimetiere.length === 0), display: "flex", alignItems: "center", gap: 4 }}
				>
					<Icone icone={Skull} taille={14} titre="Cimetière" />
					{sonCimetiere.length}
				</button>
				<span style={{ color: couleurs.or, fontSize: "clamp(14px, 4vw, 18px)" }}>{sonTotal}</span>
			</div>

			<div style={styleRangee}>
				{saDistance.map((id, i) => <Vignette key={`sd${i}`} id={id} onClick={() => setInspection(id)} />)}
			</div>
			<div style={styleRangee}>
				{saMelee.map((id, i) => <Vignette key={`sm${i}`} id={id} onClick={() => setInspection(id)} />)}
			</div>

			<div style={{ height: 2, background: couleurs.or, margin: "6px 0" }} />

			<div
				style={{
					...styleRangee,
					background: codeMelee ? couleurs.fondActif : couleurs.champ,
					border: `1px solid ${codeMelee ? couleurs.actif : couleurs.bordure}`,
					cursor: codeMelee ? "pointer" : "default"
				}}
				onClick={() => codeMelee && envoyer(codeMelee)}
			>
				{maMelee.map((id, i) => <Vignette key={`mm${i}`} id={id} onClick={() => setInspection(id)} />)}
			</div>

			<div
				style={{
					...styleRangee,
					background: codeDistance ? couleurs.fondActif : couleurs.champ,
					border: `1px solid ${codeDistance ? couleurs.actif : couleurs.bordure}`,
					cursor: codeDistance ? "pointer" : "default"
				}}
				onClick={() => codeDistance && envoyer(codeDistance)}
			>
				{maDistance.map((id, i) => <Vignette key={`md${i}`} id={id} onClick={() => setInspection(id)} />)}
			</div>

			<div style={styleLigneInfo}>
				<span style={{ display: "flex", alignItems: "center", gap: 4 }}>
					<Icone icone={Crown} taille={14} titre="Couronnes" />
					{ligneJoueur("Vous", mesCouronnes, jaiPasse, monDeck, monPouvoirUtilise, maMain.length)}
				</span>
				<button
					onClick={() => setCimetiereOuvert("moi")}
					disabled={monCimetiere.length === 0}
					style={{ ...styleCimetiere(monCimetiere.length === 0), display: "flex", alignItems: "center", gap: 4 }}
				>
					<Icone icone={Skull} taille={14} titre="Cimetière" />
					{monCimetiere.length}
				</button>
				<span style={{ color: couleurs.or, fontSize: "clamp(14px, 4vw, 18px)" }}>{monTotal}</span>
			</div>

			<div style={{
				...styleRangee,
				height: "auto",
				minHeight: "clamp(90px, 16vh, 130px)",
				paddingTop: 20,
				background: couleurs.panneau,
				overflowY: "hidden"
			}}>
				{maMain.map((id, i) => (
					<Vignette
						key={`main${i}`}
						id={id}
						actif={enMulligan ? choixMulligan.includes(id) : selection === i}
						onClick={() => {
							setInspection(id);
							if (enMulligan) {
								setChoixMulligan((c) =>
									c.includes(id) ? c.filter((x) => x !== id)
										: c.length < maxMulligan ? [...c, id]
											: c
								);
							} else {
								setSelection(selection === i ? null : i);
							}
						}}
					/>
				))}
			</div>

			<div style={{
				padding: 8,
				background: couleurs.champ,
				borderRadius: 6,
				fontSize: 12,
				color: couleurs.texteDoux,
				textAlign: "center",
				minHeight: 18
			}}>
				{messageGuide()}
			</div>

			<DetailCarte id={carteChoisie ?? inspection} />

			{erreur && (
				<div style={{ color: couleurs.erreur, fontSize: 12, display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
					<span>{messageErreur}</span>
					<button
						onClick={() => { fermerSocket(); window.location.href = "/jeu"; }}
						style={{ background: "none", border: `1px solid ${couleurs.bordure}`, borderRadius: 6, color: couleurs.or, fontSize: 12, padding: "4px 10px", cursor: "pointer", fontFamily: "inherit" }}
					>
						Recharger la partie
					</button>
				</div>
			)}
			<div style={{ display: "flex", gap: 10, marginTop: 8, flexWrap: "wrap" }}>
				{enMulligan ? (
					<button
						onClick={() => { const c = codeMulligan(); if (c) envoyer(c); }}
						disabled={codeMulligan() === null}
						style={styleBouton(codeMulligan() === null)}
					>
						Valider le mulligan ({choixMulligan.length}/{maxMulligan})
					</button>
				) : (
					<>
						{codeSort && (
							<button onClick={() => envoyer(codeSort)} style={styleBouton(false)}>
								Jouer {nomCarte(carteChoisie!)}
							</button>
						)}

						{codesInconnus.map((c) => (
							<button key={c.code} onClick={() => envoyer(c.code)} style={styleBouton(false)}>
								{c.carteId > 0 ? nomCarte(c.carteId) : "Action spéciale"}
							</button>
						))}

						<button
							onClick={() => codePouvoir && envoyer(codePouvoir)}
							disabled={!codePouvoir}
							style={styleBouton(!codePouvoir)}
						>
							Pouvoir héroïque
						</button>

						<button
							onClick={() => codeFinTour && envoyer(codeFinTour)}
							disabled={!codeFinTour}
							style={styleBouton(!codeFinTour)}
						>
							Fin de tour
						</button>

						<button
							onClick={() => codePasser && envoyer(codePasser)}
							disabled={!codePasser}
							style={styleBouton(!codePasser)}
						>
							Passer la manche
						</button>

						<button
							onClick={() => codeAbandonner && confirm("Abandonner la partie ?") && envoyer(codeAbandonner)}
							disabled={!codeAbandonner}
							style={{
								padding: 12,
								background: "none",
								color: couleurs.texteDiscret,
								border: `1px solid ${couleurs.bordure}`,
								borderRadius: 8,
								fontSize: 12,
								cursor: codeAbandonner ? "pointer" : "default",
								fontFamily: "inherit"
							}}
						>
							Abandonner
						</button>
					</>
				)}
			</div>

			{cimetiereOuvert !== null && (
				<div
					onClick={() => setCimetiereOuvert(null)}
					style={{
						position: "fixed",
						top: 0,
						left: 0,
						right: 0,
						bottom: 0,
						background: "rgba(0,0,0,0.7)",
						display: "flex",
						alignItems: "center",
						justifyContent: "center",
						padding: 20,
						zIndex: 10
					}}
				>
					<div
						onClick={(e) => e.stopPropagation()}
						style={{
							background: couleurs.panneau,
							border: `1px solid ${couleurs.or}`,
							borderRadius: 8,
							padding: 16,
							maxWidth: 600,
							width: "100%",
							maxHeight: "80vh",
							overflowY: "auto"
						}}
					>
						<div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
							<span style={{ color: couleurs.or, fontSize: 15 }}>
								Cimetière {cimetiereOuvert === "moi" ? "- vous" : `- ${adversaire ?? "adversaire"}`}
							</span>
							<button
								onClick={() => setCimetiereOuvert(null)}
								style={{
									background: "none",
									border: `1px solid ${couleurs.bordure}`,
									borderRadius: 4,
									color: couleurs.texteDoux,
									fontSize: 12,
									padding: "4px 10px",
									cursor: "pointer",
									fontFamily: "inherit"
								}}
							>
								Fermer
							</button>
						</div>

						<div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
							{(cimetiereOuvert === "moi" ? monCimetiere : sonCimetiere).map((id, i) => (
								<Vignette key={`cim${i}`} id={id} onClick={() => setInspection(id)} />
							))}
						</div>
					</div>
				</div>
			)}
		</div>
	);
}

export default Jeu;