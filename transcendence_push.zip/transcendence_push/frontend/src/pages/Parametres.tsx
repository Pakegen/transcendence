import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import type { SyntheticEvent } from "react";
import { Download, Trash2, Volume2 } from "lucide-react";
import {
	moi,
	deconnecter,
	preparerDeuxFacteurs,
	activerDeuxFacteurs,
	desactiverDeuxFacteurs,
} from "../api/auth";
import type { ConfigurationDeuxFacteurs } from "../api/auth";
import { exporterDonnees, supprimerCompte } from "../api/compte";
import type { FormatExport } from "../api/compte";
import { ImportCompte } from "../components/ImportCompte";
import { ClesApi } from "../components/ClesApi";
import { lireReglages, appliquerReglages, REGLAGES_PAR_DEFAUT } from "../api/reglages";
import type { Reglages } from "../api/reglages";
import { jouerSon } from "../api/son";
import {
	Titre,
	Panneau,
	Bouton,
	Champ,
	Onglets,
	Icone,
	Message,
	Chargement,
	Modale,
	LienRetour,
	PiedDePage
} from "../components";
import { couleurs, tailles, espaces } from "../theme";



// 2FA + donnees personnelles (RGPD)
function Parametres() {
	const navigate = useNavigate();

	// null = pas encore reçu la réponse de /auth/me, true/false = état connu
	const [deuxFaActive, setDeuxFaActive] = useState<boolean | null>(null);

	// rempli uniquement pendant l'activation, le temps que l'utilisateur
	// scanne le QR code et entre son premier code
	const [qrCode, setQrCode] = useState<ConfigurationDeuxFacteurs | null>(null);

	const [code, setCode] = useState("");
	const [erreur, setErreur] = useState("");

	// section donnees personnelles
	const [confirmation, setConfirmation] = useState(false);
	const [occupe, setOccupe] = useState<"export" | "suppression" | null>(null);
	const [formatExport, setFormatExport] = useState<FormatExport>("json");
	const [messageCompte, setMessageCompte] = useState("");
	const [erreurCompte, setErreurCompte] = useState("");

	const [reglages, setReglages] = useState<Reglages>(lireReglages());


	// qui est co ? 2FA active ? 2FA pas active ?
	useEffect(() => {
		moi()
			.then((utilisateur) => setDeuxFaActive(utilisateur.twoFactorEnabled))
			// pas de session valide -> retour à la connexion
			.catch(() => navigate("/connexion"));
	}, [navigate]);

	function changerReglages(partiel: Partial<Reglages>) {
		const nouveaux = { ...reglages, ...partiel };
		setReglages(nouveaux);
		appliquerReglages(nouveaux);
		if (partiel.ambiance !== undefined)
			jouerSon("tour");
	}

	function demarrerActivation() {
		setErreur("");
		preparerDeuxFacteurs()
			.then((configuration) => setQrCode(configuration))
			.catch(() => setErreur("Impossible de démarrer l'activation."));
	}

	function validerCode(e: SyntheticEvent) {
		e.preventDefault();
		if (!/^\d{6}$/.test(code)) {
			setErreur("Le code doit contenir exactement 6 chiffres.");
			return;
		}
		setErreur("");

		const envoyer = deuxFaActive ? desactiverDeuxFacteurs(code) : activerDeuxFacteurs(code);

		envoyer
			.then((resultat) => {
				setDeuxFaActive(resultat.twoFactorEnabled);
				setQrCode(null);
				setCode("");
			})
			.catch(() => setErreur("Code invalide."));
	}

	function lancerExport() {
		setErreurCompte("");
		setMessageCompte("");
		setOccupe("export");
		exporterDonnees(formatExport)
			.then(() => setMessageCompte("Fichier téléchargé. Un email de confirmation vous a été envoyé."))
			.catch((e: Error) => setErreurCompte(e.message))
			.finally(() => setOccupe(null));
	}

	function lancerSuppression() {
		setErreurCompte("");
		setMessageCompte("");
		setOccupe("suppression");
		supprimerCompte()
			// le compte n'existe plus : si la deconnexion echoue, ce n'est pas grave
			.then(() => deconnecter().catch(() => undefined))
			.then(() => {
				localStorage.removeItem("partieEnCours");
				navigate("/connexion");
			})
			.catch((e: Error) => {
				setErreurCompte(e.message);
				setConfirmation(false);
			})
			.finally(() => setOccupe(null));
	}

	return (
		<div style={{ maxWidth: 360, margin: "80px auto", padding: "0 16px" }}>
			<Titre>Paramètres</Titre>

			<Panneau titre="Apparence et son">
				<div style={{ fontSize: tailles.minuscule, color: couleurs.texteDoux, marginBottom: espaces.s }}>Thème</div>
				<Onglets
					onglets={[
						{ cle: "witcher", libelle: "Witcher" },
						{ cle: "wild-hunt", libelle: "Wild Hunt" }
					]}
					actif={reglages.theme}
					surChangement={(cle) => changerReglages({ theme: cle as Reglages["theme"] })}
				/>

				<div style={{ fontSize: tailles.minuscule, color: couleurs.texteDoux, marginBottom: espaces.s }}>Typographie</div>
				<Onglets
					onglets={[
						{ cle: "sans", libelle: "Sans serif" },
						{ cle: "serif", libelle: "Serif" }
					]}
					actif={reglages.police}
					surChangement={(cle) => changerReglages({ police: cle as Reglages["police"] })}
				/>

				<div style={{ display: "flex", alignItems: "center", gap: 4, fontSize: tailles.minuscule, color: couleurs.texteDoux, marginBottom: espaces.s }}>
					<Icone icone={Volume2} taille={14} />
					Ambiance sonore
				</div>
				<Onglets
					onglets={[
						{ cle: "classique", libelle: "Classique" },
						{ cle: "grave", libelle: "Grave" },
						{ cle: "coupe", libelle: "Coupé" }
					]}
					actif={reglages.ambiance}
					surChangement={(cle) => changerReglages({ ambiance: cle as Reglages["ambiance"] })}
				/>

				<Bouton
					variante="secondaire"
					onClick={() => changerReglages(REGLAGES_PAR_DEFAUT)}
					pleineLargeur
				>
					Rétablir les réglages par défaut
				</Bouton>
			</Panneau>

			<Panneau titre="Double authentification (2FA)" style={{ marginTop: espaces.l }}>

				{/* Cas 1 : on ne sait pas encore si la 2FA est active */}
				{deuxFaActive === null && <Chargement />}

				{/* Cas 2 : 2FA désactivée, et on n'a pas encore demandé le QR code */}
				{deuxFaActive === false && qrCode === null && (
					<Bouton onClick={demarrerActivation} pleineLargeur>
						Activer la 2FA
					</Bouton>
				)}

				{/* Cas 3 : on vient de demander le QR code, reste à le scanner puis confirmer */}
				{qrCode !== null && (
					<div>
						<p style={{ color: couleurs.texteDoux, fontSize: tailles.petit }}>
							Scannez ce QR code avec votre application d'authentification.
						</p>
						<img
							src={qrCode.qrCode}
							alt="QR code de configuration de la double authentification"
							style={{ display: "block", margin: "0 auto", width: 200, height: 200, background: "#fff", borderRadius: 6 }}
						/>
						<p style={{ color: couleurs.texteDiscret, fontSize: tailles.minuscule, wordBreak: "break-all" }}>
							Ou saisissez la clé manuellement : <code style={{ color: couleurs.texteClair }}>{qrCode.secret}</code>
						</p>
					</div>
				)}

				{/* Cas 4 : 2FA déjà active, on ne propose que la désactivation */}
				{deuxFaActive === true && (
					<p style={{ color: couleurs.texteDoux, fontSize: tailles.petit }}>La double authentification est activée.</p>
				)}

				{/* Le formulaire de code sert à la fois à confirmer l'activation (cas 3) et à désactiver (cas 4) */}
				{(qrCode !== null || deuxFaActive === true) && (
					<form onSubmit={validerCode} style={{ marginTop: espaces.s }}>
						<Champ
							id="code"
							label="Code à 6 chiffres"
							valeur={code}
							surChangement={(valeur) => setCode(valeur.replace(/\D/g, ""))}
							inputMode="numeric"
							autoComplete="one-time-code"
							maxLength={6}
							style={{ letterSpacing: 6, textAlign: "center", fontSize: 18 }}
						/>
						<Bouton type="submit" pleineLargeur>
							{deuxFaActive ? "Désactiver" : "Confirmer l'activation"}
						</Bouton>
					</form>
				)}

				{erreur && <Message ton="erreur">{erreur}</Message>}
			</Panneau>

			<Panneau titre="Mes données" style={{ marginTop: espaces.l }}>
				<p style={{ color: couleurs.texteDoux, fontSize: tailles.petit }}>
					Vous pouvez récupérer une copie de vos données ou supprimer définitivement votre compte.
					Un email de confirmation est envoyé à chaque opération.
				</p>

				<div style={{ fontSize: tailles.minuscule, color: couleurs.texteDoux, marginBottom: espaces.s }}>Format de l'export</div>
				<Onglets
					onglets={[
						{ cle: "json", libelle: "JSON" },
						{ cle: "csv", libelle: "CSV (tableur)" }
					]}
					actif={formatExport}
					surChangement={(cle) => setFormatExport(cle as FormatExport)}
				/>

				<Bouton onClick={lancerExport} desactive={occupe !== null} pleineLargeur>
					<span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}>
						<Icone icone={Download} taille={16} />
						{occupe === "export" ? "Préparation..." : "Télécharger mes données"}
					</span>
				</Bouton>

				<Bouton
					variante="danger"
					onClick={() => { setErreurCompte(""); setMessageCompte(""); setConfirmation(true); }}
					desactive={occupe !== null}
					pleineLargeur
					style={{ marginTop: espaces.s }}
				>
					<span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}>
						<Icone icone={Trash2} taille={16} />
						Supprimer mon compte
					</span>
				</Bouton>

				{messageCompte && <Message ton="succes">{messageCompte}</Message>}
				{erreurCompte && <Message ton="erreur">{erreurCompte}</Message>}

				<ImportCompte />
			</Panneau>

			<ClesApi />

			{/* on ne supprime jamais sur un seul clic */}
			{confirmation && (
				<Modale titre="Supprimer le compte ?" surFermeture={() => setConfirmation(false)} danger>
					<p style={{ color: couleurs.texteDoux, fontSize: tailles.petit }}>
						Cette action est définitive. Votre compte est anonymisé : pseudo, email et
						identifiants sont effacés, et la connexion devient impossible. Les parties
						déjà jouées restent dans l'historique de vos adversaires, sans votre nom.
						Pensez à télécharger vos données avant.
					</p>
					<Bouton variante="danger" onClick={lancerSuppression} desactive={occupe !== null} pleineLargeur>
						{occupe === "suppression" ? "Suppression..." : "Oui, supprimer définitivement"}
					</Bouton>
					<Bouton variante="secondaire" onClick={() => setConfirmation(false)} pleineLargeur style={{ marginTop: espaces.s }}>
						Annuler
					</Bouton>
				</Modale>
			)}

			<LienRetour />
			<PiedDePage />
		</div>
	);
}

export default Parametres;