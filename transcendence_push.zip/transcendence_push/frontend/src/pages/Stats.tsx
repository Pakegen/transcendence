import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { mesStats, historique, leaderboard } from "../api/stats";
import type { MesStats, PartieHistorique, LigneClassement } from "../api/stats";
import { Titre, Panneau, Onglets, Tableau, Badge, Chargement, Message } from "../components";
import type { Colonne } from "../components";
import { couleurs, tailles, espaces } from "../theme";

type Onglet = "stats" | "historique" | "classement";

const onglets = [
	{ cle: "stats", libelle: "Mes stats" },
	{ cle: "historique", libelle: "Historique" },
	{ cle: "classement", libelle: "Classement" }
];

const FACTIONS = ["Witcher", "Wild_Hunt"];

const SUCCES = FACTIONS.flatMap((mienne) =>
	FACTIONS.map((sienne) => ({ mienne, sienne }))
);

function nomFaction(f: string) {
	return f.replace("_", " ");
}

function date(iso: string) {
	return new Date(iso).toLocaleDateString("fr-FR");
}

const colonnesHistorique: Colonne<PartieHistorique>[] = [
	{ titre: "Date", rendu: (p) => date(p.playedAt) },
	{ titre: "Mode", rendu: (p) => p.opponent === null ? "IA" : "Humain" },
	{ titre: "Adversaire", rendu: (p) => p.opponent ?? "IA" },
	{ titre: "Factions", rendu: (p) => `${nomFaction(p.myFaction)} / ${nomFaction(p.opponentFaction)}` },
	{
		titre: "Résultat",
		rendu: (p) => (
			<Badge ton={p.outcome === "WIN" ? "positif" : p.outcome === "LOSS" ? "negatif" : "neutre"}>
				{p.outcome === "WIN" ? "Victoire" : p.outcome === "LOSS" ? "Défaite" : "Égalité"}
			</Badge>
		)
	}
];

const colonnesClassement: Colonne<LigneClassement>[] = [
	{ titre: "#", rendu: (l) => l.rank },
	{ titre: "Joueur", rendu: (l) => l.username },
	{ titre: "ELO", rendu: (l) => <span style={{ color: couleurs.or }}>{l.elo}</span>, alignement: "right" }
];

function Stats() {
	const [onglet, setOnglet] = useState<Onglet>("stats");
	const [stats, setStats] = useState<MesStats | null>(null);
	const [parties, setParties] = useState<PartieHistorique[]>([]);
	const [classement, setClassement] = useState<LigneClassement[]>([]);
	const [erreur, setErreur] = useState("");
	const [enCours, setEnCours] = useState(true);
	const navigate = useNavigate();

	useEffect(() => {
		Promise.all([mesStats(), historique(20), leaderboard(20)])
			.then(([s, h, c]) => {
				setStats(s);
				setParties(h);
				setClassement(c);
			})
			.catch((err) => setErreur(err instanceof Error ? err.message : "Erreur."))
			.finally(() => setEnCours(false));
	}, []);

	return (
		<div style={{ maxWidth: 600, margin: "40px auto", padding: "0 16px", display: "flex", flexDirection: "column", gap: 16 }}>
			<button
				onClick={() => navigate("/menu")}
				style={{ alignSelf: "flex-start", background: "none", border: "none", color: couleurs.or, fontSize: 12, cursor: "pointer", padding: 0, fontFamily: "inherit" }}
			>
				← Menu
			</button>

			<Titre>Statistiques</Titre>

			<Onglets onglets={onglets} actif={onglet} surChangement={(cle) => setOnglet(cle as Onglet)} />

			{enCours && <Chargement texte="Chargement…" />}
			{erreur && <Message ton="erreur">{erreur}</Message>}

			{!enCours && !erreur && onglet === "stats" && stats && (
				<div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
					<Panneau style={{ textAlign: "center" }}>
						<div style={{ fontSize: tailles.minuscule, color: couleurs.texteDoux }}>Classement ELO</div>
						<div style={{ fontSize: 36, fontWeight: "bold", color: couleurs.or }}>{stats.elo}</div>
					</Panneau>

					<div style={{ display: "flex", gap: 8, textAlign: "center" }}>
						<Panneau style={{ flex: 1, padding: espaces.m }}>
							<div style={{ fontSize: 22, color: couleurs.texte }}>{stats.wins}</div>
							<div style={{ fontSize: 11, color: couleurs.texteDoux }}>victoires</div>
						</Panneau>
						<Panneau style={{ flex: 1, padding: espaces.m }}>
							<div style={{ fontSize: 22, color: couleurs.texte }}>{stats.losses}</div>
							<div style={{ fontSize: 11, color: couleurs.texteDoux }}>défaites</div>
						</Panneau>
						<Panneau style={{ flex: 1, padding: espaces.m }}>
							<div style={{ fontSize: 22, color: couleurs.texte }}>{stats.draws}</div>
							<div style={{ fontSize: 11, color: couleurs.texteDoux }}>égalités</div>
						</Panneau>
					</div>

					<div>
						<div style={{ display: "flex", justifyContent: "space-between", fontSize: tailles.petit, color: couleurs.or, marginBottom: 8 }}>
							<span>Succès</span>
							<span>{stats.matchupsWon.length} / {SUCCES.length}</span>
						</div>

						<div style={{ height: 6, background: couleurs.inactif, borderRadius: 3, marginBottom: 12 }}>
							<div style={{
								height: "100%",
								width: `${(stats.matchupsWon.length / SUCCES.length) * 100}%`,
								background: couleurs.or,
								borderRadius: 3
							}} />
						</div>

						{SUCCES.map((succes) => {
							const obtenu = stats.matchupsWon.find(
								(m) => m.myFaction === succes.mienne && m.opponentFaction === succes.sienne
							);
							return (
								<div
									key={`${succes.mienne}-${succes.sienne}`}
									style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8, padding: "6px 0", fontSize: tailles.minuscule }}
								>
									<span style={{ color: obtenu ? couleurs.texteClair : couleurs.texteDiscret }}>
										Gagner avec {nomFaction(succes.mienne)} contre {nomFaction(succes.sienne)}
									</span>
									{obtenu
										? <Badge ton="positif">{date(obtenu.firstWinAt)}</Badge>
										: <Badge ton="neutre">À faire</Badge>}
								</div>
							);
						})}
					</div>
				</div>
			)}

			{!enCours && !erreur && onglet === "historique" && (
				<Tableau
					colonnes={colonnesHistorique}
					lignes={parties}
					cle={(p) => p.id}
					vide="Aucune partie jouée."
				/>
			)}

			{!enCours && !erreur && onglet === "classement" && (
				<Tableau
					colonnes={colonnesClassement}
					lignes={classement}
					cle={(l) => l.id}
					vide="Classement vide."
				/>
			)}
		</div>
	);
}

export default Stats;