import { useNavigate } from "react-router-dom";
import { couleurs } from "../theme";

function Confidentialite() {
	const navigate = useNavigate();
	const styleTitre = { color: "#b8860b", fontSize: 17, marginTop: 24, marginBottom: 8 };
	const styleTexte = { fontSize: 13, lineHeight: 1.7, color: "#ccc" };

	return (
		<div style={{ maxWidth: 700, margin: "40px auto", padding: "0 20px" }}>
			<button
				onClick={() => navigate(-1)}
				style={{ background: "none", border: "none", color: "#b8860b", fontSize: 12, cursor: "pointer", padding: 0, fontFamily: "inherit" }}
			>
				← Retour
			</button>
			<h1 style={{ color: "#b8860b", marginTop: 16 }}>Politique de confidentialité</h1>

			<h2 style={styleTitre}>Qui sommes-nous</h2>
			<p style={styleTexte}>
				Ce site est un projet étudiant réalisé dans le cadre du cursus de l'école 42.
				Il n'a aucune vocation commerciale.
			</p>

			<h2 style={styleTitre}>Données collectées</h2>
			<p style={styleTexte}>
				Lors de la création d'un compte, nous enregistrons votre adresse email,
				votre pseudonyme et votre mot de passe. Le mot de passe n'est jamais
				stocké en clair : il est haché avec l'algorithme argon2, et nous ne
				pouvons donc pas le consulter. Nous conservons également la date de
				création et de dernière modification de votre compte.
			</p>

			<h2 style={styleTitre}>Finalité</h2>
			<p style={styleTexte}>
				L'email sert à identifier votre compte lors de la connexion. Le pseudonyme
				vous identifie auprès des autres joueurs. Aucune de ces données n'est
				utilisée à des fins publicitaires ou statistiques.
			</p>

			<h2 style={styleTitre}>Session</h2>
			<p style={styleTexte}>
				Lorsque vous vous connectez, un cookie technique contenant un jeton de
				session est déposé sur votre navigateur pour une durée de sept jours.
				Il est inaccessible au code JavaScript et transmis uniquement en HTTPS.
				Ce cookie est strictement nécessaire au fonctionnement du service et ne
				sert à aucun suivi publicitaire.
			</p>

			<h2 style={styleTitre}>Connexion avec 42</h2>
			<p style={styleTexte}>
				Si vous vous connectez avec votre compte 42, nous demandons à l'intranet
				de 42 un accès en lecture seule à votre profil public (autorisation
				« public » uniquement). Nous n'en conservons que votre identifiant 42,
				votre login, utilisé comme pseudonyme, et votre adresse email. Le jeton
				d'accès fourni par 42 sert uniquement à lire ces informations et n'est
				jamais enregistré. Un tel compte n'a pas de mot de passe sur notre site.
				Un cookie technique temporaire (cinq minutes) protège l'aller-retour vers
				l'intranet de 42.
			</p>

			<h2 style={styleTitre}>Double authentification</h2>
			<p style={styleTexte}>
				Si vous activez la double authentification, une clé secrète est générée
				et stockée sur le serveur afin de vérifier les codes produits par votre
				application d'authentification. Cette clé est supprimée dès que vous
				désactivez l'option. Lors d'une connexion, un cookie technique temporaire
				(cinq minutes) est déposé le temps de saisir votre code.
			</p>

			<h2 style={styleTitre}>Partage</h2>
			<p style={styleTexte}>
				Vos données ne sont transmises à aucun tiers. Elles sont stockées sur
				le serveur hébergeant l'application et ne quittent pas celui-ci.
			</p>

			<h2 style={styleTitre}>Conservation et suppression</h2>
			<p style={styleTexte}>
				Vos données sont conservées tant que votre compte existe. Vous pouvez le
				supprimer à tout moment depuis la page Paramètres. Votre adresse email et
				votre pseudonyme sont alors remplacés par des valeurs anonymes, votre mot
				de passe est rendu inutilisable et vos clés d'API sont détruites : le compte
				ne permet plus de vous identifier et la connexion devient impossible. Les
				parties que vous avez jouées restent enregistrées sous cette forme anonyme,
				car elles constituent aussi l'historique et le classement de vos adversaires,
				que nous ne pouvons pas modifier sans porter atteinte à leurs propres données.
			</p>

			<h2 style={styleTitre}>Vos droits</h2>
			<p style={styleTexte}>
				Conformément au RGPD, vous disposez d'un droit d'accès, de rectification et
				de suppression de vos données personnelles. Vous pouvez les exercer
				directement depuis la page Paramètres : « Télécharger mes données » vous
				remet l'intégralité de votre profil et de vos parties au format JSON ou CSV,
				l'import vous permet de corriger votre pseudonyme et votre adresse email, et
				la suppression du compte est immédiate. Pour toute autre demande, écrivez-nous
				à l'adresse ci-dessous.
			</p>

			<h2 style={styleTitre}>Contact</h2>
			<p style={styleTexte}>
				<a href="mailto:quinny.allain@gmail.com" style={{ color: couleurs.or }}>
					quinny.allain@gmail.com
				</a>
			</p>
		</div>
	);
}

export default Confidentialite;