import { useRef, useState } from "react";
import type { ChangeEvent } from "react";
import { Upload } from "lucide-react";
import { importerCompte, TAILLE_MAX_IMPORT } from "../api/compte";
import type { ResultatImport } from "../api/compte";
import { Bouton } from "./Bouton";
import { Icone } from "./Icone";
import { Message } from "./Message";
import { couleurs, tailles, espaces, styleChamp, styleLabel } from "../theme";

const EXTENSIONS = [".json", ".csv"];

const NOMS = { username: "Pseudo", email: "Email" } as const;

type Props = {
	// pour que la page parente puisse rafraichir ce qu'elle affiche
	surImport?: () => void;
};

// Import du pseudo et/ou de l'email depuis un fichier .json ou .csv
// (par exemple son propre export, modifie). En 2 temps : "Vérifier" montre
// les changements sans rien enregistrer, puis "Confirmer" les applique
export function ImportCompte({ surImport }: Props) {
	const [fichier, setFichier] = useState<File | null>(null);
	const [apercu, setApercu] = useState<ResultatImport | null>(null);
	const [erreur, setErreur] = useState("");
	const [succes, setSucces] = useState("");
	const [occupe, setOccupe] = useState(false);
	// pour vider le <input type="file"> apres un import reussi
	const champFichier = useRef<HTMLInputElement>(null);

	function choisir(e: ChangeEvent<HTMLInputElement>) {
		const choisi = e.target.files?.[0] ?? null;
		setApercu(null);
		setErreur("");
		setSucces("");
		setFichier(null);
		if (!choisi)
			return;
		// validation front (le backend refait les memes verifications)
		if (!EXTENSIONS.some((extension) => choisi.name.toLowerCase().endsWith(extension))) {
			setErreur("Format non supporté : fichier .json ou .csv attendu.");
			return;
		}
		if (choisi.size > TAILLE_MAX_IMPORT) {
			setErreur("Fichier trop gros (100 Ko maximum).");
			return;
		}
		setFichier(choisi);
	}

	function envoyer(verification: boolean) {
		if (!fichier)
			return;
		setErreur("");
		setSucces("");
		setOccupe(true);
		importerCompte(fichier, verification)
			.then((resultat) => {
				if (verification) {
					setApercu(resultat);
					return;
				}
				setApercu(null);
				setFichier(null);
				if (champFichier.current)
					champFichier.current.value = "";
				setSucces("Compte mis à jour. Un email de confirmation a été envoyé à votre ancienne adresse.");
				surImport?.();
			})
			.catch((e: Error) => setErreur(e.message))
			.finally(() => setOccupe(false));
	}

	const changements = apercu ? (Object.entries(apercu.changes) as [keyof typeof NOMS, { before: string; after: string }][]) : [];

	return (
		<div style={{ marginTop: espaces.l }}>
			<h3 style={{ color: couleurs.texte, fontSize: tailles.normal, margin: `0 0 ${espaces.s}px` }}>Importer</h3>
			<p style={{ color: couleurs.texteDoux, fontSize: tailles.petit, marginTop: 0 }}>
				Modifiez votre pseudo et/ou votre email à partir d'un fichier .json ou .csv, par exemple votre
				export modifié. Seuls le pseudo et l'email sont pris en compte.
			</p>

			<label htmlFor="fichier-import" style={styleLabel}>Fichier (100 Ko maximum)</label>
			<input
				id="fichier-import"
				ref={champFichier}
				type="file"
				accept={EXTENSIONS.join(",")}
				onChange={choisir}
				style={{ ...styleChamp, marginBottom: espaces.s }}
			/>

			<Bouton onClick={() => envoyer(true)} desactive={!fichier || occupe} pleineLargeur>
				<span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}>
					<Icone icone={Upload} taille={16} />
					{occupe && !apercu ? "Vérification..." : "Vérifier le fichier"}
				</span>
			</Bouton>

			{apercu && changements.length === 0 && (
				<Message ton="info">Rien à modifier : le fichier contient déjà vos informations actuelles.</Message>
			)}

			{apercu && changements.length > 0 && (
				<div style={{ marginTop: espaces.s }} aria-live="polite">
					<div style={{ color: couleurs.texteDoux, fontSize: tailles.petit, marginBottom: espaces.s }}>
						Changements qui seront appliqués :
					</div>
					{changements.map(([champ, changement]) => (
						<div key={champ} style={{ fontSize: tailles.petit, color: couleurs.texteClair, marginBottom: espaces.xs, wordBreak: "break-all" }}>
							{NOMS[champ]} : <span style={{ color: couleurs.texteDiscret }}>{changement.before}</span> → <span style={{ color: couleurs.or }}>{changement.after}</span>
						</div>
					))}
					<div style={{ display: "flex", gap: espaces.s, marginTop: espaces.s }}>
						<Bouton onClick={() => envoyer(false)} desactive={occupe} style={{ flex: 1 }}>
							{occupe ? "Enregistrement..." : "Confirmer"}
						</Bouton>
						<Bouton variante="secondaire" onClick={() => setApercu(null)} desactive={occupe} style={{ flex: 1 }}>
							Annuler
						</Bouton>
					</div>
				</div>
			)}

			{succes && <Message ton="succes">{succes}</Message>}
			{erreur && <Message ton="erreur">{erreur}</Message>}
		</div>
	);
}
