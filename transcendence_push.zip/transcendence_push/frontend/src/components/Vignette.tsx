import type { LucideIcon } from "lucide-react";
import { Swords, Sparkles, Landmark, Flag } from "lucide-react";
import { couleurs } from "../theme";
import { carteParId, nomCarte, forceBase } from "../data/cartes";
import { Icone } from "./Icone";

type Props = {
	id: number;
	actif?: boolean;
	onClick?: () => void;
};

const couleurParType: Record<string, string> = {
	Unit: couleurs.carteUnite,
	Spell: couleurs.carteSort,
	Location: couleurs.carteLieu,
	Stratagem: couleurs.carteStrategeme
};

const iconeParType: Record<string, LucideIcon> = {
	Unit: Swords,
	Spell: Sparkles,
	Location: Landmark,
	Stratagem: Flag
};

export function Vignette({ id, actif, onClick }: Props) {
	const carte = carteParId(id);
	const type = carte?.Type ?? "Unit";
	const teinte = couleurParType[type] ?? couleurs.or;
	const icone = iconeParType[type] ?? Swords;
	const tag = carte?.Tag && carte.Tag !== "None" ? carte.Tag : null;
	const trait = type === "Stratagem" ? "dashed" : "solid";

	return (
		<div
			onClick={onClick ? (e) => { e.stopPropagation(); onClick(); } : undefined}
			title={carte?.Name}
			style={{
				position: "relative",
				width: "clamp(48px, 13vw, 70px)",
				height: "clamp(60px, 18vw, 92px)",
				flexShrink: 0,
				background: couleurs.carte,
				border: `2px ${trait} ${actif ? couleurs.blanc : teinte}`,
				borderRadius: 8,
				padding: 6,
				paddingTop: 9,
				display: "flex",
				flexDirection: "column",
				justifyContent: "space-between",
				overflow: "hidden",
				cursor: onClick ? "pointer" : "default",
				transform: actif ? "translateY(-10px)" : "none"
			}}
		>
			<div style={{
				position: "absolute",
				top: 0,
				left: 0,
				right: 0,
				height: 3,
				background: teinte
			}} />

			<div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
				<span style={{ fontSize: "clamp(14px, 4vw, 20px)", fontWeight: "bold", color: couleurs.texte }}>
					{forceBase(id)}
				</span>
				<Icone icone={icone} taille={12} couleur={teinte} titre={type} />
			</div>

			<div style={{ fontSize: "clamp(8px, 2.2vw, 10px)", lineHeight: 1.15, color: couleurs.texteClair }}>
				{nomCarte(id)}
			</div>

			<div style={{ fontSize: 8, color: couleurs.texteDiscret, minHeight: 10 }}>
				{tag}
			</div>
		</div>
	);
}