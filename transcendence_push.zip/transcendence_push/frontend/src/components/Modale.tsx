import { useEffect } from "react";
import type { ReactNode } from "react";
import { couleurs, tailles, espaces, rayon } from "../theme";

type Props = {
	titre: string;
	children: ReactNode;
	surFermeture: () => void;
	danger?: boolean;
};

export function Modale({ titre, children, surFermeture, danger = false }: Props) {
	useEffect(() => {
		function surTouche(e: KeyboardEvent) {
			if (e.key === "Escape")
				surFermeture();
		}
		window.addEventListener("keydown", surTouche);
		return () => window.removeEventListener("keydown", surTouche);
	}, [surFermeture]);

	return (
		<div
			onClick={surFermeture}
			style={{
				position: "fixed", top: 0, left: 0, right: 0, bottom: 0,
				background: "rgba(0,0,0,0.7)", zIndex: 10,
				display: "flex", alignItems: "center", justifyContent: "center",
				padding: espaces.l
			}}
		>
			<div
				onClick={(e) => e.stopPropagation()}
				role="dialog"
				aria-modal="true"
				style={{
					background: couleurs.panneau,
					border: `1px solid ${danger ? couleurs.erreur : couleurs.bordure}`,
					borderRadius: rayon,
					padding: espaces.xl,
					maxWidth: 320,
					width: "100%"
				}}
			>
				<h2 style={{ color: danger ? couleurs.erreur : couleurs.or, fontSize: tailles.sousTitre, marginTop: 0 }}>
					{titre}
				</h2>
				{children}
			</div>
		</div>
	);
}