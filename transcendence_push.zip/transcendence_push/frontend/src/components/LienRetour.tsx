import { Link } from "react-router-dom";
import { couleurs, tailles, espaces } from "../theme";

type Props = {
	vers?: string;
	libelle?: string;
};

export function LienRetour({ vers = "/menu", libelle = "Retour au menu" }: Props) {
	return (
		<div style={{ marginTop: espaces.l, textAlign: "center", fontSize: tailles.minuscule }}>
			<Link to={vers} style={{ color: couleurs.or }}>{libelle}</Link>
		</div>
	);
}