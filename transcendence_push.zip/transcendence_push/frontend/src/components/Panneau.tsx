import type { CSSProperties, ReactNode } from "react";
import { couleurs, tailles, espaces, rayon } from "../theme";

type Props = {
	children: ReactNode;
	titre?: string;
	style?: CSSProperties;
};

export function Panneau({ children, titre, style }: Props) {
	return (
		<section
			style={{
				background: couleurs.panneau,
				border: `1px solid ${couleurs.bordure}`,
				borderRadius: rayon,
				padding: espaces.l,
				...style
			}}
		>
			{titre && (
				<h2 style={{ color: couleurs.texte, fontSize: tailles.sousTitre, marginTop: 0 }}>
					{titre}
				</h2>
			)}
			{children}
		</section>
	);
}