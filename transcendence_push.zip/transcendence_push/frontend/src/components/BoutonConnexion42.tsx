import { URL_CONNEXION_42 } from "../api/auth";
import { fermerSocket } from "../api/socket";
import { oublierToutesLesParties } from "../api/partie";
import { couleurs } from "../theme";

// Lien et pas bouton + fetch : le navigateur doit vraiment aller sur l'intra 42
export function BoutonConnexion42() {
	return (
		<a
			href={URL_CONNEXION_42}
			onClick={() => { fermerSocket(); oublierToutesLesParties(); }}
			style={{
				display: "block",
				padding: 12,
				background: couleurs.champ,
				color: couleurs.texte,
				border: `2px solid ${couleurs.bordure}`,
				borderRadius: 8,
				fontSize: 14,
				fontWeight: "bold",
				textAlign: "center",
				textDecoration: "none",
			}}>
			Se connecter avec 42
		</a>
	);
}