import type { CSSProperties } from "react";
import { couleurs, tailles, espaces, styleChamp, styleLabel } from "../theme";

type Props = {
	id: string;
	label: string;
	valeur: string;
	surChangement: (valeur: string) => void;
	type?: string;
	placeholder?: string;
	maxLength?: number;
	inputMode?: "text" | "numeric" | "email";
	autoComplete?: string;
	erreur?: string;
	style?: CSSProperties;
};

export function Champ({
	id,
	label,
	valeur,
	surChangement,
	type = "text",
	placeholder,
	maxLength,
	inputMode,
	autoComplete,
	erreur,
	style
}: Props) {
	return (
		<div style={{ marginBottom: espaces.m }}>
			<label htmlFor={id} style={styleLabel}>{label}</label>
			<input
				id={id}
				type={type}
				value={valeur}
				onChange={(e) => surChangement(e.target.value)}
				placeholder={placeholder}
				maxLength={maxLength}
				inputMode={inputMode}
				autoComplete={autoComplete}
				aria-invalid={erreur !== undefined && erreur !== ""}
				style={{
					...styleChamp,
					borderColor: erreur ? couleurs.erreur : couleurs.bordure,
					...style
				}}
			/>
			{erreur && (
				<div style={{ color: couleurs.erreur, fontSize: tailles.minuscule, marginTop: espaces.xs }}>
					{erreur}
				</div>
			)}
		</div>
	);
}