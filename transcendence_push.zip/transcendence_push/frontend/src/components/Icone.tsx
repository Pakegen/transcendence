import type { LucideIcon } from "lucide-react";
import { couleurs } from "../theme";

type Props = {
	icone: LucideIcon;
	taille?: number;
	couleur?: string;
	titre?: string;
};

export function Icone({ icone: Composant, taille = 18, couleur = couleurs.texteDoux, titre }: Props) {
	return (
		<Composant
			size={taille}
			color={couleur}
			aria-hidden={titre === undefined}
			aria-label={titre}
		/>
	);
}