import { couleurs, tailles, espaces } from "../theme";

type Ton = "neutre" | "positif" | "negatif" | "or";

type Props = {
	children: string;
	ton?: Ton;
};

const teintes: Record<Ton, string> = {
	neutre: couleurs.texteDoux,
	positif: couleurs.actif,
	negatif: couleurs.erreur,
	or: couleurs.or
};

export function Badge({ children, ton = "neutre" }: Props) {
	return (
		<span
			style={{
				color: teintes[ton],
				border: `1px solid ${teintes[ton]}`,
				borderRadius: 999,
				padding: `2px ${espaces.s}px`,
				fontSize: tailles.minuscule,
				whiteSpace: "nowrap"
			}}
		>
			{children}
		</span>
	);
}