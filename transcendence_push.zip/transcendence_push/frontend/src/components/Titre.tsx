import type { ReactNode } from "react";
import { couleurs, tailles, espaces } from "../theme";

type Props = {
	children: ReactNode;
	niveau?: 1 | 2;
	centre?: boolean;
};

export function Titre({ children, niveau = 1, centre = true }: Props) {
	const style = {
		color: couleurs.or,
		textAlign: centre ? ("center" as const) : ("left" as const),
		fontSize: niveau === 1 ? tailles.titre : tailles.sousTitre,
		marginTop: 0,
		marginBottom: espaces.l
	};
	return niveau === 1 ? <h1 style={style}>{children}</h1> : <h2 style={style}>{children}</h2>;
}