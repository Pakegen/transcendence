import type { ReactNode } from "react";
import { couleurs, tailles, espaces } from "../theme";

export type Colonne<T> = {
	titre: string;
	rendu: (ligne: T) => ReactNode;
	alignement?: "left" | "center" | "right";
};

type Props<T> = {
	colonnes: Colonne<T>[];
	lignes: T[];
	cle: (ligne: T, index: number) => string | number;
	vide?: string;
};

export function Tableau<T>({ colonnes, lignes, cle, vide = "Aucune donnée." }: Props<T>) {
	if (lignes.length === 0)
		return <p style={{ color: couleurs.texteDiscret, fontSize: tailles.petit }}>{vide}</p>;

	return (
		<table style={{ width: "100%", borderCollapse: "collapse", fontSize: tailles.petit }}>
			<thead>
				<tr>
					{colonnes.map((colonne) => (
						<th
							key={colonne.titre}
							style={{
								color: couleurs.texteDoux,
								textAlign: colonne.alignement ?? "left",
								borderBottom: `1px solid ${couleurs.bordure}`,
								padding: espaces.s,
								fontWeight: "normal"
							}}
						>
							{colonne.titre}
						</th>
					))}
				</tr>
			</thead>
			<tbody>
				{lignes.map((ligne, index) => (
					<tr key={cle(ligne, index)}>
						{colonnes.map((colonne) => (
							<td
								key={colonne.titre}
								style={{
									color: couleurs.texteClair,
									textAlign: colonne.alignement ?? "left",
									borderBottom: `1px solid ${couleurs.inactif}`,
									padding: espaces.s
								}}
							>
								{colonne.rendu(ligne)}
							</td>
						))}
					</tr>
				))}
			</tbody>
		</table>
	);
}