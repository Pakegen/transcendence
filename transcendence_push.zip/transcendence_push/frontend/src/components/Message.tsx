import { couleurs, tailles, espaces, rayon } from "../theme";

type Ton = "erreur" | "succes" | "info";

type Props = {
	ton: Ton;
	children: string;
};

const teintes: Record<Ton, string> = {
	erreur: couleurs.erreur,
	succes: couleurs.actif,
	info: couleurs.texteDoux
};

export function Message({ ton, children }: Props) {
	return (
		<div
			role={ton === "erreur" ? "alert" : undefined}
			aria-live={ton === "erreur" ? undefined : "polite"}
			style={{
				color: teintes[ton],
				fontSize: tailles.minuscule,
				border: `1px solid ${teintes[ton]}`,
				borderRadius: rayon,
				padding: espaces.s,
				marginTop: espaces.s
			}}
		>
			{children}
		</div>
	);
}