import { useEffect, useState } from "react";
import type { SyntheticEvent } from "react";
import { Copy, KeyRound, Trash2 } from "lucide-react";
import { creerCles, listerCles, revoquerCles, MAX_CLES_PAR_COMPTE, MAX_CLES_PAR_CREATION } from "../api/compte";
import type { CleApi, CleApiCreee } from "../api/compte";
import { Bouton } from "./Bouton";
import { Chargement } from "./Chargement";
import { Icone } from "./Icone";
import { Message } from "./Message";
import { Modale } from "./Modale";
import { Panneau } from "./Panneau";
import { Tableau } from "./Tableau";
import type { Colonne } from "./Tableau";
import { couleurs, tailles, espaces, styleChamp, styleLabel } from "../theme";

function date(iso: string | null) {
	return iso ? new Date(iso).toLocaleDateString("fr-FR") : "jamais";
}

function copier(texte: string) {
	if (!navigator.clipboard)
		return;
	navigator.clipboard.writeText(texte).catch(() => { });
}

// Gestion des cles API (pour l'API publique /api/docs) avec operations en
// masse : creer plusieurs cles d'un coup, en revoquer plusieurs d'un coup.
// Cote serveur, chaque operation est "tout ou rien"
export function ClesApi() {
	const [cles, setCles] = useState<CleApi[] | null>(null);
	const [selection, setSelection] = useState<Set<number>>(new Set());
	const [noms, setNoms] = useState("");
	// cles en clair renvoyees par la creation : affichees UNE seule fois
	const [nouvelles, setNouvelles] = useState<CleApiCreee[]>([]);
	const [confirmation, setConfirmation] = useState(false);
	const [occupe, setOccupe] = useState(false);
	const [erreur, setErreur] = useState("");
	const [succes, setSucces] = useState("");

	function recharger() {
		return listerCles()
			.then((liste) => {
				setCles(liste);
				// on retire de la selection les cles qui n'existent plus
				setSelection((avant) => new Set([...avant].filter((id) => liste.some((cle) => cle.id === id))));
			})
			.catch((e: Error) => setErreur(e.message));
	}

	useEffect(() => {
		listerCles()
			.then(setCles)
			.catch((e: Error) => setErreur(e.message));
	}, []);

	// un nom par ligne, lignes vides ignorees
	const labels = noms.split("\n").map((nom) => nom.trim()).filter(Boolean);

	function valider() {
		if (labels.length === 0)
			return "Saisissez au moins un nom (un par ligne).";
		if (labels.length > MAX_CLES_PAR_CREATION)
			return `${MAX_CLES_PAR_CREATION} clés maximum à la fois.`;
		if (labels.some((nom) => nom.length > 50))
			return "Chaque nom fait 50 caractères maximum.";
		if (cles && cles.length + labels.length > MAX_CLES_PAR_COMPTE)
			return `${MAX_CLES_PAR_COMPTE} clés maximum par compte (vous en avez ${cles.length}).`;
		return "";
	}

	function creer(e: SyntheticEvent) {
		e.preventDefault();
		const probleme = valider();
		setErreur(probleme);
		setSucces("");
		if (probleme)
			return;
		setOccupe(true);
		creerCles(labels)
			.then((creees) => {
				setNouvelles(creees);
				setNoms("");
				return recharger();
			})
			.catch((e: Error) => setErreur(e.message))
			.finally(() => setOccupe(false));
	}

	function revoquer() {
		setErreur("");
		setSucces("");
		setOccupe(true);
		revoquerCles([...selection])
			.then((nombre) => {
				setSucces(`${nombre} clé(s) révoquée(s).`);
				setSelection(new Set());
				return recharger();
			})
			.catch((e: Error) => setErreur(e.message))
			.finally(() => {
				setOccupe(false);
				setConfirmation(false);
			});
	}

	function basculer(id: number) {
		setSelection((avant) => {
			const apres = new Set(avant);
			if (apres.has(id))
				apres.delete(id);
			else
				apres.add(id);
			return apres;
		});
	}

	const toutCoche = cles !== null && cles.length > 0 && selection.size === cles.length;

	function basculerTout() {
		setSelection(toutCoche || !cles ? new Set() : new Set(cles.map((cle) => cle.id)));
	}

	const colonnes: Colonne<CleApi>[] = [
		{
			titre: "",
			rendu: (cle) => (
				<input
					type="checkbox"
					checked={selection.has(cle.id)}
					onChange={() => basculer(cle.id)}
					aria-label={`Sélectionner la clé ${cle.label ?? cle.id}`}
				/>
			)
		},
		{ titre: "Nom", rendu: (cle) => cle.label ?? <span style={{ color: couleurs.texteDiscret }}>sans nom</span> },
		{ titre: "Créée le", rendu: (cle) => date(cle.createdAt) },
		{ titre: "Utilisée le", rendu: (cle) => date(cle.lastUsedAt) }
	];

	return (
		<Panneau titre="Clés API" style={{ marginTop: espaces.l }}>
			<p style={{ color: couleurs.texteDoux, fontSize: tailles.petit, marginTop: 0 }}>
				Une clé API permet à un programme d'utiliser l'API publique du site (documentation sur /api/docs).
				{" "}{MAX_CLES_PAR_COMPTE} clés maximum par compte.
			</p>

			{cles === null && !erreur && <Chargement />}

			{cles !== null && (
				<>
					{cles.length > 0 && (
						<label style={{ display: "flex", alignItems: "center", gap: espaces.s, fontSize: tailles.petit, color: couleurs.texteDoux }}>
							<input type="checkbox" checked={toutCoche} onChange={basculerTout} />
							Tout sélectionner
						</label>
					)}
					<Tableau colonnes={colonnes} lignes={cles} cle={(cle) => cle.id} vide="Aucune clé pour l'instant." />
					<Bouton
						variante="danger"
						onClick={() => setConfirmation(true)}
						desactive={selection.size === 0 || occupe}
						pleineLargeur
						style={{ marginTop: espaces.s }}
					>
						<span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}>
							<Icone icone={Trash2} taille={16} />
							Révoquer la sélection ({selection.size})
						</span>
					</Bouton>
				</>
			)}

			<form onSubmit={creer} style={{ marginTop: espaces.l }}>
				<label htmlFor="noms-cles" style={styleLabel}>
					Créer des clés : un nom par ligne ({MAX_CLES_PAR_CREATION} maximum)
				</label>
				<textarea
					id="noms-cles"
					value={noms}
					onChange={(e) => setNoms(e.target.value)}
					rows={3}
					placeholder={"script stats\nbot discord"}
					style={{ ...styleChamp, resize: "vertical", marginBottom: espaces.s }}
				/>
				<Bouton type="submit" desactive={occupe} pleineLargeur>
					<span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}>
						<Icone icone={KeyRound} taille={16} />
						{occupe ? "Patientez..." : `Créer ${labels.length > 1 ? `${labels.length} clés` : "la clé"}`}
					</span>
				</Bouton>
			</form>

			{nouvelles.length > 0 && (
				<div style={{ marginTop: espaces.m, border: `1px solid ${couleurs.or}`, borderRadius: 8, padding: espaces.m }} aria-live="polite">
					<div style={{ color: couleurs.or, fontSize: tailles.petit, marginBottom: espaces.s }}>
						Copiez vos clés maintenant : elles ne seront plus jamais affichées.
					</div>
					{nouvelles.map((cle) => (
						<div key={cle.id} style={{ marginBottom: espaces.s }}>
							<div style={{ fontSize: tailles.minuscule, color: couleurs.texteDoux }}>{cle.label ?? "sans nom"}</div>
							<div style={{ display: "flex", gap: espaces.s, alignItems: "center" }}>
								<code style={{ flex: 1, fontSize: tailles.minuscule, color: couleurs.texteClair, wordBreak: "break-all" }}>{cle.key}</code>
								<Bouton variante="secondaire" onClick={() => copier(cle.key)} style={{ padding: espaces.s }}>
									<Icone icone={Copy} taille={14} titre={`Copier la clé ${cle.label ?? ""}`} />
								</Bouton>
							</div>
						</div>
					))}
					<Bouton variante="secondaire" onClick={() => setNouvelles([])} pleineLargeur>
						J'ai copié mes clés
					</Bouton>
				</div>
			)}

			{succes && <Message ton="succes">{succes}</Message>}
			{erreur && <Message ton="erreur">{erreur}</Message>}

			{confirmation && (
				<Modale titre={`Révoquer ${selection.size} clé(s) ?`} surFermeture={() => setConfirmation(false)} danger>
					<p style={{ color: couleurs.texteDoux, fontSize: tailles.petit }}>
						Les programmes qui utilisent ces clés ne pourront plus accéder à l'API. Cette action est définitive.
					</p>
					<Bouton variante="danger" onClick={revoquer} desactive={occupe} pleineLargeur>
						{occupe ? "Révocation..." : "Oui, révoquer"}
					</Bouton>
					<Bouton variante="secondaire" onClick={() => setConfirmation(false)} pleineLargeur style={{ marginTop: espaces.s }}>
						Annuler
					</Bouton>
				</Modale>
			)}
		</Panneau>
	);
}