import { couleurs, tailles, espaces, rayon } from "../theme";

type Onglet = {
	cle: string;
	libelle: string;
};

type Props = {
	onglets: Onglet[];
	actif: string;
	surChangement: (cle: string) => void;
};

export function Onglets({ onglets, actif, surChangement }: Props) {
	return (
		<div role="tablist" style={{ display: "flex", gap: espaces.s, marginBottom: espaces.l, flexWrap: "wrap" }}>
			{onglets.map((onglet) => {
				const choisi = onglet.cle === actif;
				return (
					<button
						key={onglet.cle}
						role="tab"
						aria-selected={choisi}
						onClick={() => surChangement(onglet.cle)}
						style={{
							background: choisi ? couleurs.fondActif : "transparent",
							border: `1px solid ${choisi ? couleurs.or : couleurs.bordure}`,
							color: choisi ? couleurs.or : couleurs.texteDoux,
							borderRadius: rayon,
							padding: `${espaces.s}px ${espaces.m}px`,
							fontSize: tailles.petit,
							fontFamily: "inherit",
							cursor: "pointer"
						}}
					>
						{onglet.libelle}
					</button>
				);
			})}
		</div>
	);
}