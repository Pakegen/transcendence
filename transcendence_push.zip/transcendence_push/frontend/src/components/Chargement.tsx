import { couleurs, tailles, espaces } from "../theme";

type Props = {
	texte?: string;
};

export function Chargement({ texte = "Chargement..." }: Props) {
	return (
		<p aria-live="polite" style={{ color: couleurs.texteDoux, fontSize: tailles.petit, padding: espaces.s }}>
			{texte}
		</p>
	);
}