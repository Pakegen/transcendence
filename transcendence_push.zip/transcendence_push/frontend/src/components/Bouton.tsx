import type { CSSProperties, ReactNode } from "react";
import { couleurs, polices, tailles, espaces, rayon } from "../theme";

type Variante = "principal" | "secondaire" | "danger";

type Props = {
	children: ReactNode;
	onClick?: () => void;
	type?: "button" | "submit";
	variante?: Variante;
	desactive?: boolean;
	pleineLargeur?: boolean;
	style?: CSSProperties;
};

const bordures: Record<Variante, string> = {
	principal: couleurs.or,
	secondaire: couleurs.bordure,
	danger: couleurs.erreur
};

const textes: Record<Variante, string> = {
	principal: couleurs.or,
	secondaire: couleurs.texteDoux,
	danger: couleurs.erreur
};

export function Bouton({
	children,
	onClick,
	type = "button",
	variante = "principal",
	desactive = false,
	pleineLargeur = false,
	style
}: Props) {
	return (
		<button
			type={type}
			onClick={onClick}
			disabled={desactive}
			style={{
				background: desactive ? couleurs.fondDesactive : "transparent",
				border: `1px solid ${desactive ? couleurs.desactive : bordures[variante]}`,
				color: desactive ? couleurs.desactive : textes[variante],
				borderRadius: rayon,
				padding: `${espaces.m}px ${espaces.l}px`,
				fontSize: tailles.normal,
				fontFamily: polices.principale,
				cursor: desactive ? "not-allowed" : "pointer",
				width: pleineLargeur ? "100%" : undefined,
				...style
			}}
		>
			{children}
		</button>
	);
}