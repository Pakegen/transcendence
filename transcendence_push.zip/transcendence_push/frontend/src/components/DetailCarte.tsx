import { carteParId } from "../data/cartes";
import { couleurs } from "../theme";

export function DetailCarte({ id }: { id: number | null }) {
	const carte = id === null ? undefined : carteParId(id);
	const tag = carte?.Tag && carte.Tag !== "None" ? carte.Tag : null;
	const effetAnnonce = carte !== undefined && carte.Type !== "Stratagem" && (
		carte.Battlecry || carte["End Turn"] || carte["End Round"] || carte.Graveyard
	);

	function description() {
		if (carte === undefined)
			return "";
		if (carte.Type === "Stratagem")
			return "Stratagème : +5 au score de votre plateau pour cette manche, si vous avez au moins une unité posée. Retiré du jeu après usage, ne consomme pas votre carte du tour.";
		return carte["Card Desciption"] || "Pas d'effet particulier.";
	}

	return (
		<div style={{
			padding: 12,
			background: couleurs.panneau,
			border: `1px solid ${couleurs.bordure}`,
			borderRadius: 6,
			fontSize: 12,
			color: couleurs.texteDoux,
			minHeight: 72
		}}>
			{carte ? (
				<>
					<div style={{ fontSize: 15, fontWeight: "bold", color: couleurs.or, marginBottom: 4 }}>
						{carte.Name}
					</div>
					<div style={{ marginBottom: 4 }}>
						Force {carte.Strength} - {carte.Type}{tag ? ` - ${tag}` : ""}
					</div>
					<div style={{ color: couleurs.texteDiscret, lineHeight: 1.5 }}>
						{description()}
					</div>
					{effetAnnonce && (
						<div style={{ color: couleurs.erreur, fontSize: 11, marginTop: 6, fontStyle: "italic" }}>
							Effet non appliqué dans cette version du moteur.
						</div>
					)}
				</>
			) : (
				<div style={{ color: couleurs.texteDiscret, fontStyle: "italic" }}>
					Sélectionnez une carte pour voir ses informations.
				</div>
			)}
		</div>
	);
}