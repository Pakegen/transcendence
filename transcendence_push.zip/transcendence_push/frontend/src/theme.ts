import type { CSSProperties } from "react";

export const couleurs = {
	or: "var(--or)",
	fond: "var(--fond)",
	panneau: "var(--panneau)",
	champ: "var(--champ)",
	carte: "var(--carte)",
	bordure: "var(--bordure)",
	texte: "var(--texte)",
	texteClair: "var(--texte-clair)",
	texteDoux: "var(--texte-doux)",
	texteDiscret: "var(--texte-discret)",
	erreur: "var(--erreur)",
	inactif: "var(--inactif)",
	desactive: "var(--desactive)",
	fondDesactive: "var(--fond-desactive)",
	actif: "var(--actif)",
	fondActif: "var(--fond-actif)",
	blanc: "var(--blanc)",
	carteUnite: "var(--carte-unite)",
	carteSort: "var(--carte-sort)",
	carteLieu: "var(--carte-lieu)",
	carteStrategeme: "var(--carte-strategeme)",
};

export const styleChamp: CSSProperties = {
	width: "100%",
	padding: 10,
	background: couleurs.champ,
	border: `1px solid ${couleurs.bordure}`,
	borderRadius: 6,
	color: couleurs.texte,
	fontSize: 14,
	fontFamily: "inherit",
	boxSizing: "border-box"
};

export const styleLabel: CSSProperties = {
	display: "block",
	fontSize: 12,
	color: couleurs.texteDoux,
	marginBottom: 4
};

export function styleBouton(desactive: boolean): CSSProperties {
	return {
		padding: 12,
		background: desactive ? couleurs.fondDesactive : couleurs.carte,
		color: desactive ? couleurs.desactive : couleurs.or,
		border: `2px solid ${couleurs.or}`,
		borderRadius: 8,
		fontSize: 14,
		fontWeight: "bold",
		cursor: desactive ? "default" : "pointer",
		fontFamily: "inherit"
	};
}

export const polices = {
	principale: "var(--police)",
	chiffres: "'Segoe UI', system-ui, monospace"
};

export const tailles = {
	titre: 24,
	sousTitre: 16,
	normal: 14,
	petit: 13,
	minuscule: 12
};

export const espaces = {
	xs: 4,
	s: 8,
	m: 12,
	l: 16,
	xl: 24
};

export const rayon = 8;