import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import { lireReglages, appliquerReglages } from "./api/reglages";
import "./index.css";

appliquerReglages(lireReglages());

createRoot(document.getElementById("root")!).render(
	<StrictMode>
		<App />
	</StrictMode>
);