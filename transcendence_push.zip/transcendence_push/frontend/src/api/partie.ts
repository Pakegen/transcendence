export type PartieSauvegardee = {
	gameId: string;
	adversaire: string | null;
	date: number;
};

const DUREE_MAX = 2 * 60 * 60 * 1000;

export function lirePartieEnCours(): PartieSauvegardee | null {
	try {
		const brut = JSON.parse(localStorage.getItem("partieEnCours") ?? "null");
		if (brut === null || typeof brut.gameId !== "string")
			return null;
		if (Date.now() - (brut.date ?? 0) > DUREE_MAX) {
			localStorage.removeItem("partieEnCours");
			return null;
		}
		return brut;
	} catch {
		return null;
	}
}

export function oublierPartieEnCours() {
	const brut = localStorage.getItem("partieEnCours");
	if (brut !== null)
		localStorage.setItem("dernierePartie", brut);
	localStorage.removeItem("partieEnCours");
}

export function lireDernierGameId(): string | null {
	try {
		const brut = JSON.parse(localStorage.getItem("dernierePartie") ?? "null");
		return typeof brut?.gameId === "string" ? brut.gameId : null;
	} catch {
		return null;
	}
}

export function oublierToutesLesParties() {
	localStorage.removeItem("partieEnCours");
	localStorage.removeItem("dernierePartie");
}