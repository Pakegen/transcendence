const API_URL = "/api";

// Ces deux routes acceptent le cookie de session : credentials "include" suffit,
// plus besoin de demander une cle d'API comme avant.
// Le backend envoie aussi un email de confirmation de son cote.

// Telecharge un objet JSON sous forme de fichier, sans passer par le serveur.
// On fabrique un faux lien, on clique dessus, on le jette.
function telechargerJson(donnees: unknown, nomFichier: string) {
	const texte = JSON.stringify(donnees, null, 2);
	const fichier = new Blob([texte], { type: "application/json" });
	const adresse = URL.createObjectURL(fichier);

	const lien = document.createElement("a");
	lien.href = adresse;
	lien.download = nomFichier;
	lien.click();

	// sinon le navigateur garde le fichier en memoire
	URL.revokeObjectURL(adresse);
}

export type FormatExport = "json" | "csv";

// Le message d'erreur du backend : une string, ou un tableau (un message par
// champ invalide, renvoye par la validation)
async function lireErreur(reponse: Response, defaut: string): Promise<string> {
	if (reponse.status === 413)
		return "Fichier trop gros.";
	if (reponse.status === 429)
		return "Trop de tentatives, réessayez dans une minute.";
	try {
		const corps = await reponse.json();
		if (Array.isArray(corps.message))
			return corps.message.join(" ");
		if (typeof corps.message === "string")
			return corps.message;
	} catch {
		// corps vide ou pas du JSON : on garde le message par defaut
	}
	return `${defaut} (${reponse.status}).`;
}

function telechargerBlob(fichier: Blob, nomFichier: string) {
	const adresse = URL.createObjectURL(fichier);
	const lien = document.createElement("a");
	lien.href = adresse;
	lien.download = nomFichier;
	lien.click();
	URL.revokeObjectURL(adresse);
}

// json : le backend renvoie l'objet { user, matches }, transforme ici en fichier
// csv  : le backend renvoie directement le fichier (2 tableaux : profil + parties)
export async function exporterDonnees(format: FormatExport = "json"): Promise<void> {
	const reponse = await fetch(`${API_URL}/account/me/export?format=${format}`, {
		credentials: "include"
	});
	if (!reponse.ok)
		throw new Error(await lireErreur(reponse, "L'export a echoue"));
	const jour = new Date().toISOString().slice(0, 10);
	if (format === "csv") {
		telechargerBlob(await reponse.blob(), `mes-donnees-${jour}.csv`);
		return;
	}
	const donnees = await reponse.json();
	telechargerJson(donnees, `mes-donnees-${jour}.json`);
}

// ---------- Import du pseudo / de l'email ----------

// Doit correspondre a MAX_IMPORT_BYTES dans backend/src/account/import-file.ts
export const TAILLE_MAX_IMPORT = 100 * 1024;

type Changement = { before: string; after: string };

export type ResultatImport = {
	dryRun: boolean;
	updated: boolean;
	changes: { username?: Changement; email?: Changement };
	account: { username: string; email: string };
};

// verification = true : le backend valide et renvoie les changements SANS
// les enregistrer. false : il enregistre et previent l'ancienne adresse email
export async function importerCompte(fichier: File, verification: boolean): Promise<ResultatImport> {
	const formulaire = new FormData();
	formulaire.append("file", fichier);
	// pas de Content-Type a la main : le navigateur met multipart/form-data + boundary
	const reponse = await fetch(`${API_URL}/account/me/import?dryRun=${verification}`, {
		method: "POST",
		credentials: "include",
		body: formulaire
	});
	if (!reponse.ok)
		throw new Error(await lireErreur(reponse, "L'import a echoue"));
	return (await reponse.json()) as ResultatImport;
}

// ---------- Cles API (operations en masse) ----------

// Doivent correspondre au backend (dto/bulk-api-keys.dto.ts et api-key.service.ts)
export const MAX_CLES_PAR_CREATION = 10;
export const MAX_CLES_PAR_COMPTE = 20;

export type CleApi = {
	id: number;
	label: string | null;
	createdAt: string;
	lastUsedAt: string | null;
};

// renvoyee une seule fois, a la creation
export type CleApiCreee = CleApi & { key: string };

export async function listerCles(): Promise<CleApi[]> {
	const reponse = await fetch(`${API_URL}/account/me/api-keys`, { credentials: "include" });
	if (!reponse.ok)
		throw new Error(await lireErreur(reponse, "Impossible de charger les cles"));
	return (await reponse.json()) as CleApi[];
}

export async function creerCles(labels: string[]): Promise<CleApiCreee[]> {
	const reponse = await fetch(`${API_URL}/account/me/api-keys/bulk`, {
		method: "POST",
		credentials: "include",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({ labels })
	});
	if (!reponse.ok)
		throw new Error(await lireErreur(reponse, "La creation a echoue"));
	return (await reponse.json()) as CleApiCreee[];
}

export async function revoquerCles(ids: number[]): Promise<number> {
	const reponse = await fetch(`${API_URL}/account/me/api-keys/revoke`, {
		method: "POST",
		credentials: "include",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({ ids })
	});
	if (!reponse.ok)
		throw new Error(await lireErreur(reponse, "La revocation a echoue"));
	return ((await reponse.json()) as { revoked: number }).revoked;
}

export async function supprimerCompte(): Promise<void> {
	const reponse = await fetch(`${API_URL}/account/me`, {
		method: "DELETE",
		credentials: "include"
	});
	if (!reponse.ok)
		throw new Error(`La suppression a echoue (${reponse.status}).`);
	const donnees = await reponse.json().catch(() => null);
	if (donnees !== null && donnees.ok !== true)
		throw new Error("La suppression a echoue.");
}