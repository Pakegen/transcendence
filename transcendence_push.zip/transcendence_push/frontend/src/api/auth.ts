// Client pour les endpoints /auth du backend.
// Passe par nginx (https://localhost/api/...), pas directement par le port 3000 du
// backend: le sujet impose HTTPS pour toute connexion navigateur -> backend.
import { fermerSocket } from "./socket";
import { oublierToutesLesParties } from "./partie";

const API_URL = import.meta.env.VITE_API_URL ?? "/api";
export type UtilisateurPublic = {
	id: number;
	email: string;
	username: string;
	twoFactorEnabled: boolean;
};


// Sois session ouverte sois 2FA activé sur le compte et il faut encore passer par /2fa
export type ResultatConnexion = UtilisateurPublic | { twoFactorRequired: true };

export type ConfigurationDeuxFacteurs = {
	qrCode: string; // data:image/png;base64 pret pour un <img>
	secret: string; // saisie manuelle si le scan n'est pas possible
};

type CorpsErreurApi = {
	message: string | string[];
	error?: string;
	statusCode: number;
};

function messageErreur(corps: CorpsErreurApi): string {
	// Le ValidationPipe du backend renvoie un tableau de messages (un par
	// champ invalide), les autres erreurs (409, 401) renvoient une string
	return Array.isArray(corps.message) ? corps.message[0] : corps.message;
}

async function appelAuth<T>(chemin: string, donnees?: unknown): Promise<T> {
	const reponse = await fetch(`${API_URL}/auth/${chemin}`, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		// necessaire pour que le navigateur envoie/accepte le cookie de
		// session httpOnly renvoye par le backend (voir auth.controller.ts)
		credentials: "include",
		body: JSON.stringify(donnees ?? {}),
	});

	const corps = await reponse.json();
	if (!reponse.ok) throw new Error(messageErreur(corps as CorpsErreurApi));
	return corps as T;
}

export function inscrire(email: string, username: string, password: string) {
	fermerSocket();
	oublierToutesLesParties();
	return appelAuth<UtilisateurPublic>("signup", { email, username, password });
}

export function connecter(email: string, password: string) {
	fermerSocket();
	oublierToutesLesParties();
	return appelAuth<ResultatConnexion>("login", { email, password });
}

// 2FA activé mais faut encore passer par /2fa/
export function verifierDeuxFacteurs(code: string) {
	return appelAuth<UtilisateurPublic>("2fa/verify", { code });
}

// demande qr code + 2FA pas encore activé
export function preparerDeuxFacteurs() {
	return appelAuth<ConfigurationDeuxFacteurs>("2fa/setup");
}

export function activerDeuxFacteurs(code: string) {
	return appelAuth<{ twoFactorEnabled: boolean }>("2fa/enable", { code });
}

export function desactiverDeuxFacteurs(code: string) {
	return appelAuth<{ twoFactorEnabled: boolean }>("2fa/disable", { code });
}

// Renvoie l'utilisateur connecte, ou null si la session est absente ou expirée
export async function utilisateurConnecte(): Promise<UtilisateurPublic | null> {
	const reponse = await fetch(`${API_URL}/auth/me`, { credentials: "include" });
	if (!reponse.ok)
		return null;
	return (await reponse.json()) as UtilisateurPublic;
}

export async function deconnecter(): Promise<void> {
	await fetch(`${API_URL}/auth/logout`, { method: "POST", credentials: "include" });

	fermerSocket();
	oublierToutesLesParties();
}

// Comme utilisateurConnecte, mais rejette au lieu de renvoyer null (utilise
// par les pages qui exigent deja une session, ex Parametres.tsx)
export async function moi(): Promise<UtilisateurPublic> {
	const utilisateur = await utilisateurConnecte();
	if (!utilisateur) throw new Error("Session absente ou expiree.");
	return utilisateur;
}

// OAuth 42 : navigation complete vers le back (pas un fetch), qui redirige
// vers l'intra puis, au retour, vers /menu, /2fa ou /connexion?erreur=<code>
export const URL_CONNEXION_42 = `${API_URL}/auth/42`;

// Codes renvoyes par le back dans /connexion?erreur=<code> (voir forty-two.service.ts)
const MESSAGES_ERREUR_42: Record<string, string> = {
	oauth_refuse: "Connexion avec 42 annulée.",
	oauth_state: "La connexion avec 42 a expiré, veuillez réessayer.",
	oauth_echec: "La connexion avec 42 a échoué, veuillez réessayer.",
	oauth_indisponible: "La connexion avec 42 n'est pas disponible pour le moment.",
	email_pris: "Un compte existe déjà avec cet email : connectez-vous avec votre mot de passe.",
};

export function messageErreurConnexion42(code: string | null): string {
	if (!code) return "";
	return MESSAGES_ERREUR_42[code] ?? MESSAGES_ERREUR_42.oauth_echec;
}

