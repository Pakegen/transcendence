import { lireReglages } from "./reglages";

let contexte: AudioContext | null = null;
let gesteFait = false;

const ambiances = {
	classique: {
		forme: "sine" as OscillatorType,
		notes: { tour: 660, manche: 880, erreur: 220 }
	},
	grave: {
		forme: "triangle" as OscillatorType,
		notes: { tour: 294, manche: 392, erreur: 110 }
	}
};

function noterGeste() {
	gesteFait = true;
	if (contexte !== null && contexte.state === "suspended")
		contexte.resume();
	window.removeEventListener("pointerdown", noterGeste);
	window.removeEventListener("keydown", noterGeste);
}

window.addEventListener("pointerdown", noterGeste);
window.addEventListener("keydown", noterGeste);

export function jouerSon(type: "tour" | "manche" | "erreur") {
	const ambiance = lireReglages().ambiance;
	if (ambiance === "coupe")
		return;
	if (!gesteFait)
		return;
	try {
		if (contexte === null)
			contexte = new AudioContext();
		if (contexte.state === "suspended")
			contexte.resume();
		const reglage = ambiances[ambiance];
		const oscillateur = contexte.createOscillator();
		const volume = contexte.createGain();
		oscillateur.frequency.value = reglage.notes[type];
		oscillateur.type = reglage.forme;
		volume.gain.setValueAtTime(0.05, contexte.currentTime);
		volume.gain.exponentialRampToValueAtTime(0.0001, contexte.currentTime + 0.25);
		oscillateur.connect(volume);
		volume.connect(contexte.destination);
		oscillateur.start();
		oscillateur.stop(contexte.currentTime + 0.25);
	} catch {
		return;
	}
}