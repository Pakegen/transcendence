import { io, Socket } from "socket.io-client";
import type { VueJoueur } from "../types-moteur";

let socket: Socket | null = null;
let dernierEtat: VueJoueur | null = null;
let adversaireParti = false;
let connexionPerdue = false;

export function getSocket(): Socket {
	if (socket === null) {
		socket = io({
			path: "/api/socket.io",
			withCredentials: true
		});

		socket.on("game:state", (etat: VueJoueur) => {
			dernierEtat = etat;
			connexionPerdue = false;
		});

		// game:state arrive meme si adversaire deco
		// il y a que game:opponent-reconnected qui remet le flag
		socket.on("game:opponent-left", () => { adversaireParti = true; });
		socket.on("game:opponent-reconnected", () => { adversaireParti = false; });

		socket.on("disconnect", () => { connexionPerdue = true; });
		socket.on("connect", () => { connexionPerdue = false; });
	}
	return socket;
}

// Chrome coupe la websocket quand la page part en bfcache == retour arriere navigateur
window.addEventListener("pagehide", (event) => {
	if (event.persisted && socket !== null && socket.connected)
		socket.disconnect();
});

window.addEventListener("pageshow", (event) => {
	if (!event.persisted)
		return;
	if (socket !== null) {
		if (!socket.connected)
			socket.connect();
		return;
	}
	if (window.location.pathname === "/jeu")
		window.location.reload();
});

export function getDernierEtat(): VueJoueur | null {
	return dernierEtat;
}

export function getAdversaireParti(): boolean { return adversaireParti; }

export function getConnexionPerdue(): boolean { return connexionPerdue; }

export function oublierEtat() {
	dernierEtat = null;
}

export function fermerSocket() {
	if (socket !== null) {
		socket.disconnect();
		socket = null;
		dernierEtat = null;
		adversaireParti = false;
		connexionPerdue = false;
	}
}
