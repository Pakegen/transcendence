export type Reglages = {
	theme: "witcher" | "wild-hunt";
	police: "sans" | "serif";
	ambiance: "classique" | "grave" | "coupe";
};

export const REGLAGES_PAR_DEFAUT: Reglages = {
	theme: "witcher",
	police: "sans",
	ambiance: "classique"
};

export function lireReglages(): Reglages {
	try {
		const brut = localStorage.getItem("reglages");
		if (brut === null)
			return REGLAGES_PAR_DEFAUT;
		return { ...REGLAGES_PAR_DEFAUT, ...JSON.parse(brut) };
	} catch {
		return REGLAGES_PAR_DEFAUT;
	}
}

export function appliquerReglages(reglages: Reglages) {
	document.documentElement.dataset.theme = reglages.theme;
	document.documentElement.dataset.police = reglages.police;
	localStorage.setItem("reglages", JSON.stringify(reglages));
}