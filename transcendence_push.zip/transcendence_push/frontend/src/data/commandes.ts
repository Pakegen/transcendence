export type Commande = {
	code: string;
	action: "passer" | "abandonner" | "pouvoir" | "jouer" | "finTour" | "mulligan" | "autre";
	carteId: number;
	positionMain: number;
	zone: number;
};

export function decoder(code: string): Commande {
	const action = code[1];
	return {
		code,
		action: action === "0" ? "passer"
			: action === "1" ? "abandonner"
				: action === "2" ? "pouvoir"
					: action === "3" ? "jouer"
						: action === "5" ? "mulligan"
							: action === "6" ? "finTour"
								: "autre",
		carteId: Number(code.slice(2, 5)),
		positionMain: Number(code.slice(6, 8)),
		zone: Number(code[8])
	};
}